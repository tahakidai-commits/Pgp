# PGP - Quiz et Cours de Pharmacie & Médecine

Application de révision (cours + quiz + flashcards) pour la Pharmacologie, la
Toxicologie, la Parasitologie médicale, les Opérations Galéniques et la
Gestion Logistique PGP1. Application 100% front-end (React + Vite +
Tailwind), aucune clé API ni backend requis : toutes les données (cours,
questions, résultats) sont stockées dans le navigateur (localStorage).

## Lancer en local

**Prérequis :** Node.js 20+

1. Installer les dépendances : `npm install`
2. Lancer l'app : `npm run dev`

## Build de production

`npm run build` génère le site statique dans `dist/`.

## Déploiement sur GitHub Pages

Un workflow GitHub Actions (`.github/workflows/deploy.yml`) est fourni : il
build l'app et la publie sur GitHub Pages à chaque push sur `main`.

Pour l'activer sur ton dépôt :
1. Pousse ce projet sur GitHub (branche `main`).
2. Dans le repo GitHub : **Settings → Pages → Build and deployment → Source**,
   choisis **GitHub Actions**.
3. Au prochain push sur `main`, le site sera construit et publié
   automatiquement (l'URL apparaît dans l'onglet Actions puis dans
   Settings → Pages).

Tu peux aussi déclencher le déploiement manuellement depuis l'onglet
**Actions** du dépôt (`workflow_dispatch`).
