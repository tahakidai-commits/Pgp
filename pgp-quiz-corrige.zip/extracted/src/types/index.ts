export type QuestionType = 'TRUE_FALSE' | 'MULTIPLE_CHOICE' | 'SINGLE_CHOICE';

export interface Question {
  id: number;
  quizId: number;
  questionIndex: number;
  contextText?: string;
  questionText: string;
  type: QuestionType;
  options: string[];
  correctAnswers: string[];
  explanation?: string;
  positivePoints: number;
  negativePoints: number;
  maxChoices: number;
}

export interface Quiz {
  id: number;
  title: string;
  description: string;
  category: string;
  isBuiltIn: boolean;
  questionCount: number;
  createdAt: number;
}

export interface QuizAttempt {
  id: string;
  quizId: number;
  quizTitle: string;
  score: number;
  maxScore: number;
  correctCount: number;
  partialCount: number;
  wrongCount: number;
  unansweredCount: number;
  timeTakenSeconds: number;
  completedAt: number;
  userAnswers: Record<number, string[]>;
}

export interface CourseSubSection {
  id: string;
  title: string;
  subtitle?: string;
  content: string; // rich text or markdown-like formatted text
  keyTakeaways?: string[];
  keyTable?: {
    headers: string[];
    rows: string[][];
  };
  formulas?: {
    name: string;
    formula: string;
    example: string;
  }[];
  clinicalNotes?: string[];
  linkedQuizId?: number;
}

export interface CourseChapter {
  id: string;
  number: number;
  title: string;
  description: string;
  sections: CourseSubSection[];
}

export interface Course {
  id: string;
  title: string;
  subject: 'Galénique' | 'Toxicologie' | 'Gestion Logistique' | 'Pharmacologie' | 'Parasitologie';
  badge: string;
  author: string;
  pageCount: number;
  iconName: string;
  colorScheme: {
    primary: string;
    bg: string;
    light: string;
    border: string;
  };
  summary: string;
  learningObjectives: string[];
  chapters: CourseChapter[];
  linkedQuizIds: number[];
}

export type FlashcardSubject = 'Parasitologie' | 'Galénique' | 'Toxicologie' | 'Pharmacologie' | 'Gestion Logistique';

export interface Flashcard {
  id: string;
  subject: FlashcardSubject;
  category: string;
  front: string; // Question or concept prompt
  back: string; // Detailed answer, mechanisms, traps
  mnemonic?: string; // High-yield memory trick or acronym
  sourceReference?: string; // Reference page (ex: "Cours Parasito p. 12")
  difficulty: 'Facile' | 'Moyen' | 'Difficile';
  isCustom?: boolean;
}

export interface FlashcardProgress {
  cardId: string;
  box: number; // Leitner box 1 to 3
  status: 'new' | 'learning' | 'mastered';
  reviewCount: number;
  lastReviewedAt: number;
}

