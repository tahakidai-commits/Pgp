import { Course } from '../types';

export const COURSE_PARASITOLOGIE: Course = {
  id: 'cours-parasitologie-medicale',
  title: 'Parasitologie Médicale & Maladies Parasitaires',
  subject: 'Parasitologie',
  badge: '85 pages de cours officiel',
  author: 'Fascicule de cours PGP 1 – Année scolaire 2025-2026',
  pageCount: 85,
  iconName: 'Bug',
  colorScheme: {
    primary: '#E11D48',
    bg: '#FFF1F2',
    light: '#FFE4E6',
    border: '#FECDD3',
  },
  summary: 'Fascicule officiel complet de Parasitologie Médicale PGP1 (85 pages) : définitions fondamentales, cycles évolutifs, protozooses (amibiase, coccidioses, giardiose, trichomonose), helminthoses (nématodes, filaires, bilharzioses, cestodes), ectoparasitoses (gale) et syndromes de larva migrans.',
  learningObjectives: [
    'Maîtriser les définitions fondamentales : types d’hôtes (définitif, intermédiaire actif/passif), réservoirs, spécificité parasitaire, cycles directs et indirects.',
    'Distinguer les formes végétatives et kystiques des protozoaires (Entamoeba histolytica, Giardia, Trichomonas vaginalis, Coccidies).',
    'Connaître la physiopathologie, les signes d’appel (dysenterie, syndrome de Löffler, hématurie, prurit) et les complications graves.',
    'Identifier les méthodes diagnostiques de certitude : EPS direct, Scotch-test de Graham, technique de Baermann, biopsie cutanée exsangue (BCE), sédimentation urinaire.',
    'Retenir les molécules antiparasitaires clés, leurs posologies et leurs précautions (Métronidazole, Ivermectine, Albendazole, Praziquantel, Diéthylcarbamazine).'
  ],
  linkedQuizIds: [80],
  chapters: [
    {
      id: 'para-ch1-generalites',
      number: 1,
      title: 'Chapitre 1 : Parasitologie Générale & Notions Fondamentales',
      description: 'Définitions des termes techniques, relations hôte-parasite et classification générale des parasites de l’homme (pages 3 à 11).',
      sections: [
        {
          id: 'sec-para-definitions',
          title: '1. Définitions Fondamentales & Types d’Hôtes',
          subtitle: 'Parasite, endoparasite, ectoparasite, hôte intermédiaire actif/passif, cycles évolutifs',
          content: `**1. Définition du Parasite :**
Le parasite est un être vivant (animal ou champignon/végétal) qui, pendant une partie ou la totalité de son existence, vit aux dépens d'un autre organisme vivant appelé **hôte**.

**Classification selon la localisation :**
- **Endoparasite :** Vit à l'intérieur de l'hôte :
  - *Tissulaire :* Filaires (dont *Onchocerca volvulus* dans le derme/kystes sous-cutanés).
  - *Sanguicole :* *Plasmodium* (érythrocytes), *Trypanosoma* (plasma sanguin).
  - *Intestinal :* *Ascaris lumbricoides*, *Ancylostoma duodenale*, *Entamoeba histolytica*.
- **Ectoparasite :** Vit sur les téguments de l'hôte :
  - *Simple nuisant :* Gênant par sa piqûre sans transmettre de maladie (ex : *Cimex lectularius* / punaise de lit).
  - *Agent causal direct de maladie parasitaire :* *Sarcoptes scabiei* (responsable de la gale humaine).
  - *Vecteur de maladie parasitaire :* *Anopheles gambiae* (moustique transmettant le paludisme).

---

**2. Les Hôtes et Réservoirs :**
- **Hôte définitif (HD) :** Être vivant hébergeant la **forme adulte ou sexuée** du parasite. L'homme est l'hôte définitif exclusif de nombreuses parasitoses.
- **Hôte intermédiaire (HI) :** Organisme vivant chez lequel le parasite doit séjourner pour subir une maturation ou multiplication qui l'amène à sa forme infestante (héberge la forme larvaire ou asexuée).
  - *HI actif :* Capable de transmettre lui-même l'agent pathogène par piqûre (*Anopheles gambiae* pour le paludisme, *Simulium damnosum* pour l'onchocercose).
  - *HI passif :* Incapable de transmettre activement le parasite ; la transmission nécessite son ingestion par l'hôte définitif (ex : le crustacé *Cyclops* dans la dracunculose).
- **Réservoir de parasite :** Animal ou milieu écologique (aquatique ou tellurique) qui héberge le parasite et permet son maintien permanent dans la nature en dehors de l'homme.
- **Zoonose :** Maladie animale transmissible à l'homme (l'homme apparaît souvent comme un hôte accidentel).
- **Spécificité parasitaire :** Propriété pour un parasite de ne pouvoir se développer que chez un hôte strictement déterminé (ex : *Enterobius vermicularis* strictement inféodé à l'homme).

---

**3. Les Cycles Évolutifs :**
Enchaînement inéluctable de transformations débutant de l'adulte d'une génération pour aboutir à l'adulte de la génération suivante :
- **Cycle évolutif direct (Monoxène) :** Se déroule chez un seul hôte :
  - *Direct court :* Les formes émises dans le milieu extérieur sont immédiatement infestantes (ex : *Enterobius vermicularis* / oxyure).
  - *Direct long :* Les formes émises doivent subir une maturation dans le milieu extérieur avant de devenir infestantes (ex : *Ascaris lumbricoides* dont l'œuf doit s'embryonner dans le sol pendant plusieurs semaines).
- **Cycle évolutif indirect (Hétéroxène) :** Fait intervenir obligatoirement un ou plusieurs hôtes intermédiaires (ex : *Taenia saginata* avec le bœuf comme HI).
- **Impasse parasitaire :** Situation où le parasite s'égare chez un hôte inhabituel défavorable. Le cycle s'interrompt, le parasite n'atteint jamais le stade adulte et reste bloqué au stade larvaire (ex : ingestion d'œufs de *Toxocara canis* de chien par l'enfant -> syndrome de **Larva migrans viscérale**).`,
          keyTakeaways: [
            'Hôte définitif = héberge la forme adulte ou sexuée.',
            'Hôte intermédiaire passif = Cyclops (dracunculose), actif = moustique/simulie.',
            'Cycle direct court = Enterobius ; Cycle direct long = Ascaris.',
            'Impasse parasitaire = blocage au stade larvaire chez un hôte anormal (Toxocara).'
          ]
        },
        {
          id: 'sec-para-relations-hote',
          title: '2. Relations Hôte-Parasite & Actions Pathogènes',
          subtitle: 'Spoliation, traumatismes, toxines, mécanique, hyperéosinophilie sanguine (HES)',
          content: `**1. Les Actions du Parasite sur l'Hôte :**
- **Action spoliatrice :** Pratiquement constante car le parasite vit aux dépens de l'hôte.
  - *Spoliation sanguine :* Ankylostomes (*Ancylostoma duodenale* 0,2 mL de sang/ver/j) entraînant une anémie ferriprive sévère.
  - *Spoliation vitaminique :* Le bothriocéphale (*Diphyllobothrium latum*) détourne la vitamine B12 et cause une anémie mégaloblastique de type Biermer.
- **Action traumatique et bactériphère :** Perforation de la muqueuse ou de la peau servant de porte d'entrée à des surinfections bactériennes :
  - *Entamoeba histolytica* creuse des ulcères et abcès en « bouton de chemise » dans la muqueuse colique.
  - La femelle de *Dracunculus medinensis* perfore le derme pour libérer ses larves, formant une phlyctène qui s'ulcère.
- **Action toxique :** Émission de sécrétions toxiques d'arthropodes, toxines histolytiques des amibes, hémolysines du paludisme, neurotoxines des tiques (paralysie ascendante). La rupture traumatique d'un kyste hydatique libère un liquide très antigénique provoquant un **choc anaphylactique mortel**.
- **Action mécanique :**
  - Microscopique : éclatement des hématies parasitées par les plasmodies.
  - Macroscopique : **occlusion intestinale mécanique** par un paquet volumineux d'ascaris ; compression viscérale ou cérébrale par un kyste hydatique.
- **Action irritative et réflexe :** Toux réflexe lors du passage pulmonaire de l'ascaridiase ; spasmes digestifs douloureux.
- **Action immuno-dépressive :** Observée au cours du paludisme, des bilharzioses et de l'onchocercose.

---

**2. Les Réactions de l'Hôte au Parasitisme :**
- **Anémie :** Liée à la spoliation sanguine (ankylostomes), à l'hémolyse (paludisme), à la séquestration splénique (leishmaniose viscérale) ou au déficit en vitamine B12 (bothriocéphalose).
- **Hyperéosinophilie Sanguine (HES) :**
  - En parasitologie, l'HES est **quasi-exclusivement le fait des helminthes** (vers) lors de leur migration ou contact tissulaire (**Courbe de Lavier** : ascension rapide pendant la migration larvaire, pic, puis décroissance lente lors de la fixation de l'adulte dans l'intestin).
  - Les protozoaires intraluminaux stricts (amibes non invasives, Giardia, Trichomonas) n'entraînent pas d'hyperéosinophilie.
- **Splénomégalie :** Très fréquente dans les zones tropicales, causée par le paludisme, la leishmaniose viscérale (Kala-azar) et les bilharzioses hépato-spléniques.`,
          keyTakeaways: [
            'HES = signe quasi-exclusif d’helminthose avec migration tissulaire (Courbe de Lavier).',
            'Ankylostomes = spoliation sanguine ; Bothriocéphale = spoliation en vitamine B12.',
            'Rupture de kyste hydatique = choc anaphylactique mortel par action toxique/allergisante.',
            'Paquet d’Ascaris = occlusion intestinale mécanique chirurgicale.'
          ]
        },
        {
          id: 'sec-para-classification',
          title: '3. Classification Générale des Parasites d’Intérêt Médical',
          subtitle: 'Protozoaires (Ciliés, Flagellés, Rhizopodes, Sporozoaires) & Métazoaires',
          content: `Les parasites humains appartiennent principalement au règne animal (les champignons constituant les mycoses). Le règne animal se subdivise en deux sous-règnes :

### I. Sous-Règne des Protozoaires (Unicellulaires)
Organismes unicellulaires dotés de mouvements :
1. **Classe des Ciliés :** Se déplacent grâce à des cils vibratiles. Exemple type : *Balantidium coli* (responsable de dysenteries glairo-sanglantes).
2. **Classe des Flagellés :** Se déplacent grâce à des flagelles :
   - *Sanguicoles et tissulaires :* *Trypanosoma brucei gambiense* (maladie du sommeil), *Leishmania donovani* (leishmaniose viscérale).
   - *Urogénitaux :* *Trichomonas vaginalis*.
   - *Intestinaux :* *Giardia intestinalis* (*G. lamblia*).
3. **Classe des Rhizopodes (Amibes) :** Émettent des pseudopodes pour leur locomotion :
   - Pathogène : *Entamoeba histolytica*.
   - Non pathogènes (commensales) : *Entamoeba coli*, *Endolimax nana*, *Pseudolimax (Iodamoeba) butschlii*.
4. **Classe des Sporozoaires :** Parasites immobiles sans appareil locomoteur différencié :
   - *Isospora (Cystoisospora) belli*, *Toxoplasma gondii*, *Sarcocystis*, *Cryptosporidium parvum*, *Plasmodium* (*P. falciparum, P. malariae, P. ovale, P. vivax*).

---

### II. Sous-Règne des Métazoaires (Pluricellulaires)
Organismes pluricellulaires formés de tissus différenciés :
1. **Phylum des Plathelminthes (Vers plats) :**
   - *Classe des Trématodes :* Corps plat non segmenté, foliacé en feuille. Genres : *Fasciola* (douves), *Schistosoma* (*S. haematobium, S. mansoni, S. intercalatum, S. japonicum, S. mekongi*).
   - *Classe des Cestodes :* Corps aplati rubané segmenté en anneaux. Genres : *Taenia* (*T. saginata, T. solium*), *Hymenolepis*, *Dipylidium*, *Diphyllobothrium*.
2. **Phylum des Némathelminthes (Vers ronds) :**
   - *Classe des Nématodes :* Vers à section ronde cylindrique et à **sexes séparés** :
     - Nématodes intestinaux : *Ascaris lumbricoides*, *Enterobius vermicularis*, *Strongyloides stercoralis*, *Ancylostoma duodenale*, *Necator americanus*, *Trichuris trichiura*, *Trichinella spiralis*.
     - Filaires : *Onchocerca volvulus*, *Wuchereria bancrofti*, *Brugia malayi*, *Loa loa*, *Mansonella*, *Dracunculus medinensis*.
3. **Phylum des Arthropodes :** Exosquelette chitineux rigide et pattes articulées :
   - *Classe des Insectes* (3 paires de pattes, corps en 3 parties : tête, thorax, abdomen) : Moustiques (*Anopheles, Culex, Mansonia, Aedes*), Mouches/Simulies (*Simulium damnosum, Glossina palpalis*), Poux (*Pediculus humanus*).
   - *Classe des Arachnides* (4 paires de pattes à l'état adulte, corps globuleux non segmenté) : *Sarcoptes scabiei* (agent de la gale), tiques (*Ixodes ricinus, Amblyomma variegatum*).
   - *Classe des Crustacés :* *Cyclops* (hôte intermédiaire passif de *Dracunculus medinensis*).
4. **Phylum des Mollusques :** Gastéropodes d'eau douce jouant le rôle d'hôtes intermédiaires des schistosomes (*Biomphalaria*, *Bulinus*, *Oncomelania*).`,
          keyTakeaways: [
            'Protozoaires = unicellulaires (Ciliés, Flagellés, Rhizopodes, Sporozoaires).',
            'Plathelminthes = vers plats (Trématodes non segmentés, Cestodes segmentés).',
            'Némathelminthes = vers ronds cylindriques à sexes séparés.',
            'Arthropodes : Insectes = 3 paires de pattes ; Arachnides = 4 paires de pattes.'
          ]
        }
      ]
    },
    {
      id: 'para-ch2-protozooses',
      number: 2,
      title: 'Chapitre 2 : Les Protozooses Intestinales & Urogénitales',
      description: 'Amibiase dysentérique et hépatique, coccidioses opportunistes, giardiose et trichomonose urogénitale (pages 12 à 36).',
      sections: [
        {
          id: 'sec-para-amibiase',
          title: '1. L’Amibiase (Entamoeba histolytica)',
          subtitle: 'FVH vs FVNH, kyste à 4 noyaux, dysenterie amibienne, abcès hépatique, traitement',
          content: `**1. Définition & Taxinomie :**
L'amibiase est l'état dans lequel l'organisme humain héberge *Entamoeba histolytica*, **seule amibe pathogène** pour l'homme (OMS 1968).
- *Amibiase-infestation (asymptomatique) :* Porteurs sains éliminant des kystes.
- *Amibiase-maladie :* Atteinte tissulaire intestinale (côlon) ou extra-intestinale (foie, poumons).

**2. Morphologie :**
- **Forme Végétative Hématophage (FVH) :** 20 à 40 µm, très mobile par émission de pseudopodes fins et directionnels. Contient des hématies phagocytées dans son endoplasme. C'est la forme pathogène invasive responsable de la dysenterie amibienne (D.A.).
- **Forme Végétative Non Hématophage (FVNH) :** 10 à 12 µm, vit en commensale dans la lumière colique sans phagocyter d'hématies (se nourrit de bactéries et débris).
- **Forme Kystique (FK) :** Éléments immobiles arrondis de 10 à 15 µm à paroi lisse et réfringente. Contient 1, 2 puis **4 noyaux à maturité** (kyste mûr à 4 noyaux = forme de dissémination et de contamination). Présence fréquente de bâtonnets sidérophiles arrondis (**chromidium**).

**3. Cycle Évolutif & Physiopathologie :**
- **Cycle non pathogène :** Les FVNH se multiplient par scissiparité dans la lumière colique, s'enkystent sous l'effet de la déshydratation du bol fécal et sont éliminées sous forme de FK mûres dans les selles.
- **Cycle pathogène :** Sous l'influence de facteurs locaux (lésion muqueuse, épices, déséquilibre de la flore) ou généraux (corticothérapie, dénutrition), la FVNH se transforme en FVH virulente. La FVH sécrète des enzymes protéolytiques lytiques, détruit la muqueuse colique, crée des ulcérations en « bouton de chemise » et peut essaimer par la **veine porte** vers le foie, puis vers la plèvre et les poumons.

**4. Tableaux Cliniques :**
- **Dysenterie Amibienne Aiguë (Amibiase intestinale aiguë) :**
  - Début brutal : évacuations afécales fréquentes (5 à 20 selles/jour) constituées uniquement de glaires et de sang strié (**crachat rectal dysentérique**).
  - Épreintes (douleurs coliques expulsives avec fausses envies d'aller à la selle).
  - Ténesme (contracture douloureuse et permanente du sphincter anal).
  - **Absence de fièvre** dans la forme intestinale non surinfectée (contrairement à la dysenterie bacillaire à *Shigella*).
- **Amibiase Hépatique (Extra-intestinale la plus fréquente) :**
  - *Phase pré-suppurative :* Triade de Fontan = Douleur vive de l'hypochondre droit irradiant à l'épaule + Hépatomégalie douloureuse + Fièvre modérément élevée (38-39°C).
  - *Abcès amibien constitué du foie :* Tableau de suppuration profonde, altération marquée de l'état général, ponction ramenant un pus couleur pâte d'anchois ou chocolat aseptique.

**5. Diagnostic Biologique :**
- *Amibiase intestinale :* Examen Parasitologique des Selles (EPS) à l'état frais direct sur selles fraîchement émises (visualisation des FVH mobiles hématophages), complété par la coloration au Lugol et MIF.
- *Amibiase hépatique :* La sérologie amibienne (ELISA, IFI) est **l'examen de référence** (positive dans plus de 95% des cas) ; échographie hépatique.

**6. Principes Thérapeutiques :**
- **Amoebicides tissulaires (actifs sur les FVH invasives) :**
  - *Métronidazole (Flagyl) :* Adulte : 1,5 à 2 g/jour ; Enfant : 40 à 50 mg/kg/jour en cure de 10 jours.
  - *Secnidazole :* 2 g en prise unique chez l'adulte (30 mg/kg/j pendant 3 jours chez l'enfant).
  - *Tinidazole (Fasigyne) :* 2 g/jour chez l'adulte pendant 3 jours.
  - *Précautions :* Contre-indiqués au 1er trimestre de grossesse et pendant l'allaitement ; **effet antabuse** (intolérance aiguë à l'alcool).
- **Amoebicides de contact (intraluminaux, actifs sur les kystes et FVNH) :**
  - *Association tiliquinol + tibroquinol (Intetrix)* ou *Diloxanide*. Indispensables après la cure d'amoebicide tissulaire pour éliminer le portage luminal et éviter les récidives.`,
          keyTakeaways: [
            'Seule amibe pathogène = Entamoeba histolytica.',
            'Kyste mûr à 4 noyaux = forme infestante de dissémination.',
            'Dysenterie amibienne : crachat rectal glairo-sanglant + épreintes + ténesme SANS fièvre.',
            'Amibiase hépatique = Triade de Fontan (douleur hypochondre droit, hépatomégalie, fièvre).',
            'Traitement : Amoebicide tissulaire (Métronidazole) SUIVI d’un amoebicide de contact (Intetrix).'
          ]
        },
        {
          id: 'sec-para-coccidioses',
          title: '2. Les Coccidioses Intestinales',
          subtitle: 'Cystoisospora belli, Cryptosporidium, Cyclospora, Sarcocystose',
          content: `Les coccidioses sont des protozooses opportunistes en forte recrudescence chez les sujets immunodéprimés (VIH/SIDA). On en distingue 4 majeures :

### 1. Cystoisosporose (Cystoisospora belli)
- **Agent :** *Cystoisospora belli* (anciennement *Isospora belli*), protozoaire sporozoaire hébergé dans les entérocytes.
- **Morphologie :** Oocyste éliminé non segmenté, elliptique, de grande taille (> 30 µm sur 12 µm). À maturité, il renferme **2 sporocystes contenant chacun 4 sporozoïtes en banane** (soit 8 sporozoïtes au total).
- **Clinique :** Diarrhée aqueuse bénigne chez l'immunocompétent ; diarrhée chronique sévère glairo-sanguinolente avec malabsorption et déshydratation chez l'immunodéprimé.
- **Diagnostic :** Coloration de **Ziehl-Neelsen modifiée** mettant en évidence les oocystes colorés en rouge vif.
- **Traitement :** **Cotrimoxazole (Bactrim)** : 2 cp (800 mg SMX + 160 mg TMP) 2 fois/jour pendant 1 semaine chez l'adulte.

---

### 2. Cryptosporidiose (Cryptosporidium parvum)
- **Agent :** *Cryptosporidium parvum* (parasite l'homme et les bovidés : veau, porcelet). Zoonose cosmopolite.
- **Morphologie :** Oocyste sphérique très petit (4 à 7 µm de diamètre), éliminé dans le milieu extérieur **déjà mature, renfermant directement 4 sporozoïtes libres sans sporocyste**.
- **Particularité épidémiologique :** Résiste remarquablement au chlore des piscines et aux systèmes habituels de filtration d'eau potable.
- **Clinique :**
  - Sujet immunocompétent : gastro-entérite aiguë spontanément résolutive en 10-12 jours.
  - Sujet immunodéprimé (VIH à CD4 < 100) : **diarrhée cholériforme profuse**, aqueuse verdâtre (jusqu'à 10-15 litres/jour), crampes abdominales, dénutrition cachectisante et décès par collapsus hydro-électrolytique.
- **Diagnostic :** Coloration de Ziehl-Neelsen modifiée d'Henriksen et Pohlenz (oocystes rouges de 4-6 µm sur fond bleu ou vert).
- **Traitement :** Pas de traitement curatif parfait ; réhydratation hydro-électrolytique majeure + Spiramycine ou Nitazoxanide ; restauration immunitaire par les antirétroviraux (ARV).

---

### 3. Cyclosporose (Cyclospora cayetanensis)
- **Agent :** *Cyclospora cayetanensis*, agent infectieux émergent.
- **Morphologie :** Oocyste arrondi de 9 à 10 µm renfermant à maturité **2 sporocystes contenant chacun 2 sporozoïtes**.
- **Diagnostic biologique :**
  - Coloration de Ziehl-Neelsen modifiée.
  - **Microscopie en fluorescence UV :** Les oocystes présentent une autofluorescence bleue à 365 nm et verte à 450-490 nm.
- **Traitement :** Cotrimoxazole (Bactrim) ou Fluoroquinolones (Ciprofloxacine).

---

### 4. Sarcocystose (Sarcocystis hominis & S. suihominis)
- **Agent & Hôtes :** Parasite hétéroxène à cycle indirect. Hôte définitif = Homme (cycle sexué intestinal) ; Hôte intermédiaire = Bœuf (*S. hominis*) ou Porc (*S. suihominis*) hébergeant des kystes musculaires (sarcocystes).
- **Contamination :** Ingestion de viande de bœuf ou de porc crue ou insuffisamment cuite.
- **Diagnostic :** Découverte dans les selles de sporocystes ovoïdes de 14/9 µm renfermant 4 sporozoïtes et un corps résiduel polaire.
- **Traitement & Prophylaxie :** Cotrimoxazole ou Sulfadiazine ; cuisson complète de la viande de bœuf et de porc.`,
          keyTakeaways: [
            'Cystoisospora belli = oocyste > 30 µm (2 sporocystes à 4 sporozoïtes). Ttt = Cotrimoxazole.',
            'Cryptosporidium = petit oocyste 4-7 µm sans sporocyste, résistant au chlore.',
            'Cyclospora = autofluorescence bleu/vert au microscope UV. Ttt = Cotrimoxazole.',
            'Sarcocystose = contamination par viande crue de porc ou bœuf.'
          ]
        },
        {
          id: 'sec-para-giardiose',
          title: '3. La Giardiose (Giardia intestinalis)',
          subtitle: 'Giardia lamblia, flagellé duodénal, syndrome de malabsorption de l’enfant',
          content: `**1. Définition & Agent :**
La giardiose (ou lambliase) est une affection parasitaire causée par *Giardia intestinalis* (anciennement *Giardia lamblia* ou *Giardia duodenale*), un protozoaire flagellé cosmopolite colonisant la surface duodénale et jéjunale.

**2. Morphologie :**
- **Trophozoïte (forme végétative) :** Forme piriforme (en poire) de 10 à 20 µm de long sur 5 à 10 µm de large. Face ventrale creusée d'une large dépression réniforme faisant office de disque de fixation (ventouse). Comprend **2 noyaux symétriques** à gros caryosome central ("face de vieillard" ou "lunettes"), un axostyle médian et **4 paires de flagelles** lui conférant des mouvements oscillants en « feuille qui tombe ».
- **Kyste :** Forme de résistance et d'infestation, ovale de 8 à 10 µm à paroi lisse réfringente, renfermant **2 à 4 noyaux** et un faisceau de flagelles internes en forme de S.

**3. Habitat & Mode de Vie :**
Le trophozoïte vit strictement à la surface de la muqueuse du duodénum et du jéjunum proximal (il ne pénètre jamais à l'intérieur des cellules épithéliales). Il peut migrer dans les voies biliaires.

**4. Clinique :**
- Souvent latente chez l'adulte.
- **Forme digestive symptomatique :** Diarrhée intermittente sans épreinte ni ténesme, 5 à 10 selles par jour prédominant le matin et après les repas, pâteuses, claires, graisseuses, jaunâtres et mousseuses. Douleurs épigastriques simulant un ulcère gastro-duodénal.
- **Chez le jeune enfant :** Complication majeure par **syndrome de malabsorption intestinale** : selles abondantes, malodorantes et graisseuses (stéatorrhée) conduisant à un amaigrissement important et un **retard staturo-pondéral**.
- *Signe négatif capital :* Pas de fièvre, pas de sang dans les selles.

**5. Diagnostic Biologique :**
- Examen Parasitologique des Selles (EPS) répété sur 3 jours (émission discontinue des kystes) : kystes dans les selles moulées, trophozoïtes dans les selles liquides.
- Tubage duodénal ou test à la cordelette (Enterotest) en cas de suspicion persistante.

**6. Traitement :**
- **Nitro-imidazolés (traitement de 1ère intention) :**
  - *Métronidazole (Flagyl) :* Adulte : 250 mg 3 fois/jour pendant 5 à 7 jours ; Enfant : 30 mg/kg/jour en 3 prises.
  - *Tinidazole (Fasigyne) :* Adulte : 2 g en prise unique ; Enfant : 50 à 70 mg/kg en prise unique.
  - *Secnidazole (Secnol) :* Adulte : 2 g en prise unique ; Enfant : 30 mg/kg en prise unique.
- **En cas d'échec ou de résistance :** Albendazole (Zentel) 400 mg/jour pendant 5 jours ou Nitazoxanide.`,
          keyTakeaways: [
            'Giardia = flagellé en forme de poire à 2 noyaux et 4 paires de flagelles.',
            'Kyste à 4 noyaux résistant 3 mois dans l’eau.',
            'Clinique : selles mousseuses claires duodénales, SANS fièvre ni épreintes.',
            'Chez l’enfant : risque majeur de retard staturo-pondéral par malabsorption.',
            'Traitement : Tinidazole ou Secnidazole 2 g prise unique (ou Métronidazole 5-7j).'
          ]
        },
        {
          id: 'sec-para-trichomonose',
          title: '4. La Trichomonose Urogénitale (Trichomonas vaginalis)',
          subtitle: 'Protozoaire sans kyste, IST, leucorrhées verdâtres spumeuses, col en fraise',
          content: `**1. Définition & Agent Pathogène :**
La trichomonose urogénitale est une Infection Sexuellement Transmissible (IST) fréquente et cosmopolite due à *Trichomonas vaginalis*, un protozoaire flagellé strictement humain.

**2. Morphologie :**
- **Caractéristique fondamentale :** *Trichomonas vaginalis* n'existe que sous la **forme végétative (trophozoïte)**. **IL N'EXISTE AUCUNE FORME KYSTIQUE.**
- Forme ovale ou piriforme de 15 à 25 µm sur 7 à 10 µm.
- Présente à sa partie antérieure **4 flagelles libres** et un **5e flagelle récurrent** fixé le long de la cellule pour former une membrane ondulante courte (ne dépassant pas le 1/3 de la longueur du corps).
- Un axostyle médian rigide traverse le parasite et dépasse à la partie postérieure.

**3. Transmission & Habitat :**
- Habitat : voies génitales et urinaires de la femme (vagin, col) et de l'homme (urètre, prostate).
- Transmission : presque exclusivement par voie sexuelle vénérienne lors de rapports non protégés. Exceptionnellement par le linge de toilette humide.
- Meurt très rapidement dans le milieu extérieur (absence de kyste protecteur).

**4. Clinique :**
- **Chez la femme (Vaginite subaiguë ou aiguë) :**
  - **Leucorrhées abondantes spumeuses/mousseuses**, blanchâtres ou verdâtres, fluides et aérées, d'odeur plâtreuse ou fétide.
  - Prurit vulvaire féroce, cuisson, brûlures mictionnelles et dyspareunie.
  - Examen au spéculum : muqueuse vaginale inflammatoire rouge vif parsemée de petits points rouges hémorragiques donnant l'aspect caractéristique de **« col framboisé »** ou piqueté hémorragique.
- **Chez l'homme :**
  - Le plus souvent **porteur asymptomatique** (réservoir de transmission).
  - Parfois : urétrite subaiguë avec écoulement matinal minime (« goutte matinale » claire ou mucopurulente) et prurit du méat. Complications : prostatite, balanite.
- *Remarque biologique :* *T. vaginalis* phagocyte fréquemment les gonocoques et *Candida albicans*, pouvant masquer une co-infection vénérienne.

**5. Diagnostic Biologique :**
- Chez la femme : prélèvement des sécrétions vaginales au spéculum au niveau du cul-de-sac postérieur.
- Chez l'homme : prélèvement urétral le matin avant toute miction ou culot de centrifugation des premières urines.
- Examen direct à l'état frais immédiat au microscope : met en évidence des parasites très mobiles et oscillants. Frottis coloré au MGG.

**6. Principes Thérapeutiques :**
- **Traitement minute de 1ère intention :** Métronidazole (Flagyl) 2 g en prise unique par voie orale (ou Tinidazole Fasigyne 2 g PU, Secnidazole 2 g PU).
- **Alternative chez la femme :** Métronidazole 500 mg matin et soir pendant 10 jours + ovules gynécologiques vaginaux le soir.
- **Règles impératives :**
  - **Traitement simultané obligatoire des partenaires sexuels** même en l'absence de tout symptôme pour éviter l'effet "ping-pong".
  - Abstention de boissons alcoolisées pendant le traitement (effet antabuse).
  - Préservatifs jusqu'à guérison confirmée.`,
          keyTakeaways: [
            'Trichomonas vaginalis : AUCUNE FORME KYSTIQUE (uniquement forme végétative).',
            'Transmission vénérienne stricte (IST).',
            'Femme : leucorrhées verdâtres spumeuses + col en fraise + prurit intense.',
            'Homme : le plus souvent porteur asymptomatique (goutte matinale).',
            'Règle d’or : traitement minute des deux partenaires simultanément.'
          ]
        }
      ]
    },
    {
      id: 'para-ch3-helminthoses',
      number: 3,
      title: 'Chapitre 3 : Les Helminthoses Intestinales, Tissulaires & Bilharzioses',
      description: 'Nématodoses intestinales (ascaris, oxyure, ankylostome, anguillule, trichine), filarioses, bilharzioses et cestodoses (pages 36 à 77).',
      sections: [
        {
          id: 'sec-para-nematodes-digestifs',
          title: '1. Les Nématodoses Intestinales Majeures',
          subtitle: 'Ascaris (Löffler), Oxyure (Graham), Ankylostome (anémie), Anguillule (Baermann)',
          content: `Les nématodes sont des vers ronds cylindriques non segmentés à sexes séparés. Les principales nématodoses digestives sont :

### 1. Ascaridiase (Ascaris lumbricoides)
- **Morphologie :** Grand ver rond blanc-rosé (mâle 15-17 cm à queue recourbée en crosse ; femelle 20-35 cm). Œuf fécondé de 60/45 µm à coque double externe mamelonnée brune.
- **Cycle biologique :** Cycle direct long. Ingestion d'œufs embryonnés telluriques -> éclosion dans le tube digestif -> migration tissulaire obligatoire de la larve L1 : paroi intestinale -> veine porte -> foie (mue en L2) -> veine sus-hépatique -> cœur droit -> artère pulmonaire -> effraction des alvéoles pulmonaires (mues en L3 puis L4) -> remontée des bronches et trachée -> déglutition au carrefour pharyngé -> maturation en adulte dans le jéjunum. Durée : 2 à 3 mois.
- **Clinique :**
  - *Phase d'invasion larvaire :* **Syndrome de LÖFFLER** associant toux sèche quinteuse, fièvre modérée, expectorations et opacités pulmonaires radiologiques labiles et fugaces, avec une hyperéosinophilie sanguine (HES) élevée (20 à 50%).
  - *Phase d'état intestinale :* Douleurs abdominales vagues, diarrhées. Chez l'enfant en zone d'endémie : **occlusion intestinale mécanique aiguë par pelote d'ascaris**, appendicite ascaridienne.
- **Diagnostic :** EPS direct et concentration de Ritchie ou Kato (œufs mamelonnés caractéristiques).
- **Traitement :** **Albendazole (Zentel)** 400 mg en prise unique (dès 2 ans ; 200 mg de 9 mois à 2 ans) ; Mébendazole (Vermox) ou Pyrantel (Combantrin).

---

### 2. Oxyurose (Enterobius vermicularis)
- **Morphologie :** Petit ver blanc visible à l'œil nu (mâle 3-5 mm, femelle 9-12 mm à extrémité effilée). Œuf transparent asymétrique (un côté plat, un côté bombé) mesurant 60/30 µm, contenant un embryon gyriniforme immédiatement infestant.
- **Cycle & Contamination :** Cycle direct court avec auto-infestation. La femelle gravide migre la nuit vers le sphincter anal, s'y fixe et pond environ 10 000 œufs avant de mourir. Le prurit anal induit le grattage et le transport d'œufs sous les ongles (cycle ano-buccal) et dans la literie.
- **Clinique :** **Prurit anal nocturne ou vespéral féroce**, vulvovaginite chez la fillette, insomnies, cauchemars, irritabilité et troubles de la concentration scolaire.
- **Diagnostic de certitude :** **Scotch-test anal de Graham** appliqué sur les plis radiés de l'anus le matin au réveil avant toute toilette. L'EPS classique est généralement négatif car les œufs ne sont pas pondus dans la lumière intestinale.
- **Traitement :** Albendazole 400 mg PU ou Flubendazole, **à répéter obligatoirement 15 jours plus tard** pour éliminer les vers issus des œufs ingérés. Traiter simultanément tous les membres de la famille, couper les ongles ras et laver les draps à 60°C.

---

### 3. Ankylostomiase (Ancylostoma duodenale & Necator americanus)
- **Biologie & Spoliation :** Vers hématophages fixés par leur capsule buccale armée (*A. duodenale* avec 4 dents chitinisées ; *N. americanus* avec 2 lames tranchantes). Spoliation sanguine massive : 0,2 mL de sang/ver/j pour *A. duodenale* et 0,03 mL pour *N. americanus*.
- **Contamination :** Pénétration transcutanée active des larves strongyloïdes enkystées L3 lors de la marche pieds nus sur sol boueux humide ou défécation en plein air.
- **Clinique :** Gourmes (dermatite prurigineuse aux pieds), catarrhe des gourmes (toux, enrouement), duodénite, puis installation d'une **anémie ferriprive hypochrome microcytaire sévère** avec pâleur, œdèmes des membres inférieurs, dyspnée d'effort et insuffisance cardiaque anémique.
- **Traitement :** Albendazole 400 mg PU + supplémentation martiale ; port systématique de chaussures fermées.

---

### 4. Anguillulose (Strongyloides stercoralis)
- **Particularité biologique unique :** Femelle parthénogénétique nichée dans la muqueuse duodénale. Possède des **cycles internes d'auto-infestation endogène et exogène** qui permettent la pérennisation indéfinie de la parasitose pendant 20 à 30 ans !
- **Clinique :** **Larva currens** (cordon érythémateux serpigineux sous-cutané linéaire très prurigineux progressant à la vitesse spectaculaire de 5 à 10 cm par heure aux fesses et cuisses), crises d'urticaire, HES oscillante "en dents de scie".
- **Forme maligne disséminée (Anguillulose maligne) :** Survient lors de corticothérapie ou immunosuppression (VIH, chimiothérapie). Hyperinfestation massive, translocation de bactéries digestives avec septicémies à bacilles Gram négatif et méningites purulentes, détresse respiratoire aiguë souvent mortelle.
- **Diagnostic :** Découverte de larves rhabditoïdes dans les selles par la **technique d'extraction de BAERMANN** (fondée sur l'hygrotropisme et le thermotropisme positif des larves).
- **Traitement de choix :** **Ivermectine (Stromectol)** : 200 µg/kg en prise unique à jeun. Bilan parasitologique obligatoire avant toute corticothérapie chez un patient ayant séjourné en zone tropicale !

---

### 5. Trichocéphalose & Trichinose
- **Trichuris trichiura :** Ver en forme de fouet (partie antérieure filiforme 2/3). Œuf en forme de citron avec 2 bouchons muqueux clairs. Entraîne lors de charges massives une diarrhée sanglante avec **prolapsus rectal tapissé de vers**.
- **Trichinella spiralis :** Ingestion de viande de porc ou de sanglier mal cuite. Les larves s'enkystent dans les muscles striés très actifs (diaphragme, langue, yeux). Clinique : fièvre en plateau à 40°C, myalgies intenses, **œdème bilatéral de la face et des paupières**, HES > 50%. Diagnostic par biopsie musculaire (deltoïde) et sérologie.`,
          keyTakeaways: [
            'Ascaridiase : Syndrome de Löffler (phase pulmonaire) et occlusion sur pelote.',
            'Oxyurose : Prurit anal nocturne, Scotch-test de Graham, renouveler à J15.',
            'Ankylostomiase : Pénétration transcutanée, anémie ferriprive par spoliation sanguine.',
            'Anguillulose : Larva currens (5-10 cm/h), Baermann, Ivermectine 200 µg/kg.',
            'Corticothérapie chez un tropical = EPS/Baermann impératif pour éviter l’anguillulose maligne.'
          ]
        },
        {
          id: 'sec-para-filarioses',
          title: '2. Les Filarioses Humaines',
          subtitle: 'Dracunculose (ver de Guinée), Onchocercose, Filarioses lymphatiques, Loaose',
          content: `Les filaires sont des nématodes vivipares tissulaires transmis par des arthropodes piqueurs (sauf la dracunculose qui passe par l'eau) :

### 1. Dracunculose (Dracunculus medinensis / Ver de Guinée)
- **Biologie :** Nématode géant du tissu sous-cutané. Femelle adulte mesurant 70 à 120 cm de long.
- **Transmission :** Ingestion d'eau douce de marigot non filtrée contenant des crustacés copépodes (*Cyclops*, **hôte intermédiaire passif**) infectés par les larves L3.
- **Clinique :** La femelle gravide migre vers les membres inférieurs (malléole externe de la cheville) et perfore la peau au contact de l'eau en créant une phlyctène qui s'ulcère.
- **Complications :** Surinfection bactérienne, phlegmon, arthrite septique, **greffe du tétanos**.
- **Statut épidémiologique :** Quasi-éradiquée à l'échelle mondiale. La Côte d'Ivoire est certifiée exempte de dracunculose par l'OMS depuis 2012.
- **Traitement :** Extraction mécanique traditionnelle lente en enroulant quotidiennement le ver sur un bâtonnet d'allumette ; vaccination/sérum antitétanique obligatoire.

---

### 2. Onchocercose ou Cécité des Rivières (Onchocerca volvulus)
- **Vecteur & Épidémiologie :** Transmise par la piqûre de la femelle de **Simulie** (*Simulium damnosum*), petit diptère nématocère se reproduisant exclusivement dans les cours d'eau rapides à fort débit et hautement oxygénés.
- **Clinique :**
  - *Signes cutanés :* Prurit féroce (« gale filarienne »), papules, lichénification (« peau de lézard »), atrophie cutanée et dépigmentation en « peau de léopard ».
  - *Kystes sous-cutanés :* **Onchocercomes** indolores, fibreux, roulant sous le doigt, prédominant au contact des reliefs osseux (crêtes iliaques, côtes, crâne).
  - *Signes oculaires (gravité majeure) :* Microfilaires migrant dans la cornée et la chambre antérieure de l'œil -> kératite ponctuée, kératite sclérosante, choriorétinite conduisant inéluctablement à la **cécité bilatérale définitive**.
- **Diagnostic :** **Biopsie Cutanée Exsangue (BCE ou skin snip)** aux crêtes iliaques montrant les microfilaires dermiques sans gaine à l'examen microscopique direct. Test de Mazzotti à la Notézine (historique).
- **Traitement de choix :** **Ivermectine (Mectizan)** 150 à 200 µg/kg en prise unique annuelle. Détruit plus de 90% des microfilaires dès le 7e jour sans effet macrofilaricide direct. Dénodulation chirurgicale des kystes de la tête.

---

### 3. Filarioses Lymphatiques (Wuchereria bancrofti & Brugia malayi)
- **Biologie & Vecteurs :** Adultes filiformes (8-10 cm) vivant pelotonnés dans les troncs et ganglions lymphatiques (longévité 10-15 ans). Microfilaires engainées présentes dans le sang périphérique avec une **périodicité nocturne stricte (22h - 02h)**. Transmises par les piqûres nocturnes de moustiques culicidés (*Culex quinquefasciatus*, *Anopheles*).
- **Clinique :**
  - *Manifestations précoces :* Lymphangites aiguës centrifuges des membres avec adénopathies douloureuses fébriles, orchi-épididymite.
  - *Manifestations tardives chroniques :* Obstruction et sclérose des vaisseaux lymphatiques -> **Éléphantiasis** fibro-œdémateux monstrueux des membres inférieurs et des bourses (scrotum volumineux), chylurie par rupture des varices lymphatiques dans les voies urinaires.
- **Diagnostic :** Goutte épaisse sanguine prélevée **entre 22h et 02h du matin** (coloration au Giemsa).
- **Traitement :** Diéthylcarbamazine (DEC, Notézine) + Ivermectine ou Albendazole. La **Doxycycline** (200 mg/j pendant 4 à 6 semaines) détruit la bactérie endosymbiote *Wolbachia*, stérilise les femelles adultes et conduit à leur mort.

---

### 4. Loaose (Loa loa)
- **Vecteur :** *Chrysops* (taon / mouche rouge), diptère femelle hématophage à activité **diurne** vivant dans la canopée des forêts équatoriales africaines.
- **Périodicité :** Microfilaires sanguines engainées à **périodicité diurne (pic entre 10h et 14h)**.
- **Clinique :**
  - **Œdème fugace de Calabar :** Œdème sous-cutané indolore, prurigineux, migrateur, durant 2 à 3 jours, localisé aux avant-bras et aux mains.
  - **Migration sous-conjonctivale du ver adulte :** Passage spectaculaire d'un ver adulte blanchâtre sous la conjonctive de l'œil, provoquant larmoiement, photophobie et sensation de corps étranger.
- **Danger mortel & Règle d'or :** En cas de forte charge microfilarienne (> 50 microfilaires/µL), l'administration intempestive de Diéthylcarbamazine (DEC) déclenche une **encéphalite toxique mortelle** due à la lyse massive des microfilaires dans les capillaires cérébraux. Il faut impérativement doser la microfilarémie avant tout traitement, et réduire la charge par Albendazole ou aphérèse avant d'introduire la DEC à doses très progressives.`,
          keyTakeaways: [
            'Dracunculose = Cyclops (HI passif dans l’eau), extraction sur bâtonnet d’allumette.',
            'Onchocercose = Simulie, cécité des rivières, biopsie cutanée exsangue (BCE), Mectizan.',
            'Filariose lymphatique = Culex nocturne, éléphantiasis, prélèvement sanguin nocturne (22h-02h).',
            'Loa loa = Chrysops diurne, œdème de Calabar, vers sous la conjonctive.',
            'Piège mortel Loa loa : encéphalite à la DEC si microfilarémie élevée (> 50 µL).'
          ]
        },
        {
          id: 'sec-para-bilharzioses',
          title: '3. Les Bilharzioses ou Schistosomoses',
          subtitle: 'Schistosoma haematobium, S. mansoni, éperons, furcocercaires, Praziquantel',
          content: `**1. Épidémiologie Générale :**
Deuxième endémie parasitaire mondiale après le paludisme (> 200 millions de personnes infectées). Causées par des vers plats trématodes dioïques (à sexes séparés) du genre *Schistosoma*. Le mâle porte une gouttière ventrale appelée **canal gynécophore** dans lequel s'insère la femelle filiforme.

**2. Les 5 Espèces Pathogènes :**
1. ***Schistosoma haematobium :***
   - Localisation : Plexus veineux vésicaux et utéro-vaginaux (Bilharziose urinaire).
   - Œuf : Ovale, 150/60 µm, muni d'un **éperon terminal rectiligne**.
   - Hôte intermédiaire : Mollusque gastéropode d'eau douce du genre *Bulinus* (*B. globosus*).
2. ***Schistosoma mansoni :***
   - Localisation : Veines mésentériques inférieures (Bilharziose intestinale et hépato-splénique).
   - Œuf : Grand, muni d'un **éperon latéral saillant et triangulaire**.
   - Hôte intermédiaire : Mollusque du genre *Biomphalaria* (*B. pfeifferi*).
3. ***Schistosoma intercalatum :***
   - Localisation : Veines hémorroïdaires et rectales (Bilharziose rectale).
   - Œuf : Muni d'un **éperon terminal coudé**. Hôte intermédiaire = *Bulinus*.
4. ***Schistosoma japonicum & S. mekongi :***
   - Localisation : Plexus veineux mésentériques supérieurs et système porte. Zoonose grave en Asie.
   - Œuf : Petit, arrondi, muni d'un **éperon latéral minuscule rudimentaire**. Hôte intermédiaire = *Oncomelania*.

---

**3. Cycle Biologique :**
Élimination des œufs dans les urines (*S. haematobium*) ou les matières fécales (*S. mansoni*). Dans l'eau douce tiède (20-25°C), l'œuf éclot et libère une larve ciliée nageuse : le **miracidium**. Le miracidium pénètre chez le gastéropode spécifique, s'y multiplie par polyembryonie et donne naissance à des milliers de larves infestantes à queue fourchue : les **furcocercaires**.
Les furcocercaires pénètrent **activement par voie transcutanée** chez l'homme en 10 à 15 minutes lors des baignades, pêche, lessive ou travaux dans les rizières. Elles perdent leur queue, deviennent des schistosomules, gagnent le cœur droit, les poumons puis le système veineux hépatique pour devenir adultes.

---

**4. Clinique :**
- **Phase de pénétration cercarienne :** Dermatite cercarienne (érythème prurigineux transitoire).
- **Phase d'invasion toxo-infectieuse (Fièvre de Katayama) :** Fièvre, céphalées, arthralgies, urticaire, dyspnée asthmatiforme, hépatomégalie et HES massive.
- **Phase d'état spécifique :**
  - *Bilharziose urinaire (S. haematobium) :* **Hématurie terminale indolore**, pollakiurie, cystite. Complications tardives : sténoses urétérales, hydronéphrose, pyélonéphrite, calcifications vésicales ("vessie de porcelaine") et **cancer épidermoïde de la vessie**.
  - *Bilharziose intestinale (S. mansoni) :* Douleurs coliques, diarrhée sanglante, polypes rectaux bilharziens. Complication hépatique majeure : fibrose périportale de Symmers conduisant à une **hypertension portale sévère avec volumineuses varices œsophagiennes hémorragiques** et splénomégalie géante.

---

**5. Diagnostic Biologique :**
- *S. haematobium :* Recherche des œufs à éperon terminal dans le culot de centrifugation des urines de 24h ou filtration sur membrane d'urines prélevées après effort physique.
- *S. mansoni :* Recherche des œufs à éperon latéral dans les selles par EPS direct et technique de Kato-Katz. Biopsie de la muqueuse rectale au rectoscope montrant les œufs vivants ou calcifiés.

---

**6. Traitement :**
- **Praziquantel (Biltricide) :** Traitement universel de référence de toutes les bilharzioses humaines. Posologie : **40 mg/kg en prise unique** (ou 60 mg/kg pour *S. japonicum*).
- *Oxamniquine (Vansil) :* 15 à 20 mg/kg en prise unique, actif uniquement sur *S. mansoni*.`,
          keyTakeaways: [
            'S. haematobium = éperon terminal, Bulin, hématurie indolore, cancer de vessie.',
            'S. mansoni = éperon latéral, Biomphalaria, dysenterie et hypertension portale.',
            'Contamination active par pénétration transcutanée des furcocercaires dans l’eau douce.',
            'Traitement universel de référence = Praziquantel 40 mg/kg prise unique.'
          ]
        },
        {
          id: 'sec-para-cestodes',
          title: '4. Les Cestodoses Humaines (Ténias & Cysticercose)',
          subtitle: 'Taenia saginata (bœuf, inerme), Taenia solium (porc, armé), cysticercose cérébrale',
          content: `Les cestodes sont des vers plats hermaphrodites segmentés en anneaux (strobile), dépourvus de tube digestif (absorption osmotique à travers leurs téguments).

### 1. Taenia saginata (Ténia inerme du bœuf)
- **Morphologie :** Grand ver solitaire mesurant 4 à 10 mètres de long. Scolex piriforme muni de **4 ventouses, sans rostre ni crochets**. Strobile formé de 1 000 à 2 000 anneaux. Les anneaux mûrs terminaux mesurent 2 cm sur 0,7 cm et présentent de **très nombreuses ramifications utérines fines (> 15 par côté)**.
- **Biologie & Émission :** Les anneaux mûrs sont doués d'une motilité active propre : **ils forcent activement le sphincter anal en dehors des selles** et sont retrouvés dans les sous-vêtements ou sur les draps.
- **Cycle :** Hôte intermédiaire = bovidés (bœuf, zébu) ingérant les œufs embryonnés sur les pâturages -> formation de larves cysticerques (*Cysticercus bovis*) dans les muscles. Contamination humaine : consommation de viande de bœuf crue ou insuffisamment cuite.
- **Particularité majeure :** L'œuf de *T. saginata* n'évolue pas chez l'homme. **Il n'y a JAMAIS de cysticercose humaine avec T. saginata.**

---

### 2. Taenia solium (Ténia armé du porc)
- **Morphologie :** Ver solitaire plus court (1 à 3 mètres). Scolex globuleux muni de 4 ventouses et d'un **rostre armé d'une double couronne de crochets**. Anneaux mûrs plus courts présentant **peu de ramifications utérines épaisses (< 14 par côté)**.
- **Biologie & Émission :** Les anneaux n'ont pas de motilité active : ils se détachent par chaînes de 4 à 6 et sont **éliminés passivement dans les matières fécales**.
- **Cycle :** Hôte intermédiaire normal = le porc (*Cysticercus cellulosae* dans la viande de porc ladrée). Contamination humaine : viande de porc crue ou mal cuite.

---

### 3. Le Danger Mortel : La Cysticercose Humaine
- Contrairement à *T. saginata*, chez *T. solium*, **l'homme peut devenir accidentellement hôte intermédiaire** s'il ingère des œufs d'origine humaine (mains sales, eau souillée) ou par péristaltisme rétrograde d'anneaux dans l'estomac.
- Les embryons hexacanthes traversent la paroi digestive, disséminent par voie sanguine et s'enkystent sous forme de cysticerques dans :
  - **Le cerveau (Neurocysticercose) :** Cause majeure d'**épilepsie secondaire de l'adulte**, hypertension intracrânienne, céphalées violentes, déficits neurologiques focaux.
  - **L'œil :** Baisse visuelle, uvéite, décollement rétinien.
  - **Les muscles et le tissu sous-cutané :** Nodules indolores calcifiés visibles à la radiographie.

---

**4. Diagnostic & Traitement :**
- Diagnostic du ténia adulte : examen macroscopique des anneaux éliminés (comptage des ramifications utérines après éclaircissement) ; Scotch-test anal pour retrouver les embryophores.
- Diagnostic de la neurocysticercose : scanner cérébral ou IRM (kystes en « grains de plomb » ou scolex visible), sérologie ELISA/Western-Blot.
- **Traitement du téniase intestinale adulte :**
  - **Niclosamide (Trédémine) :** 2 g en 2 prises espacées d'une heure chez l'adulte (mâcher longuement les comprimés à jeun).
  - **Praziquantel (Biltricide) :** 10 à 15 mg/kg en prise unique.
- **Traitement de la neurocysticercose :** Albendazole à fortes doses (15 mg/kg/j pendant 8 à 30 jours) ou Praziquantel, obligatoirement associés à une corticothérapie préalable pour prévenir l'œdème cérébral inflammatoire réactionnel.`,
          keyTakeaways: [
            'T. saginata (bœuf) : scolex inerme sans crochets, anneaux mobiles forçant l’anus, > 15 ramifications.',
            'T. solium (porc) : scolex armé de crochets, anneaux passifs dans les selles, < 14 ramifications.',
            'DANGER T. solium = CYSTICERCOSE humaine cérébrale (épilepsie) par ingestion d’œufs.',
            'Traitement ténia adulte : Niclosamide (Trédémine) 2 g ou Praziquantel 10-15 mg/kg PU.'
          ]
        }
      ]
    },
    {
      id: 'para-ch4-ectoparasitoses-larva-migrans',
      number: 4,
      title: 'Chapitre 4 : Les Ectoparasitoses & Syndromes de Larva Migrans',
      description: 'La gale humaine (Sarcoptes scabiei), toxocarose viscérale, anisakiose marine et larbish cutané (pages 77 à 86).',
      sections: [
        {
          id: 'sec-para-gale',
          title: '1. La Gale ou Scabiose (Sarcoptes scabiei)',
          subtitle: 'Acarien, sillon scabieux, prurit nocturne, gale norvégienne, Ivermectine & Ascabiol',
          content: `**1. Définition & Agent Pathogène :**
La gale (ou scabiose) est une dermatose contagieuse cosmopolite très prurigineuse causée par la prolifération intra-épidermique d'un acarien microscopique : *Sarcoptes scabiei var. hominis*.

**2. Morphologie & Biologie :**
- Acarien globuleux grisâtre aplati ventralement, strié transversalement.
- La femelle adulte mesure environ 330 µm de long sur 250 µm de large (mâle plus petit, 220 µm).
- Possède **4 paires de pattes courtes** chez l'adulte : les deux paires antérieures portent des ventouses pédiculées (**ambulacres**). La femelle possède des ambulacres aux paires 1 et 2 ; le mâle aux paires 1, 2 et 4. Les larves hexapodes écloses possèdent 3 paires de pattes.
- **Cycle biologique :** Après accouplement à la surface de la peau, le mâle meurt. La femelle fécondée s'enfonce sous la couche cornée de l'épiderme et y creuse un tunnel horizontal (le **sillon scabieux**) progressant de 1 à 2 mm par jour. Elle s'y nourrit de liquide interstitiel et y dépose **2 à 3 œufs par jour** pendant 1 à 2 mois.
- Survie hors de l'hôte humain : très limitée (**ne dépasse pas 24 à 48 heures** dans l'environnement ambiant).

**3. Mode de Transmission :**
- **Transmission directe (95% des cas) :** Contact cutané intime, direct et prolongé (rapports sexuels, sommeil dans le même lit, mère-nourrisson, crèches). La gale est une véritable Infection Sexuellement Transmissible (IST).
- **Transmission indirecte (5% des cas) :** Par l'intermédiaire de la literie, des couvertures, des serviettes et vêtements partagés.

**4. Signes Cliniques :**
- **Symptôme cardinal :** **Prurit diffus féroce à recrudescence nocturne**, qui épargne toujours le visage, le cou et le haut du dos chez l'adulte.
- **Lésions cutanées spécifiques :**
  - *Sillons scabieux :* Trajets linéaires sinueux filiformes de quelques millimètres, blanchâtres, se terminant par une petite surélévation : l'**éminence acarienne** (abritant la femelle).
  - *Vésicules perlées :* Minuscules vésicules translucides translucides reposant sur une base non érythémateuse.
  - *Nodules scabieux (Chancre scabieux) :* Papulo-nodules rouge-cuivré très prurigineux, situés électivement sur les organes génitaux externes de l'homme (fourreau de la verge, scrotum).
- **Topographie d'élection :** Espaces interdigitaux des mains, face antérieure des poignets, plis des coudes, creux axillaires, région péri-ombilicale, fesses, face interne des cuisses et mamelons chez la femme.
- **Formes cliniques particulières :**
  - *Gale du nourrisson :* Localisation caractéristique à la **plante des pieds** et aux paumes, avec vésiculo-pustules plantaires et atteinte du visage possible.
  - *Gale norvégienne (hyperkératosique croûteuse) :* Survient chez les patients immunodéprimés (VIH, corticothérapie, sujets âgés alités). Éruptions croûteuses et squames farineuses profuses sur tout le corps renfermant des **millions de sarcoptes**. Prurit souvent discret ou absent. **Forme extrêmement contagieuse** déclenchant de véritables épidémies en milieu hospitalier.

**5. Diagnostic Biologique :**
Prélèvement à l'aide d'une aiguille stérile ou d'une lame de scalpel après scarification d'un sillon : examen microscopique direct à l'état frais dans une goutte d'huile d'immersion ou de potasse, montrant la femelle vivante, les œufs ovalaires (150 µm) ou les déjections noirâtres (scybales).

**6. Principes Thérapeutiques :**
- **Traitement acaricide topique (externe) :**
  - *Benzoate de benzyle (Ascabiol)* : lotion appliquée au pinceau sur tout le corps (sauf le visage) après un bain tiède, laissée en contact 24 heures (12h chez le jeune enfant) puis rincée.
  - *Pyréthrinoïdes (Perméthrine 5% ou Sprégal)*.
- **Traitement acaricide oral (systémique) :**
  - **Ivermectine (Stromectol) : 200 µg/kg en prise unique** (environ 1 comprimé de 3 mg par 15 kg de poids). Traitement de choix des collectivités, de la gale croûteuse et des échecs locaux (AMM officielle en France depuis 2001). À renouveler 8 à 14 jours plus tard pour éliminer les larves nouvellement écloses.
- **Mesures environnementales indispensables :**
  - **Traiter impérativement le même jour tous les membres du foyer et les partenaires intimes**, même asymptomatiques.
  - Lavage en machine à 60°C de tout le linge de corps, draps et serviettes utilisés dans les 3 jours précédents, ou mise sous sac plastique fermé hermétiquement pendant 72 heures avec un aérosol scabicide (poudre A-par).`,
          keyTakeaways: [
            'Sarcoptes scabiei : femelle creuse un sillon sous-corné, survie hors de l’hôte < 48h.',
            'Prurit généralisé féroce nocturne respectant le visage chez l’adulte.',
            'Lésions spécifiques : sillons interdigitaux, vésicules perlées, chancre scabieux génital.',
            'Nourrisson = vésicules de la plante des pieds ; Norvégienne = croûtes profuses hyper-contagieuses.',
            'Traitement : Ivermectine orale 200 µg/kg + Ascabiol + traitement obligatoire de l’entourage.'
          ]
        },
        {
          id: 'sec-para-larva-migrans',
          title: '2. Les Syndromes de Larva Migrans',
          subtitle: 'Larva migrans viscérale (Toxocara), Anisakiose marine, Larva migrans cutanée (Larbish)',
          content: `Les syndromes de Larva migrans désignent l'ensemble des troubles provoqués par la migration et la persistance chez l'homme de **larves de nématodes animaux en impasse parasitaire** (le parasite ne peut pas poursuivre son cycle normal vers le stade adulte chez l'homme).

### 1. Syndrome de Larva Migrans Viscérale / Toxocarose
- **Agents :** *Toxocara canis* (ascaris du chien) et accessoirement *Toxocara cati* (ascaris du chat).
- **Contamination humaine :** Ingestion d'œufs embryonnés telluriques par de jeunes enfants (1 à 5 ans) lors de jeux dans les bacs à sable publics souillés par des déjections canines ou par géophagie (pica), ou par consommation de légumes souillés crus.
- **Pathogénie :** Les larves L2 écloses dans l'estomac perforent la paroi digestive et migrent à travers les viscères (foie, poumons, cœur, cerveau, globe oculaire) où elles s'enkystent dans des granulomes éosinophiles sans jamais atteindre le stade adulte.
- **Clinique :**
  - Forme commune fébrile : asthénie, fièvre modérée, hépatosplénomégalie, épisodes asthmatiformes avec infiltrats pulmonaires labiles.
  - **Toxocarose oculaire :** Gravité extrême chez l'enfant plus âgé, généralement sans signes généraux : granulome rétinien inflammatoire pseudotumoral unilatéral conduisant à une baisse visuelle sévère, strabisme ou cécité.
- **Diagnostic Biologique :**
  - **Hyperéosinophilie sanguine majeure, constante et durable (HES pouvant atteindre 50 à 70%)**.
  - Sérologie spécifique par ELISA et confirmation en Western-Blot (recherche des anticorps dirigés contre les antigènes d'excrétion-sécrétion des larves L2). L'EPS est toujours strictement négatif car aucun ver adulte ne vit dans l'intestin.
- **Traitement :**
  - **Albendazole (Zentel)** : 10 à 15 mg/kg/jour en 2 prises pendant 15 jours, ou Diéthylcarbamazine.
  - Corticothérapie indispensable en cas d'atteinte oculaire ou cardiaque. (L'Ivermectine est inefficace).
  - Prophylaxie : vermifugation tri-annuelle des chiens adultes et mensuelle des chiots jusqu'à 6 mois ; protection des bacs à sable.

---

### 2. Anisakiose (Anisakis simplex)
- **Biologie & Source :** Les adultes vivent dans l'estomac des mammifères marins (dauphins, baleines, phoques). Les œufs éclosent en mer et les larves L3 infectent les poissons marins (hareng, maquereau, merlu, saumon, thon) et les calmars.
- **Contamination humaine :** Consommation de poissons de mer crus, marinés, fumés ou insuffisamment cuits (**sushis, sashimis, harengs saurs, ceviche**).
- **Clinique :**
  - *Forme gastrique aiguë :* Douleurs épigastriques atroces pseudo-ulcéreuses survenant 4 à 8 heures après le repas de poisson, avec vomissements et manifestations allergiques aiguës.
  - *Forme intestinale :* Syndrome subocclusif ou tumoral avec granulome à éosinophiles 1 à 2 semaines plus tard.
- **Diagnostic & Traitement :** **Endoscopie œso-gastro-duodénale en urgence**, qui visualise la larve blanchâtre fixée dans la muqueuse gastrique et permet son **extraction mécanique immédiate à la pince**, ce qui guérit instantanément le malade.
- **Prophylaxie :** Congélation industrielle préalable du poisson à **-20°C pendant au moins 24 heures** (ou cuisson à cœur à > 65°C pendant 1 minute).

---

### 3. Syndrome de Larva Migrans Cutanée (Larbish)
- **Agents :** Larves strongyloïdes de nématodes parasites du chien et du chat : *Ancylostoma braziliense* et *Ancylostoma caninum*.
- **Contamination :** Pénétration transcutanée active de larves infectantes L3 lors de la marche pieds nus ou de l'allongement direct sur le sable chaud et humide des plages tropicales souillées par les déjections des chiens errants.
- **Clinique :**
  - Apparition d'une papule prurigineuse au point de pénétration.
  - Développement d'un **trajet sous-cutané linéaire serpigineux en relief, très érythémateux et intensément prurigineux**, progressant de **quelques millimètres à 2-3 cm par jour** (« dermatite vermineuse rampante »).
  - Localisation élective : pieds, orteils, fesses, cuisses, dos.
  - Évolution : en l'absence de traitement, la larve meurt spontanément au bout de quelques semaines à quelques mois car elle ne peut pas traverser la membrane basale épidermique.
- **Diagnostic :** Purement clinique (aspect serpigineux caractéristique + notion de séjour récent en zone intertropicale). Éosinophilie sanguine habituellement normale.
- **Traitement curatif :**
  - **Ivermectine (Stromectol) : 200 µg/kg en prise unique**, entraînant l'arrêt du prurit en 24-48h et la guérison complète.
  - Alternative : Albendazole (Zentel) 400 mg/jour pendant 3 jours.`,
          keyTakeaways: [
            'Larva migrans = blocage au stade larvaire chez l’homme (impasse parasitaire).',
            'Toxocarose = déjections canines, HES massive, risque de cécité oculaire. Ttt = Albendazole.',
            'Anisakiose = poisson marin cru (sushis), pseudo-ulcère aigu, extraction endoscopique de la larve.',
            'Larbish = cordon serpigineux cutané avançant de 2-3 cm/j sur plage tropicale. Ttt = Ivermectine.'
          ]
        }
      ]
    }
  ]
};
