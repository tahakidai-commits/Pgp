import React, { useState, useMemo } from 'react';
import { 
  ArrowLeft, 
  Search, 
  BookOpen, 
  GraduationCap, 
  CheckCircle2, 
  Lightbulb, 
  Calculator, 
  FileText,
  ChevronDown,
  ChevronUp,
  Sparkles
} from 'lucide-react';
import { Course, CourseChapter, CourseSubSection } from '../types';

interface CourseDetailScreenProps {
  course: Course;
  onBack: () => void;
  onStartQuiz: (quizId: number) => void;
  onOpenCalculators: () => void;
}

export const CourseDetailScreen: React.FC<CourseDetailScreenProps> = ({
  course,
  onBack,
  onStartQuiz,
  onOpenCalculators,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedChapterId, setExpandedChapterId] = useState<string>(
    course.chapters[0]?.id || ''
  );
  const [activeSectionId, setActiveSectionId] = useState<string>(
    course.chapters[0]?.sections[0]?.id || ''
  );

  // Perfusion live calculator state for chapter 2 of Galenique
  const [calcVolume, setCalcVolume] = useState('1500');
  const [calcHours, setCalcHours] = useState('12');
  const [calcDropFactor, setCalcDropFactor] = useState('20');

  const perfusionResult = useMemo(() => {
    const v = parseFloat(calcVolume);
    const h = parseFloat(calcHours);
    const factor = parseFloat(calcDropFactor) || 20;
    if (isNaN(v) || isNaN(h) || v <= 0 || h <= 0) return null;
    const totalMinutes = h * 60;
    const totalDrops = v * factor;
    const rate = Math.round(totalDrops / totalMinutes);
    return {
      rate,
      totalDrops,
      totalMinutes,
    };
  }, [calcVolume, calcHours, calcDropFactor]);

  // Filter sections by search query
  const filteredChapters = useMemo(() => {
    if (!searchQuery.trim()) return course.chapters;
    const q = searchQuery.toLowerCase();
    return course.chapters.map((ch) => ({
      ...ch,
      sections: ch.sections.filter(
        (sec) =>
          sec.title.toLowerCase().includes(q) ||
          sec.content.toLowerCase().includes(q) ||
          sec.keyTakeaways?.some((k) => k.toLowerCase().includes(q))
      ),
    })).filter((ch) => ch.sections.length > 0);
  }, [course, searchQuery]);

  return (
    <div className="min-h-screen bg-slate-50 pb-28">
      {/* Top Bar */}
      <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-slate-700 hover:text-blue-600 font-semibold text-sm transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Tous les cours</span>
          </button>
          {course.linkedQuizIds.length > 0 && (
            <button
              onClick={() => onStartQuiz(course.linkedQuizIds[0])}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              <GraduationCap className="w-4 h-4" />
              <span>S'entraîner au Quiz</span>
            </button>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-4 space-y-5">
        {/* Header Hero */}
        <div
          className="rounded-3xl p-6 border shadow-sm relative overflow-hidden"
          style={{
            backgroundColor: course.colorScheme.bg,
            borderColor: course.colorScheme.border,
          }}
        >
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <span
              className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-white"
              style={{ backgroundColor: course.colorScheme.primary }}
            >
              {course.subject}
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-white/80 text-slate-700 border border-slate-200">
              {course.badge}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2 leading-tight">
            {course.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mb-4">
            Par {course.author}
          </p>

          <p className="text-sm text-slate-700 leading-relaxed bg-white/70 backdrop-blur-xs p-4 rounded-2xl border border-white/60 mb-4">
            {course.summary}
          </p>

          {/* Objectives */}
          <div className="space-y-1.5">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Compétences et objectifs attendus :</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              {course.learningObjectives.map((obj, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{obj}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Search within Course */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher une notion dans ce cours (ex: lyophilisation, CMM, DJA, débit...)"
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 placeholder-slate-400 shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-semibold"
            >
              Effacer
            </button>
          )}
        </div>

        {/* Chapters and Sections */}
        <div className="space-y-6">
          {filteredChapters.map((chapter) => {
            const isChapterExpanded = expandedChapterId === chapter.id || searchQuery.length > 0;
            return (
              <div
                key={chapter.id}
                className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden"
              >
                {/* Chapter Accordion Header */}
                <button
                  onClick={() =>
                    setExpandedChapterId(isChapterExpanded ? '' : chapter.id)
                  }
                  className="w-full px-5 py-4 flex items-center justify-between bg-slate-50/70 hover:bg-slate-100/70 transition-colors text-left cursor-pointer border-b border-slate-200/60"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-xl flex items-center justify-center font-bold text-sm text-white shrink-0"
                      style={{ backgroundColor: course.colorScheme.primary }}
                    >
                      {chapter.number}
                    </div>
                    <div>
                      <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                        {chapter.title}
                      </h2>
                      <p className="text-xs text-slate-500">{chapter.description}</p>
                    </div>
                  </div>
                  <div className="text-slate-400">
                    {isChapterExpanded ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </div>
                </button>

                {/* Chapter Sections */}
                {isChapterExpanded && (
                  <div className="divide-y divide-slate-100 p-2 sm:p-4 space-y-6">
                    {chapter.sections.map((sec) => (
                      <article key={sec.id} className="pt-4 first:pt-2 space-y-4">
                        {/* Section Header */}
                        <div>
                          <h3 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                            {sec.title}
                          </h3>
                          {sec.subtitle && (
                            <p className="text-xs font-semibold text-slate-500 mt-0.5">
                              {sec.subtitle}
                            </p>
                          )}
                        </div>

                        {/* Section Content */}
                        <div className="text-sm text-slate-800 leading-relaxed whitespace-pre-line space-y-3 font-normal">
                          {sec.content}
                        </div>

                        {/* Interactive Table if available */}
                        {sec.keyTable && (
                          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-slate-50/50 my-3">
                            <table className="w-full text-xs text-left text-slate-700">
                              <thead className="bg-slate-100/90 text-slate-900 font-bold border-b border-slate-200">
                                <tr>
                                  {sec.keyTable.headers.map((h, idx) => (
                                    <th key={idx} className="p-3">
                                      {h}
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-200/60">
                                {sec.keyTable.rows.map((row, rIdx) => (
                                  <tr key={rIdx} className="hover:bg-blue-50/30 transition-colors">
                                    {row.map((cell, cIdx) => (
                                      <td key={cIdx} className="p-3 font-medium">
                                        {cell}
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}

                        {/* Embedded Interactive Perfusion Calculator if in Calculations Section */}
                        {sec.id === 'sec-calcul-debit-perfusion' && (
                          <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-4 my-4 space-y-3">
                            <div className="flex items-center gap-2 text-blue-900 font-bold text-sm">
                              <Calculator className="w-4 h-4 text-blue-600" />
                              <span>Simulateur en direct : Calculateur de Débit de Perfusion</span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                              <div>
                                <label className="text-xs font-semibold text-slate-600">
                                  Volume à perfuser (mL)
                                </label>
                                <input
                                  type="number"
                                  value={calcVolume}
                                  onChange={(e) => setCalcVolume(e.target.value)}
                                  className="w-full mt-1 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                                />
                              </div>
                              <div>
                                <label className="text-xs font-semibold text-slate-600">
                                  Durée prescrite (heures)
                                </label>
                                <input
                                  type="number"
                                  value={calcHours}
                                  onChange={(e) => setCalcHours(e.target.value)}
                                  className="w-full mt-1 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                                />
                              </div>
                              <div>
                                <label className="text-xs font-semibold text-slate-600">
                                  Tubulure (gouttes/mL)
                                </label>
                                <select
                                  value={calcDropFactor}
                                  onChange={(e) => setCalcDropFactor(e.target.value)}
                                  className="w-full mt-1 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                                >
                                  <option value="20">Standard adulte (20 gttes/mL)</option>
                                  <option value="60">Micro-gouttes pédiatrie (60 gttes/mL)</option>
                                  <option value="15">Transfusion sang (15 gttes/mL)</option>
                                </select>
                              </div>
                            </div>

                            {perfusionResult && (
                              <div className="p-3 bg-white rounded-xl border border-blue-200 flex items-center justify-between">
                                <div>
                                  <div className="text-xs text-slate-500 font-medium">
                                    Débit calculé à régler :
                                  </div>
                                  <div className="text-xl font-extrabold text-blue-700">
                                    {perfusionResult.rate}{' '}
                                    <span className="text-xs font-bold text-slate-600">
                                      gouttes / minute
                                    </span>
                                  </div>
                                </div>
                                <div className="text-right text-xs text-slate-500">
                                  <div>Total : {perfusionResult.totalDrops.toLocaleString()} gouttes</div>
                                  <div>Durée : {perfusionResult.totalMinutes} minutes</div>
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Key Takeaways Card */}
                        {sec.keyTakeaways && sec.keyTakeaways.length > 0 && (
                          <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-3.5 space-y-1.5">
                            <div className="flex items-center gap-1.5 text-xs font-extrabold text-amber-900 uppercase tracking-wider">
                              <Lightbulb className="w-4 h-4 text-amber-600" />
                              <span>Notions essentielles pour l'examen :</span>
                            </div>
                            <ul className="space-y-1 pl-5 list-disc text-xs text-amber-950 font-medium">
                              {sec.keyTakeaways.map((point, kIdx) => (
                                <li key={kIdx}>{point}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </article>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bottom CTA: Test Knowledge */}
        {course.linkedQuizIds.length > 0 && (
          <div className="p-5 rounded-3xl bg-linear-to-r from-blue-600 to-indigo-700 text-white shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h4 className="text-base font-bold">Prêt à tester vos connaissances ?</h4>
              <p className="text-xs text-blue-100">
                Passez immédiatement les questionnaires et travaux dirigés liés à ce cours.
              </p>
            </div>
            <button
              onClick={() => onStartQuiz(course.linkedQuizIds[0])}
              className="px-5 py-2.5 rounded-2xl bg-white text-blue-700 font-bold text-sm shadow-xs hover:bg-blue-50 transition-colors whitespace-nowrap cursor-pointer"
            >
              Lancer le Quiz du cours
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
