import React from 'react';
import { Home, BookOpen, GraduationCap, Layers, User } from 'lucide-react';

interface BottomNavProps {
  currentTab: number;
  onTabChange: (tab: number) => void;
  coursesCount: number;
  quizzesCount: number;
  flashcardsCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  coursesCount,
  quizzesCount,
  flashcardsCount = 31,
}) => {
  const navItems = [
    {
      id: 0,
      label: 'Accueil',
      icon: Home,
    },
    {
      id: 1,
      label: 'Cours',
      icon: BookOpen,
      badge: coursesCount,
    },
    {
      id: 2,
      label: 'Quiz',
      icon: GraduationCap,
      badge: quizzesCount,
    },
    {
      id: 3,
      label: 'Flashcards',
      icon: Layers,
      badge: flashcardsCount,
    },
    {
      id: 4,
      label: 'Profil',
      icon: User,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-lg">
      <div className="max-w-md mx-auto px-4 py-1.5 flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer ${
                isActive
                  ? 'text-blue-600 font-bold scale-105'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <div
                  className={`w-10 h-7 rounded-xl flex items-center justify-center transition-colors ${
                    isActive ? 'bg-blue-50 text-blue-600' : 'text-slate-500'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                {item.badge !== undefined && item.badge > 0 && !isActive && (
                  <span className="absolute -top-1 -right-1 bg-slate-200 text-slate-700 text-[10px] font-bold px-1 rounded-full">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] leading-tight mt-0.5 tracking-tight">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
