import React from 'react';
import { History, Bell, Calculator } from 'lucide-react';

interface HeaderProps {
  onOpenHistory: () => Unit;
  onOpenDoctor: () => void;
  onOpenCalculators: () => void;
  attemptCount: number;
}

type Unit = void;

export const Header: React.FC<HeaderProps> = ({
  onOpenHistory,
  onOpenDoctor,
  onOpenCalculators,
  attemptCount,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-4xl mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Left: Avatar + Greeting */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-11 h-11 rounded-full bg-blue-50 border-2 border-blue-200 flex items-center justify-center overflow-hidden shadow-xs">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=160&q=80"
                alt="Avatar Étudiant"
                className="w-full h-full object-cover"
                onError={(e) => {
                  // Fallback avatar icon
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <span className="text-blue-700 font-bold text-sm">PGP</span>
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-500 font-medium">Bonjour,</span>
              <span className="text-xs font-bold px-1.5 py-0.5 rounded-full bg-blue-100/80 text-blue-700">
                Promo PGP1
              </span>
            </div>
            <h1 className="text-base font-bold text-slate-900 leading-tight">
              Étudiant en Pharmacie & Médecine
            </h1>
            <p className="text-[11px] text-slate-500 hidden sm:block">
              Apprendre aujourd'hui, soigner demain.
            </p>
          </div>
        </div>

        {/* Right: Quick Tools */}
        <div className="flex items-center gap-2">
          {/* Calculators button */}
          <button
            onClick={onOpenCalculators}
            title="Calculateurs de perfusion & dilutions"
            className="w-9 h-9 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <Calculator className="w-4 h-4" />
          </button>

          {/* History */}
          <button
            onClick={onOpenHistory}
            title="Historique des quiz"
            className="w-9 h-9 rounded-full bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 flex items-center justify-center transition-colors relative cursor-pointer"
          >
            <History className="w-4 h-4" />
            {attemptCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-4 bg-blue-600 text-white text-[10px] font-bold rounded-full px-1 flex items-center justify-center">
                {attemptCount > 9 ? '9+' : attemptCount}
              </span>
            )}
          </button>

          {/* Notification / Encadrement */}
          <button
            onClick={onOpenDoctor}
            title="Encadrement & notifications"
            className="w-9 h-9 rounded-full bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 flex items-center justify-center transition-colors relative cursor-pointer"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
          </button>
        </div>
      </div>
    </header>
  );
};
