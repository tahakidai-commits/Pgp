import React, { useState } from 'react';
import { 
  BookOpen, 
  FileCheck, 
  BarChart3, 
  Star, 
  Sparkles, 
  Play, 
  ArrowRight, 
  FileText,
  Clock, 
  CheckCircle2, 
  Flame, 
  Calculator,
  ChevronRight,
  ShieldCheck,
  Stethoscope,
  Pill,
  Heart,
  Brain,
  Microscope,
  Truck,
  Activity,
  Bug,
  Layers
} from 'lucide-react';
import { Course, Quiz } from '../types';

interface HomeScreenProps {
  courses: Course[];
  quizzes: Quiz[];
  onSelectCourse: (course: Course) => void;
  onSelectQuiz: (quiz: Quiz, practiceMode: boolean) => void;
  onOpenCalculators: () => void;
  onOpenHistory: () => void;
  onNavigateTab: (tab: number) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  courses,
  quizzes,
  onSelectCourse,
  onSelectQuiz,
  onOpenCalculators,
  onOpenHistory,
  onNavigateTab,
}) => {
  const [selectedQuizForMode, setSelectedQuizForMode] = useState<Quiz | null>(null);

  // Quick action items matching design
  const quickActions = [
    {
      label: 'Mes cours',
      icon: BookOpen,
      bg: 'bg-blue-50 hover:bg-blue-100',
      iconColor: 'text-blue-600',
      action: () => onNavigateTab(1),
    },
    {
      label: 'Mes quiz',
      icon: FileCheck,
      bg: 'bg-emerald-50 hover:bg-emerald-100',
      iconColor: 'text-emerald-600',
      action: () => onNavigateTab(2),
    },
    {
      label: 'Flashcards',
      icon: Layers,
      bg: 'bg-indigo-50 hover:bg-indigo-100',
      iconColor: 'text-indigo-600',
      action: () => onNavigateTab(3),
    },
    {
      label: 'Calculateurs',
      icon: Calculator,
      bg: 'bg-purple-50 hover:bg-purple-100',
      iconColor: 'text-purple-600',
      action: onOpenCalculators,
    },
    {
      label: 'Résultats',
      icon: BarChart3,
      bg: 'bg-amber-50 hover:bg-amber-100',
      iconColor: 'text-amber-600',
      action: onOpenHistory,
    },
  ];

  // Specialties grid matching Figma reference
  const specialties = [
    {
      title: 'Parasitologie',
      sub: '85 pages officielles',
      icon: Bug,
      bg: 'bg-rose-50',
      iconColor: 'text-rose-600',
      onClick: () => {
        const c = courses.find((item) => item.subject === 'Parasitologie');
        if (c) onSelectCourse(c);
        else onNavigateTab(1);
      },
    },
    {
      title: 'Galénique',
      sub: '53 pages de cours',
      icon: Pill,
      bg: 'bg-amber-50',
      iconColor: 'text-amber-600',
      onClick: () => {
        const c = courses.find((item) => item.subject === 'Galénique');
        if (c) onSelectCourse(c);
        else onNavigateTab(1);
      },
    },
    {
      title: 'Toxicologie',
      sub: '36 pages Pr TIGORI',
      icon: Activity,
      bg: 'bg-sky-50',
      iconColor: 'text-sky-600',
      onClick: () => {
        const c = courses.find((item) => item.subject === 'Toxicologie');
        if (c) onSelectCourse(c);
        else onNavigateTab(1);
      },
    },
    {
      title: 'Logistique',
      sub: '44 pages & NPSP-CI',
      icon: Truck,
      bg: 'bg-emerald-50',
      iconColor: 'text-emerald-600',
      onClick: () => {
        const c = courses.find((item) => item.subject === 'Gestion Logistique');
        if (c) onSelectCourse(c);
        else onNavigateTab(1);
      },
    },
    {
      title: 'Pharmacologie',
      sub: '65 questions de TD',
      icon: Brain,
      bg: 'bg-indigo-50',
      iconColor: 'text-indigo-600',
      onClick: () => {
        onNavigateTab(2);
      },
    },
  ];

  return (
    <div className="space-y-6 pb-24">
      {/* 1. Hero Blue Banner */}
      <div className="rounded-3xl p-6 sm:p-7 bg-linear-to-r from-blue-700 via-blue-600 to-indigo-700 text-white shadow-lg relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="relative z-10 max-w-sm space-y-2">
          <span className="inline-block px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold text-blue-100 uppercase tracking-wider">
            Examens PGP1 2025-2026
          </span>
          <h2 className="text-2xl sm:text-3xl font-black leading-tight tracking-tight">
            Révise, progresse, réussis !
          </h2>
          <p className="text-xs sm:text-sm text-blue-100/90 leading-relaxed">
            Supports de cours complets et QCM officiels corrigés pour maîtriser tes matières médicales.
          </p>
          <div className="pt-2 flex items-center gap-3">
            <button
              onClick={() => {
                const firstQuiz = quizzes[0];
                if (firstQuiz) setSelectedQuizForMode(firstQuiz);
              }}
              className="px-5 py-2.5 rounded-full bg-white text-blue-700 font-extrabold text-xs shadow-md hover:bg-blue-50 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>Commencer un quiz</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onNavigateTab(1)}
              className="px-4 py-2.5 rounded-full bg-white/15 hover:bg-white/25 text-white font-bold text-xs backdrop-blur-xs transition-colors cursor-pointer"
            >
              Voir les cours
            </button>
          </div>
        </div>

        {/* Stethoscope hero illustration container */}
        <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-3xl bg-white/10 backdrop-blur-md p-3 border border-white/20 flex items-center justify-center shrink-0 shadow-inner">
          <Stethoscope className="w-20 h-20 text-blue-200 animate-pulse" />
        </div>
      </div>

      {/* 2. Quick Action Buttons */}
      <div className="grid grid-cols-5 gap-2 sm:gap-3">
        {quickActions.map((action, i) => {
          const Icon = action.icon;
          return (
            <button
              key={i}
              onClick={action.action}
              className="flex flex-col items-center p-2 sm:p-2.5 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-md transition-all cursor-pointer group"
            >
              <div
                className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-105 mb-1.5 sm:mb-2 ${action.bg}`}
              >
                <Icon className={`w-5 h-5 sm:w-6 sm:h-6 ${action.iconColor}`} />
              </div>
              <span className="text-[11px] sm:text-xs font-bold text-slate-800 text-center line-clamp-1">
                {action.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Flashcards Banner */}
      <div
        onClick={() => onNavigateTab(3)}
        className="rounded-3xl p-4 sm:p-5 bg-gradient-to-r from-indigo-900 via-purple-900 to-indigo-800 text-white flex items-center justify-between cursor-pointer hover:shadow-lg transition-all border border-indigo-700/60 shadow-md group"
      >
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md text-amber-300 flex items-center justify-center shrink-0 border border-white/10 group-hover:scale-105 transition-transform">
            <Layers className="w-6 h-6 text-indigo-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider">
                Mémorisation active
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span className="text-[11px] text-emerald-300 font-bold">Nouveau</span>
            </div>
            <h3 className="text-sm sm:text-base font-bold text-white mt-0.5">
              Flashcards & Fiches de Révision Rapide
            </h3>
            <p className="text-xs text-indigo-200/90 line-clamp-1">
              Entraînez-vous avec les cartes mémo recto/verso : cycles, vecteurs, pièges du concours, posologies et formules.
            </p>
          </div>
        </div>
        <div className="w-8 h-8 rounded-full bg-white/15 text-white flex items-center justify-center shrink-0 group-hover:translate-x-1 transition-transform">
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>

      {/* 3. Featured TD & Défi Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div
          onClick={() => {
            const featured = quizzes.find((q) => q.id === 81) || quizzes.find((q) => q.id === 80) || quizzes[0];
            if (featured) setSelectedQuizForMode(featured);
          }}
          className="rounded-3xl p-4 sm:p-5 bg-gradient-to-r from-rose-500/10 via-pink-500/10 to-amber-500/10 border border-rose-200/80 flex items-center justify-between cursor-pointer hover:border-rose-300 transition-all shadow-xs"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-xs shrink-0">
              <Bug className="w-6 h-6 text-rose-200" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-rose-700 uppercase tracking-wider">
                  Nouveaux Quizz PGP
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                <span className="text-[11px] text-slate-500 font-semibold">4 Quiz (176 Q)</span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                TD & Examens Parasitologie
              </h3>
              <p className="text-xs text-slate-600">
                TD 50 questions, Éval 2021 (40 Q) & Banque Extractor (51 Q)
              </p>
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

        <div
          onClick={() => {
            const featured = quizzes.find((q) => q.id === 70) || quizzes[0];
            if (featured) setSelectedQuizForMode(featured);
          }}
          className="rounded-3xl p-4 sm:p-5 bg-gradient-to-r from-teal-500/10 via-emerald-500/10 to-cyan-500/10 border border-teal-200/80 flex items-center justify-between cursor-pointer hover:border-teal-300 transition-all shadow-xs"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-xs shrink-0">
              <Sparkles className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">
                  Nouveau TD 2024
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                <span className="text-[11px] text-slate-500 font-semibold">41 questions</span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                TD Galénique : Calculs
              </h3>
              <p className="text-xs text-slate-600">
                Corrigé officiel PGP1 : débits, Gay-Lussac et opérations.
              </p>
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

        <div
          onClick={() => {
            const featured = quizzes.find((q) => q.id === 50) || quizzes[0];
            if (featured) setSelectedQuizForMode(featured);
          }}
          className="rounded-3xl p-4 sm:p-5 bg-gradient-to-r from-purple-500/10 via-indigo-500/10 to-blue-500/10 border border-purple-200/80 flex items-center justify-between cursor-pointer hover:border-purple-300 transition-all shadow-xs"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-purple-600 text-white flex items-center justify-center shadow-xs shrink-0">
              <Flame className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-purple-700 uppercase tracking-wider">
                  Épreuve Phare
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
                <span className="text-[11px] text-slate-500 font-semibold">40 questions</span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                Évaluation Toxicologie
              </h3>
              <p className="text-xs text-slate-600">
                Formulaire Dr. Bosson : xénobiotiques & antidotes.
              </p>
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* 4. Specialties Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-base sm:text-lg font-bold text-slate-900">
            Parcourir par matière
          </h3>
          <button
            onClick={() => onNavigateTab(1)}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Voir tous les cours</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {specialties.map((spec, i) => {
            const Icon = spec.icon;
            return (
              <div
                key={i}
                onClick={spec.onClick}
                className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
              >
                <div
                  className={`w-10 h-10 rounded-2xl flex items-center justify-center mb-3 ${spec.bg}`}
                >
                  <Icon className={`w-5 h-5 ${spec.iconColor}`} />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{spec.title}</h4>
                  <p className="text-[11px] text-slate-500">{spec.sub}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Section Cours : Aperçu des cours officiels */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900">
              Fiches de Cours PGP1 (5 Matières)
            </h3>
            <p className="text-xs text-slate-500">
              Supports officiels complets : Parasitologie (85p), Galénique, Toxicologie & Logistique
            </p>
          </div>
          <button
            onClick={() => onNavigateTab(1)}
            className="text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Ouvrir l'espace cours</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
          {courses.map((course) => (
            <div
              key={course.id}
              onClick={() => onSelectCourse(course)}
              className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span
                    className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase text-white"
                    style={{ backgroundColor: course.colorScheme.primary }}
                  >
                    {course.subject}
                  </span>
                  <span className="text-[11px] font-semibold text-slate-500 bg-slate-50 border border-slate-200 px-2 py-0.5 rounded-full">
                    {course.badge}
                  </span>
                </div>
                <h4 className="text-base font-bold text-slate-900 mb-1 leading-snug">
                  {course.title}
                </h4>
                <p className="text-xs text-slate-500 font-medium mb-2">
                  {course.author}
                </p>
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {course.summary}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-teal-700">
                <span>Lire le cours & calculs</span>
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6. Section Quiz : Entraînements officiels */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900">
              Examens & Entraînements
            </h3>
            <p className="text-xs text-slate-500">
              Chronomètre 40s par question & barème officiel
            </p>
          </div>
          <button
            onClick={() => onNavigateTab(2)}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Voir tous les quiz ({quizzes.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {quizzes.slice(0, 4).map((quiz) => (
            <div
              key={quiz.id}
              className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs hover:shadow-md transition-all flex items-center justify-between gap-3"
            >
              <div className="space-y-1 max-w-[70%]">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-100 text-blue-700">
                    {quiz.category}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    {quiz.questionCount} questions
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 line-clamp-1">
                  {quiz.title}
                </h4>
                <p className="text-xs text-slate-500 line-clamp-1">{quiz.description}</p>
              </div>

              <button
                onClick={() => setSelectedQuizForMode(quiz)}
                className="px-4 py-2 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Lancer</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Mode Picker Modal (Révision vs Examen) */}
      {selectedQuizForMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="text-center space-y-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700 uppercase">
                {selectedQuizForMode.category}
              </span>
              <h3 className="text-lg font-bold text-slate-900">
                {selectedQuizForMode.title}
              </h3>
              <p className="text-xs text-slate-500">
                Choisissez le mode d'entraînement souhaité :
              </p>
            </div>

            <div className="space-y-2.5">
              {/* Option 1: Révision */}
              <button
                onClick={() => {
                  const q = selectedQuizForMode;
                  setSelectedQuizForMode(null);
                  onSelectQuiz(q, true);
                }}
                className="w-full p-4 rounded-2xl border-2 border-emerald-200 bg-emerald-50/60 hover:bg-emerald-100/70 transition-colors text-left flex items-start gap-3 cursor-pointer"
              >
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-bold text-emerald-950">Mode Révision</div>
                  <div className="text-xs text-emerald-800">
                    Correction et explications détaillées affichées immédiatement après chaque question.
                  </div>
                </div>
              </button>

              {/* Option 2: Examen */}
              <button
                onClick={() => {
                  const q = selectedQuizForMode;
                  setSelectedQuizForMode(null);
                  onSelectQuiz(q, false);
                }}
                className="w-full p-4 rounded-2xl border-2 border-blue-200 bg-blue-50/60 hover:bg-blue-100/70 transition-colors text-left flex items-start gap-3 cursor-pointer"
              >
                <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-bold text-blue-950">Mode Examen</div>
                  <div className="text-xs text-blue-800">
                    Chronomètre de 40s par question, barème officiel et note globale calculée à la fin.
                  </div>
                </div>
              </button>
            </div>

            <button
              onClick={() => setSelectedQuizForMode(null)}
              className="w-full py-2.5 text-xs font-bold text-slate-500 hover:text-slate-700 transition-colors cursor-pointer"
            >
              Annuler
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
