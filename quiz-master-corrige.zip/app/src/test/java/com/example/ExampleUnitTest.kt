package com.example

import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.ui.viewmodel.QuizViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testTrueFalseScoring() {
    val qTrue = QuestionEntity(
      id = 1L,
      quizId = 1L,
      questionIndex = 1,
      questionText = "Test True",
      type = QuestionType.TRUE_FALSE,
      options = listOf("VRAI", "FAUX"),
      correctAnswers = listOf("VRAI"),
      positivePoints = 1.0f,
      negativePoints = 0.5f,
      maxChoices = 1
    )

    val questions = listOf(qTrue)

    // Case 1: Correct answer -> +1.0 pt
    val summaryCorrect = QuizViewModel.evaluateAnswers(questions, mapOf(1L to setOf("VRAI")))
    assertEquals(1.0f, summaryCorrect.totalScore, 0.001f)
    assertEquals(1, summaryCorrect.correctCount)

    // Case 2: Wrong answer -> -0.5 pt penalty
    val summaryWrong = QuizViewModel.evaluateAnswers(questions, mapOf(1L to setOf("FAUX")))
    assertEquals(-0.5f, summaryWrong.totalScore, 0.001f)
    assertEquals(1, summaryWrong.wrongCount)

    // Case 3: Unanswered -> 0 pt
    val summaryEmpty = QuizViewModel.evaluateAnswers(questions, emptyMap())
    assertEquals(0.0f, summaryEmpty.totalScore, 0.001f)
    assertEquals(1, summaryEmpty.unansweredCount)
  }

  @Test
  fun testMultipleChoiceScoring() {
    val qcm = QuestionEntity(
      id = 2L,
      quizId = 1L,
      questionIndex = 2,
      questionText = "Test QCM",
      type = QuestionType.MULTIPLE_CHOICE,
      options = listOf("a- Option 1", "b- Option 2", "c- Option 3", "d- Option 4"),
      correctAnswers = listOf("a", "c"),
      positivePoints = 1.0f,
      negativePoints = 0.0f,
      maxChoices = 2
    )

    val questions = listOf(qcm)

    // Case 1: Both correct -> +1.0 pt
    val summaryBoth = QuizViewModel.evaluateAnswers(questions, mapOf(2L to setOf("a", "c")))
    assertEquals(1.0f, summaryBoth.totalScore, 0.001f)
    assertEquals(1, summaryBoth.correctCount)

    // Case 2: One correct without errors -> +0.5 pt
    val summaryOne = QuizViewModel.evaluateAnswers(questions, mapOf(2L to setOf("a")))
    assertEquals(0.5f, summaryOne.totalScore, 0.001f)
    assertEquals(1, summaryOne.partialCount)

    // Case 3: Error present -> 0 pt
    val summaryError = QuizViewModel.evaluateAnswers(questions, mapOf(2L to setOf("a", "b")))
    assertEquals(0.0f, summaryError.totalScore, 0.001f)
    assertEquals(1, summaryError.wrongCount)
  }

  @Test
  fun testTextImportParser() {
    val rawText = """
1. Question Vrai Faux
Réponse: VRAI

2. Question QCM
a- Choix 1
b- Choix 2
Réponse: a, b
    """.trimIndent()

    val parsed = QuizViewModel.parseTextToQuestions(rawText)
    assertEquals(2, parsed.size)
    assertEquals(QuestionType.TRUE_FALSE, parsed[0].type)
    assertEquals(listOf("VRAI"), parsed[0].correctAnswers)
    assertEquals(QuestionType.MULTIPLE_CHOICE, parsed[1].type)
    assertEquals(listOf("a", "b"), parsed[1].correctAnswers)
  }
}
