package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.QuizEntity
import com.example.ui.screens.DoctorDetailScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.QuizEditorScreen
import com.example.ui.screens.QuizPlayScreen
import com.example.ui.screens.QuizResultScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.QuizViewModel

sealed interface Screen {
    data object Home : Screen
    data object Play : Screen
    data object Result : Screen
    data object Editor : Screen
    data object History : Screen
    data class DoctorDetail(val quiz: QuizEntity? = null) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    QuizAppRoot()
                }
            }
        }
    }
}

@Composable
fun QuizAppRoot(
    viewModel: QuizViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "ScreenTransition"
    ) { screen ->
        when (screen) {
            Screen.Home -> {
                HomeScreen(
                    viewModel = viewModel,
                    onStartQuiz = { quiz, practiceMode ->
                        viewModel.startQuiz(quiz, practiceMode)
                        currentScreen = Screen.Play
                    },
                    onCreateQuiz = {
                        currentScreen = Screen.Editor
                    },
                    onOpenHistory = {
                        currentScreen = Screen.History
                    },
                    onOpenDoctorDetail = { quiz ->
                        currentScreen = Screen.DoctorDetail(quiz)
                    }
                )
            }

            Screen.Play -> {
                QuizPlayScreen(
                    viewModel = viewModel,
                    onFinish = {
                        currentScreen = Screen.Result
                    },
                    onQuit = {
                        currentScreen = Screen.Home
                    }
                )
            }

            Screen.Result -> {
                QuizResultScreen(
                    viewModel = viewModel,
                    onRestart = {
                        val activeQuiz = viewModel.playState.value.quiz
                        val isPractice = viewModel.playState.value.isPracticeMode
                        if (activeQuiz != null) {
                            viewModel.startQuiz(activeQuiz, isPractice)
                            currentScreen = Screen.Play
                        } else {
                            currentScreen = Screen.Home
                        }
                    },
                    onHome = {
                        viewModel.resetPlayState()
                        currentScreen = Screen.Home
                    }
                )
            }

            Screen.Editor -> {
                QuizEditorScreen(
                    viewModel = viewModel,
                    onQuizSaved = {
                        currentScreen = Screen.Home
                    },
                    onCancel = {
                        currentScreen = Screen.Home
                    }
                )
            }

            Screen.History -> {
                HistoryScreen(
                    viewModel = viewModel,
                    onBack = {
                        currentScreen = Screen.Home
                    }
                )
            }

            is Screen.DoctorDetail -> {
                val allQuizzes by viewModel.allQuizzes.collectAsState()
                val chosenQuiz = screen.quiz
                    ?: allQuizzes.firstOrNull { it.title.contains("Toxicologie", ignoreCase = true) }
                    ?: allQuizzes.firstOrNull()

                DoctorDetailScreen(
                    onBack = { currentScreen = Screen.Home },
                    onStartExam = { quizToStart ->
                        val target = quizToStart ?: chosenQuiz
                        if (target != null) {
                            viewModel.startQuiz(target, practiceMode = false)
                            currentScreen = Screen.Play
                        } else {
                            currentScreen = Screen.Home
                        }
                    },
                    featuredQuiz = chosenQuiz
                )
            }
        }
    }
}
