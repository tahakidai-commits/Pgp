package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// --- FIGMA MEDICAL DESIGN SYSTEM TOKENS (Matching Reference Image) ---

// Primary Brand Palette (Medical Royal Blue / Cobalt & Cyan)
val QuizPrimary = Color(0xFF1E6BFF) // Vibrant royal blue from button & icons in reference
val QuizPrimaryVariant = Color(0xFF1D4ED8)
val QuizPrimaryLight = Color(0xFFEFF6FF)
val QuizSecondary = Color(0xFF0284C7) // Sky blue
val QuizSecondaryContainer = Color(0xFFE0F2FE)
val QuizTertiary = Color(0xFF10B981) // Medical emerald / mint
val QuizTertiaryContainer = Color(0xFFD1FAE5)

// Medical pastel containers for category / service cards
val PastelBlueBg = Color(0xFFE0F2FE)
val PastelBlueIcon = Color(0xFF0284C7)

val PastelGreenBg = Color(0xFFDCFCE7)
val PastelGreenIcon = Color(0xFF10B981)

val PastelPinkBg = Color(0xFFFFE4E6)
val PastelPinkIcon = Color(0xFFF43F5E)

val PastelOrangeBg = Color(0xFFFFEDD5)
val PastelOrangeIcon = Color(0xFFF97316)

val PastelPurpleBg = Color(0xFFEEF2FF)
val PastelPurpleIcon = Color(0xFF6366F1)

val PastelTealBg = Color(0xFFCCFBF1)
val PastelTealIcon = Color(0xFF0D9488)

// Feedback & Status Badges
val QuizSuccess = Color(0xFF10B981)
val QuizSuccessContainer = Color(0xFFD1FAE5)
val QuizSuccessBorder = Color(0xFFA7F3D0)

val QuizError = Color(0xFFEF4444)
val QuizErrorContainer = Color(0xFFFEE2E2)
val QuizErrorBorder = Color(0xFFFECACA)

val QuizWarning = Color(0xFFF59E0B)
val QuizWarningContainer = Color(0xFFFEF3C7)
val QuizWarningBorder = Color(0xFFFDE68A)

// Neutral Canvas & Surface Layers
val DarkSurface = Color(0xFF0F172A)
val DarkCard = Color(0xFF1E293B)
val DarkBackground = Color(0xFF0B0F19)
val DarkBorder = Color(0xFF334155)

val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFFFFFFF)
val LightBackground = Color(0xFFF4F7FC) // Light soft medical blue-gray from reference
val LightBorder = Color(0xFFE2E8F0)
val LightBorderSubtle = Color(0xFFF1F5F9)
val LightMutedText = Color(0xFF64748B)
val TextDark = Color(0xFF0F172A)

// Hero Banner Gradient Brush (matching reference image header banner)
val PrimaryHeroBrush = Brush.linearGradient(
    colors = listOf(Color(0xFF2563EB), Color(0xFF38BDF8))
)

val CardAccentGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF1E6BFF).copy(alpha = 0.06f), Color(0xFF0284C7).copy(alpha = 0.03f))
)

val Purple80 = Color(0xFF93C5FD)
val PurpleGrey80 = Color(0xFFCBD5E1)
val Pink80 = Color(0xFFFBCFE8)

val Purple40 = Color(0xFF1E6BFF)
val PurpleGrey40 = Color(0xFF64748B)
val Pink40 = Color(0xFF0284C7)

