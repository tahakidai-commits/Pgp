package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.ui.theme.PrimaryHeroBrush
import com.example.ui.theme.QuizError
import com.example.ui.theme.QuizErrorContainer
import com.example.ui.theme.QuizPrimary
import com.example.ui.theme.QuizSecondary
import com.example.ui.theme.QuizSuccess
import com.example.ui.theme.QuizSuccessContainer
import com.example.ui.theme.QuizWarning
import com.example.ui.theme.QuizWarningContainer
import com.example.ui.viewmodel.QuestionScoreResult
import com.example.ui.viewmodel.QuizSummaryResult
import com.example.ui.viewmodel.QuizViewModel

enum class ResultFilter {
    ALL,
    WRONG_ONLY,
    CORRECT_ONLY,
    UNANSWERED
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizResultScreen(
    viewModel: QuizViewModel,
    onRestart: () -> Unit,
    onHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playState by viewModel.playState.collectAsState()
    val questions = playState.questions
    val userAnswers = playState.userAnswers
    val quiz = playState.quiz

    val summary: QuizSummaryResult = remember(questions, userAnswers) {
        viewModel.calculateSummary(questions, userAnswers)
    }

    var selectedFilter by remember { mutableStateOf(ResultFilter.ALL) }

    val filteredResults = remember(summary, selectedFilter) {
        when (selectedFilter) {
            ResultFilter.ALL -> summary.questionResults
            ResultFilter.WRONG_ONLY -> summary.questionResults.filter { it.isWrong }
            ResultFilter.CORRECT_ONLY -> summary.questionResults.filter { it.isFullyCorrect || it.isPartiallyCorrect }
            ResultFilter.UNANSWERED -> summary.questionResults.filter { it.isUnanswered }
        }
    }

    Scaffold(
        modifier = modifier.testTag("quiz_result_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Résultats & Corrigé",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onHome) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour à l'accueil"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Score Trophy Card
            item {
                ScoreHeroCard(
                    quizTitle = quiz?.title ?: "Quiz",
                    totalScore = summary.totalScore,
                    maxScore = summary.maxScore,
                    percentage = summary.percentage,
                    timeSeconds = playState.timeElapsedSeconds
                )
            }

            // Stats Breakdown Grid
            item {
                StatsBreakdownCard(summary = summary)
            }

            // Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onRestart,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("restart_quiz_button")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Recommencer")
                    }

                    Button(
                        onClick = onHome,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = QuizPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("return_home_button")
                    ) {
                        Text("Accueil", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Header for Corrigé Détaillé
            item {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    Text(
                        text = "Corrigé Détaillé",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Analysez vos réponses et consultez les justifications officielles.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Filter Chips
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = selectedFilter == ResultFilter.ALL,
                                onClick = { selectedFilter = ResultFilter.ALL },
                                label = { Text("Toutes (${summary.questionResults.size})") },
                                colors = FilterChipDefaults.filterChipColors()
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedFilter == ResultFilter.WRONG_ONLY,
                                onClick = { selectedFilter = ResultFilter.WRONG_ONLY },
                                label = { Text("Erreurs (${summary.wrongCount})") },
                                colors = FilterChipDefaults.filterChipColors()
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedFilter == ResultFilter.CORRECT_ONLY,
                                onClick = { selectedFilter = ResultFilter.CORRECT_ONLY },
                                label = { Text("Réussies (${summary.correctCount + summary.partialCount})") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedFilter == ResultFilter.UNANSWERED,
                                onClick = { selectedFilter = ResultFilter.UNANSWERED },
                                label = { Text("Sans réponse (${summary.unansweredCount})") }
                            )
                        }
                    }
                }
            }

            // Questions Corrigé List
            items(filteredResults, key = { it.question.id }) { result ->
                QuestionCorrectionCard(result = result)
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun ScoreHeroCard(
    quizTitle: String,
    totalScore: Float,
    maxScore: Float,
    percentage: Float,
    timeSeconds: Int
) {
    val gradeText = when {
        percentage >= 80f -> "Excellent travail !"
        percentage >= 65f -> "Très bien réussi !"
        percentage >= 50f -> "Moyenne atteinte"
        else -> "À approfondir"
    }

    val gradeColor = when {
        percentage >= 80f -> QuizSuccess
        percentage >= 50f -> QuizWarning
        else -> QuizError
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("score_hero_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(brush = PrimaryHeroBrush)
                .padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                    modifier = Modifier.size(68.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = Color(0xFFFBBF24),
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = gradeText,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = quizTitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f)
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (totalScore % 1 == 0f) "%.0f".format(totalScore) else "%.1f".format(totalScore),
                        style = MaterialTheme.typography.headlineLarge,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = " / ${"%.0f".format(maxScore)} pts",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.75f),
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                    modifier = Modifier.padding(top = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${"%.1f".format(percentage)}%",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        val m = timeSeconds / 60
                        val s = timeSeconds % 60
                        Text(
                            text = String.format("%02d:%02d", m, s),
                            color = Color.White.copy(alpha = 0.9f),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatsBreakdownCard(summary: QuizSummaryResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DÉTAIL DE LA PERFORMANCE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${summary.questionResults.size} questions",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Correct
                StatBox(
                    label = "Bonnes",
                    value = "${summary.correctCount}",
                    color = Color(0xFF059669),
                    bg = Color(0xFFECFDF5),
                    borderColor = Color(0xFF10B981).copy(alpha = 0.25f),
                    icon = Icons.Default.Check
                )

                // Partial
                StatBox(
                    label = "Partielles",
                    value = "${summary.partialCount}",
                    color = Color(0xFFD97706),
                    bg = Color(0xFFFEF3C7),
                    borderColor = Color(0xFFF59E0B).copy(alpha = 0.25f),
                    icon = Icons.Default.Check
                )

                // Wrong
                StatBox(
                    label = "Erreurs",
                    value = "${summary.wrongCount}",
                    color = Color(0xFFDC2626),
                    bg = Color(0xFFFEF2F2),
                    borderColor = Color(0xFFEF4444).copy(alpha = 0.25f),
                    icon = Icons.Default.Close
                )

                // Unanswered
                StatBox(
                    label = "Sans rép.",
                    value = "${summary.unansweredCount}",
                    color = Color(0xFF6B7280),
                    bg = Color(0xFFF3F4F6),
                    borderColor = Color(0xFF9CA3AF).copy(alpha = 0.25f),
                    icon = Icons.Default.HelpOutline
                )
            }
        }
    }
}

@Composable
fun StatBox(
    label: String,
    value: String,
    color: Color,
    bg: Color,
    borderColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bg,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier.width(78.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = color.copy(alpha = 0.15f),
                modifier = Modifier.size(24.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, fontWeight = FontWeight.Black, fontSize = 18.sp, color = color)
            Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = color.copy(alpha = 0.9f))
        }
    }
}

@Composable
fun QuestionCorrectionCard(result: QuestionScoreResult) {
    val q = result.question

    val borderColor = when {
        result.isFullyCorrect -> Color(0xFF10B981)
        result.isPartiallyCorrect -> Color(0xFFF59E0B)
        result.isWrong -> Color(0xFFEF4444)
        else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header Row: Question number & Score Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when {
                        result.isFullyCorrect -> Color(0xFFECFDF5)
                        result.isPartiallyCorrect -> Color(0xFFFEF3C7)
                        result.isWrong -> Color(0xFFFEF2F2)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    border = BorderStroke(
                        1.dp,
                        when {
                            result.isFullyCorrect -> Color(0xFF10B981).copy(alpha = 0.3f)
                            result.isPartiallyCorrect -> Color(0xFFF59E0B).copy(alpha = 0.3f)
                            result.isWrong -> Color(0xFFEF4444).copy(alpha = 0.3f)
                            else -> Color.Transparent
                        }
                    )
                ) {
                    Text(
                        text = "Question ${q.questionIndex}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = when {
                            result.isFullyCorrect -> Color(0xFF059669)
                            result.isPartiallyCorrect -> Color(0xFFD97706)
                            result.isWrong -> Color(0xFFDC2626)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when {
                        result.pointsEarned > 0 -> Color(0xFFECFDF5)
                        result.pointsEarned < 0 -> Color(0xFFFEF2F2)
                        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    }
                ) {
                    Text(
                        text = when {
                            result.pointsEarned > 0 -> "+${result.pointsEarned} pt"
                            result.pointsEarned < 0 -> "${result.pointsEarned} pt"
                            else -> "0 pt"
                        },
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = when {
                            result.pointsEarned > 0 -> Color(0xFF059669)
                            result.pointsEarned < 0 -> Color(0xFFDC2626)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Question Statement
            Text(
                text = q.questionText,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // User Answer Box
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = when {
                    result.isFullyCorrect -> Color(0xFFECFDF5)
                    result.isPartiallyCorrect -> Color(0xFFFEF3C7)
                    result.isWrong -> Color(0xFFFEF2F2)
                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Votre réponse : ",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (result.userSelection.isEmpty()) {
                            Text(
                                text = "Aucune réponse",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text(
                                text = result.userSelection.joinToString(", "),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = when {
                                    result.isFullyCorrect -> Color(0xFF059669)
                                    result.isPartiallyCorrect -> Color(0xFFD97706)
                                    else -> Color(0xFFDC2626)
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Corrigé officiel : ",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = q.correctAnswers.joinToString(", "),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF059669)
                        )
                    }
                }
            }

            // Explanation / Notes if available
            if (!q.explanation.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = q.explanation,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(10.dp),
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
