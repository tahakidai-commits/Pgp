package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.ui.theme.QuizError
import com.example.ui.theme.QuizErrorContainer
import com.example.ui.theme.QuizPrimary
import com.example.ui.theme.QuizSecondary
import com.example.ui.theme.QuizSuccess
import com.example.ui.theme.QuizSuccessContainer
import com.example.ui.theme.QuizWarning
import com.example.ui.viewmodel.QuizViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizPlayScreen(
    viewModel: QuizViewModel,
    onFinish: () -> Unit,
    onQuit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playState by viewModel.playState.collectAsState()
    val questions = playState.questions
    val currentIndex = playState.currentIndex
    val currentQuestion = questions.getOrNull(currentIndex)
    val userAnswers = playState.userAnswers

    var showExitDialog by remember { mutableStateOf(false) }
    var showGridSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()
    val scope = rememberCoroutineScope()

    BackHandler {
        showExitDialog = true
    }

    LaunchedEffect(playState.isCompleted) {
        if (playState.isCompleted) {
            onFinish()
        }
    }

    if (currentQuestion == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Chargement du quiz...")
        }
        return
    }

    val selectedAnswers = userAnswers[currentQuestion.id] ?: emptySet()
    val isRevealedInPractice = playState.isPracticeMode && playState.revealedQuestions.contains(currentQuestion.id)

    Scaffold(
        modifier = modifier.testTag("quiz_play_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = playState.quiz?.title ?: "Quiz",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (playState.isPracticeMode) MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = if (playState.isPracticeMode) "Mode Révision" else "Mode Examen",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (playState.isPracticeMode) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            val minutes = playState.timeElapsedSeconds / 60
                            val seconds = playState.timeElapsedSeconds % 60
                            Text(
                                text = String.format("%02d:%02d", minutes, seconds),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { showExitDialog = true },
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Quitter le quiz"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showGridSheet = true },
                        modifier = Modifier.testTag("grid_overview_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.GridView,
                            contentDescription = "Vue d'ensemble des questions"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                shadowElevation = 12.dp,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { viewModel.previousQuestion() },
                        enabled = currentIndex > 0,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("prev_question_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Précédent", fontWeight = FontWeight.SemiBold)
                    }

                    if (currentIndex == questions.size - 1) {
                        Button(
                            onClick = {
                                viewModel.finishQuiz()
                                onFinish()
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = QuizPrimary),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("finish_quiz_button")
                        ) {
                            Text("Terminer l'évaluation", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    } else {
                        Button(
                            onClick = { viewModel.nextQuestion() },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = QuizPrimary),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("next_question_button")
                        ) {
                            Text("Suivant", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Progress Bar at the top of the quiz screen with Remaining Questions & 40s Quiz Timer
            val totalQuestions = questions.size
            val currentNumber = currentIndex + 1
            val remainingQuestions = (totalQuestions - currentNumber).coerceAtLeast(0)
            val progress = if (totalQuestions > 0) currentNumber.toFloat() / totalQuestions else 0f
            val animatedProgress by animateFloatAsState(
                targetValue = progress,
                animationSpec = tween(durationMillis = 300),
                label = "quiz_progress"
            )

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quiz_progress_header"),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                tonalElevation = 1.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Top Progress Bar
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .testTag("quiz_progress_bar"),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    // Information Row: Question Counter, Remaining Questions, and 40s Timer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left: Question Count & Remaining Questions
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Question $currentNumber sur $totalQuestions",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                // Remaining questions badge
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (remainingQuestions == 0) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                    else MaterialTheme.colorScheme.secondaryContainer,
                                    modifier = Modifier.testTag("questions_remaining_badge")
                                ) {
                                    Text(
                                        text = if (remainingQuestions == 0) "Dernière question !"
                                        else "$remainingQuestions restante${if (remainingQuestions > 1) "s" else ""}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (remainingQuestions == 0) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                            .testTag("questions_remaining_text")
                                    )
                                }
                            }

                            val answeredCount = userAnswers.count { it.value.isNotEmpty() }
                            Text(
                                text = "$answeredCount répondue(s) • ${(progress * 100).toInt()}% • $remainingQuestions à faire",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Right: 40s Countdown Quiz Timer
                        val timerSeconds = playState.questionTimerSeconds
                        val timerMax = playState.maxQuestionTimerSeconds
                        val isPaused = playState.isTimerPaused
                        val timerColor = when {
                            timerSeconds <= 5 -> QuizError
                            timerSeconds <= 12 -> QuizWarning
                            else -> QuizPrimary
                        }

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = timerColor.copy(alpha = 0.12f),
                            border = BorderStroke(1.5.dp, timerColor),
                            modifier = Modifier
                                .clickable { viewModel.toggleTimerPause() }
                                .testTag("quiz_timer_40s")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Timer,
                                    contentDescription = if (isPaused) "Reprendre le chronomètre" else "Mettre en pause le chronomètre",
                                    modifier = Modifier.size(16.dp),
                                    tint = timerColor
                                )
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (isPaused) "Pause" else "${timerSeconds}s",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = timerColor
                                    )
                                    Text(
                                        text = "sur ${timerMax}s",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        color = timerColor.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }

                    // Low Timer Alert Banner (< 6s)
                    if (playState.questionTimerSeconds in 1..5 && !playState.isTimerPaused && playState.isTimerEnabled) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = QuizErrorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "⚠️ Attention : plus que ${playState.questionTimerSeconds}s pour cette question !",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = QuizError
                                )
                            }
                        }
                    } else if (playState.isTimerPaused) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "⏸️ Chronomètre 40s en pause (${playState.questionTimerSeconds}s)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "Reprendre",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.clickable { viewModel.toggleTimerPause() }
                                    )
                                    Text(
                                        text = "Réinitialiser 40s",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.clickable { viewModel.resetQuestionTimer() }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Scrollable Content for Question & Options
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Clinical Context or Case Background (e.g. Mr AL, Mr KAMESS)
                if (!currentQuestion.contextText.isNullOrBlank()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(18.dp)
                                    .padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = currentQuestion.contextText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                // Question Statement Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        val badgeBg = when (currentQuestion.type) {
                            QuestionType.TRUE_FALSE -> Color(0xFFE0F2FE)
                            QuestionType.MULTIPLE_CHOICE -> Color(0xFFEEF2FF)
                            QuestionType.SINGLE_CHOICE -> Color(0xFFFEF3C7)
                        }
                        val badgeColor = when (currentQuestion.type) {
                            QuestionType.TRUE_FALSE -> Color(0xFF0284C7)
                            QuestionType.MULTIPLE_CHOICE -> Color(0xFF4F46E5)
                            QuestionType.SINGLE_CHOICE -> Color(0xFFD97706)
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = badgeBg,
                            border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.25f))
                        ) {
                            Text(
                                text = when (currentQuestion.type) {
                                    QuestionType.TRUE_FALSE -> {
                                        when (currentQuestion.negativePoints) {
                                            0f -> "VRAI OU FAUX • +1 pt / 0 pt"
                                            0.5f -> "VRAI OU FAUX • +1 / -0,5 pt"
                                            1.0f -> "VRAI OU FAUX • +1 / -1 pt"
                                            else -> "VRAI OU FAUX • +${currentQuestion.positivePoints.toInt()} / -${currentQuestion.negativePoints} pt"
                                        }
                                    }
                                    QuestionType.MULTIPLE_CHOICE -> "QCM • Choisir ${currentQuestion.maxChoices} réponses"
                                    QuestionType.SINGLE_CHOICE -> "QCM • Choix Unique (+1 pt)"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = badgeColor,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = currentQuestion.questionText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 24.sp
                        )
                    }
                }

                // Options Section
                if (currentQuestion.type == QuestionType.TRUE_FALSE) {
                    TrueFalseOptionGroup(
                        selectedAnswers = selectedAnswers,
                        correctAnswers = currentQuestion.correctAnswers,
                        isRevealed = isRevealedInPractice,
                        onSelect = { option ->
                            if (!isRevealedInPractice) {
                                viewModel.selectOption(currentQuestion.id, option, isMultiple = false)
                            }
                        }
                    )
                } else {
                    MultipleChoiceOptionGroup(
                        options = currentQuestion.options,
                        selectedAnswers = selectedAnswers,
                        correctAnswers = currentQuestion.correctAnswers,
                        isRevealed = isRevealedInPractice,
                        isMultiple = currentQuestion.maxChoices > 1,
                        onSelect = { optionKey ->
                            if (!isRevealedInPractice) {
                                viewModel.selectOption(
                                    currentQuestion.id,
                                    optionKey,
                                    isMultiple = currentQuestion.maxChoices > 1
                                )
                            }
                        }
                    )
                }

                // Practice Mode: Check Answer Button & Explanation
                if (playState.isPracticeMode) {
                    if (!isRevealedInPractice) {
                        Button(
                            onClick = {
                                viewModel.revealCurrentInPractice(currentQuestion.id)
                            },
                            enabled = selectedAnswers.isNotEmpty(),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("validate_practice_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Text("Vérifier ma réponse", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        // Show Answer Explanation Card
                        val correctSet = currentQuestion.correctAnswers.map { it.trim().lowercase() }.toSet()
                        val userSet = selectedAnswers.map { it.trim().lowercase() }.toSet()
                        val isFullyCorrect = userSet == correctSet

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isFullyCorrect) QuizSuccessContainer.copy(alpha = 0.6f)
                                else QuizErrorContainer.copy(alpha = 0.6f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isFullyCorrect) Icons.Default.Check else Icons.Default.Close,
                                        contentDescription = null,
                                        tint = if (isFullyCorrect) QuizSuccess else QuizError,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isFullyCorrect) "Bonne réponse !" else "Mauvaise réponse",
                                        fontWeight = FontWeight.Bold,
                                        color = if (isFullyCorrect) QuizSuccess else QuizError
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "Réponse attendue : ${currentQuestion.correctAnswers.joinToString(", ")}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                if (!currentQuestion.explanation.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = currentQuestion.explanation,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Modal Sheet for Question Palette Grid
    if (showGridSheet) {
        ModalBottomSheet(
            onDismissRequest = { showGridSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Vue d'ensemble des questions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Touchez une question pour y accéder directement.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 48.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp)
                ) {
                    itemsIndexed(questions) { idx, q ->
                        val isAnswered = (userAnswers[q.id]?.isNotEmpty() == true)
                        val isCurrent = idx == currentIndex

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    when {
                                        isCurrent -> MaterialTheme.colorScheme.primary
                                        isAnswered -> MaterialTheme.colorScheme.primaryContainer
                                        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    }
                                )
                                .clickable {
                                    viewModel.goToQuestion(idx)
                                    scope.launch {
                                        sheetState.hide()
                                        showGridSheet = false
                                    }
                                }
                        ) {
                            Text(
                                text = "${idx + 1}",
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                color = when {
                                    isCurrent -> MaterialTheme.colorScheme.onPrimary
                                    isAnswered -> MaterialTheme.colorScheme.onPrimaryContainer
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Exit Confirmation Dialog
    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text("Quitter le quiz ?") },
            text = { Text("Votre progression en cours ne sera pas enregistrée si vous quittez maintenant.") },
            confirmButton = {
                Button(
                    onClick = {
                        showExitDialog = false
                        viewModel.resetPlayState()
                        onQuit()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Quitter")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitDialog = false }) {
                    Text("Continuer le quiz")
                }
            }
        )
    }
}

@Composable
fun TrueFalseOptionGroup(
    selectedAnswers: Set<String>,
    correctAnswers: List<String>,
    isRevealed: Boolean,
    onSelect: (String) -> Unit
) {
    val normalizedCorrect = correctAnswers.map { it.trim().uppercase() }.toSet()
    val isTrueSelected = selectedAnswers.any { 
        it.trim().equals("VRAI", ignoreCase = true) || it.trim().equals("A", ignoreCase = true) || it.trim().equals("V", ignoreCase = true) 
    }
    val isFalseSelected = selectedAnswers.any { 
        it.trim().equals("FAUX", ignoreCase = true) || it.trim().equals("B", ignoreCase = true) || it.trim().equals("F", ignoreCase = true) 
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // VRAI Card (A)
        OptionButtonCard(
            label = "VRAI (A)",
            isSelected = isTrueSelected,
            isRevealed = isRevealed,
            isCorrectAnswer = normalizedCorrect.contains("VRAI") || normalizedCorrect.contains("A") || normalizedCorrect.contains("V"),
            onClick = { onSelect("VRAI") },
            modifier = Modifier
                .weight(1f)
                .testTag("option_vrai")
        )

        // FAUX Card (B)
        OptionButtonCard(
            label = "FAUX (B)",
            isSelected = isFalseSelected,
            isRevealed = isRevealed,
            isCorrectAnswer = normalizedCorrect.contains("FAUX") || normalizedCorrect.contains("B") || normalizedCorrect.contains("F"),
            onClick = { onSelect("FAUX") },
            modifier = Modifier
                .weight(1f)
                .testTag("option_faux")
        )
    }
}

@Composable
fun OptionButtonCard(
    label: String,
    isSelected: Boolean,
    isRevealed: Boolean,
    isCorrectAnswer: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor = when {
        isRevealed && isCorrectAnswer -> Color(0xFFECFDF5)
        isRevealed && isSelected && !isCorrectAnswer -> Color(0xFFFEF2F2)
        isSelected -> Color(0xFFEFF6FF)
        else -> MaterialTheme.colorScheme.surface
    }

    val borderColor = when {
        isRevealed && isCorrectAnswer -> Color(0xFF10B981)
        isRevealed && isSelected && !isCorrectAnswer -> Color(0xFFEF4444)
        isSelected -> QuizPrimary
        else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
    }

    Card(
        modifier = modifier
            .height(72.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = BorderStroke(if (isSelected || isRevealed) 2.dp else 1.dp, borderColor),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) 3.dp else 1.dp
        )
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isRevealed && isCorrectAnswer) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFD1FAE5),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                } else if (isRevealed && isSelected && !isCorrectAnswer) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFFEE2E2),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Text(
                    text = label,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = when {
                        isRevealed && isCorrectAnswer -> Color(0xFF059669)
                        isRevealed && isSelected && !isCorrectAnswer -> Color(0xFFDC2626)
                        isSelected -> Color(0xFF4F46E5)
                        else -> MaterialTheme.colorScheme.onSurface
                    }
                )
            }
        }
    }
}

@Composable
fun MultipleChoiceOptionGroup(
    options: List<String>,
    selectedAnswers: Set<String>,
    correctAnswers: List<String>,
    isRevealed: Boolean,
    isMultiple: Boolean,
    onSelect: (String) -> Unit
) {
    val normalizedCorrect = correctAnswers.map { it.trim().lowercase() }.toSet()

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        options.forEachIndexed { index, optionText ->
            // Match key either by prefix like "a" or full text
            val optionKey = when {
                optionText.startsWith("a-", ignoreCase = true) || optionText.startsWith("a)", ignoreCase = true) || optionText.startsWith("a.", ignoreCase = true) -> "a"
                optionText.startsWith("b-", ignoreCase = true) || optionText.startsWith("b)", ignoreCase = true) || optionText.startsWith("b.", ignoreCase = true) -> "b"
                optionText.startsWith("c-", ignoreCase = true) || optionText.startsWith("c)", ignoreCase = true) || optionText.startsWith("c.", ignoreCase = true) -> "c"
                optionText.startsWith("d-", ignoreCase = true) || optionText.startsWith("d)", ignoreCase = true) || optionText.startsWith("d.", ignoreCase = true) -> "d"
                optionText.startsWith("e-", ignoreCase = true) || optionText.startsWith("e)", ignoreCase = true) || optionText.startsWith("e.", ignoreCase = true) -> "e"
                else -> ('a' + index).toString()
            }

            val isSelected = selectedAnswers.any { it.trim().equals(optionKey, ignoreCase = true) || it.trim().equals(optionText, ignoreCase = true) }
            val isCorrect = normalizedCorrect.contains(optionKey) || normalizedCorrect.contains(optionText.trim().lowercase())

            val backgroundColor = when {
                isRevealed && isCorrect -> Color(0xFFECFDF5)
                isRevealed && isSelected && !isCorrect -> Color(0xFFFEF2F2)
                isSelected -> Color(0xFFEFF6FF)
                else -> MaterialTheme.colorScheme.surface
            }

            val borderColor = when {
                isRevealed && isCorrect -> Color(0xFF10B981)
                isRevealed && isSelected && !isCorrect -> Color(0xFFEF4444)
                isSelected -> QuizPrimary
                else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(optionKey) }
                    .testTag("option_$optionKey"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = backgroundColor),
                border = BorderStroke(if (isSelected || isRevealed) 2.dp else 1.dp, borderColor),
                elevation = CardDefaults.cardElevation(
                    defaultElevation = if (isSelected) 3.dp else 1.dp
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = when {
                            isRevealed && isCorrect -> Color(0xFF10B981)
                            isRevealed && isSelected && !isCorrect -> Color(0xFFEF4444)
                            isSelected -> QuizPrimary
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = optionKey.uppercase(),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = if (isSelected || (isRevealed && isCorrect)) Color.White
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Text(
                        text = optionText.replace(Regex("^[a-eA-E][\\-\\)]\\s*"), ""),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 22.sp,
                        modifier = Modifier.weight(1f)
                    )

                    if (isRevealed && isCorrect) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFD1FAE5),
                            modifier = Modifier.size(26.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Bonne réponse",
                                    tint = Color(0xFF059669),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    } else if (isRevealed && isSelected && !isCorrect) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFFEE2E2),
                            modifier = Modifier.size(26.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Mauvaise réponse",
                                    tint = Color(0xFFDC2626),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    } else if (isMultiple) {
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { onSelect(optionKey) },
                            colors = CheckboxDefaults.colors(
                                checkedColor = QuizPrimary
                            )
                        )
                    }
                }
            }
        }
    }
}
