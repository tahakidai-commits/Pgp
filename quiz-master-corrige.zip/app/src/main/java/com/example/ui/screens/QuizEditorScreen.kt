package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.ui.theme.QuizPrimary
import com.example.ui.theme.QuizSecondary
import com.example.ui.theme.QuizSuccess
import com.example.ui.viewmodel.QuizViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizEditorScreen(
    viewModel: QuizViewModel,
    onQuizSaved: (Long) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Manuel, 1: Import Texte

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Mes Cours") }

    val manualQuestions = remember { mutableStateListOf<QuestionEntity>() }
    var showAddQuestionDialog by remember { mutableStateOf(false) }

    // Text import state
    var rawImportText by remember { mutableStateOf("") }
    var parsedQuestionsCount by remember { mutableIntStateOf(0) }
    var parsedQuestionsPreview by remember { mutableStateOf<List<QuestionEntity>>(emptyList()) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        modifier = modifier.testTag("quiz_editor_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Créer un Quiz",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour"
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            val questionsToSave = if (selectedTab == 0) {
                                manualQuestions.toList()
                            } else {
                                parsedQuestionsPreview
                            }

                            if (title.isBlank()) {
                                errorMessage = "Veuillez entrer un titre pour le quiz."
                                return@Button
                            }
                            if (questionsToSave.isEmpty()) {
                                errorMessage = "Veuillez ajouter au moins une question."
                                return@Button
                            }

                            viewModel.createQuizWithQuestions(
                                title = title,
                                description = description,
                                category = category,
                                questions = questionsToSave,
                                onSuccess = onQuizSaved
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = QuizPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("save_quiz_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Enregistrer")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Row
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Formulaire Manuel") },
                    icon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Import Rapide (Texte)") },
                    icon = { Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Error banner if any
                if (errorMessage != null) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                // General Quiz Info Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Informations Générales",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )

                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it; errorMessage = null },
                                label = { Text("Titre du quiz *") },
                                placeholder = { Text("ex: Pharmacologie TD 2, Anatomie...") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("quiz_title_input")
                            )

                            OutlinedTextField(
                                value = category,
                                onValueChange = { category = it },
                                label = { Text("Matière / Catégorie") },
                                placeholder = { Text("ex: Pharmacologie, Toxicologie, Gestion Logistique...") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Gestion Logistique", "Pharmacologie", "Toxicologie").forEach { cat ->
                                    FilterChip(
                                        selected = category == cat,
                                        onClick = { category = cat },
                                        label = { Text(cat, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = description,
                                onValueChange = { description = it },
                                label = { Text("Description (optionnelle)") },
                                placeholder = { Text("ex: 20 questions sur la pharmacocinétique...") },
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 3
                            )
                        }
                    }
                }

                if (selectedTab == 0) {
                    // MANUAL TAB CONTENT
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Questions (${manualQuestions.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )

                            Button(
                                onClick = { showAddQuestionDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("add_question_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Ajouter une question")
                            }
                        }
                    }

                    if (manualQuestions.isEmpty()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "Aucune question ajoutée",
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Cliquez sur « Ajouter une question » ci-dessus ou utilisez l'onglet « Import Rapide » pour coller une série de questions.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    } else {
                        itemsIndexed(manualQuestions) { index, question ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${index + 1}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = question.questionText,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Réponse : ${question.correctAnswers.joinToString(", ")} (${when (question.type) {
                                                QuestionType.TRUE_FALSE -> "Vrai/Faux"
                                                QuestionType.MULTIPLE_CHOICE -> "QCM"
                                                QuestionType.SINGLE_CHOICE -> "Choix unique"
                                            }})",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = QuizSuccess
                                        )
                                    }

                                    IconButton(
                                        onClick = { manualQuestions.removeAt(index) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Supprimer",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // RAPID TEXT IMPORT TAB
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Coller vos questions",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )

                                    TextButton(
                                        onClick = {
                                            rawImportText = """
1. La pharmacologie étudie les interactions entre substances et organismes vivants.
Réponse: VRAI

2. Indiquer les deux voies d'administration parentérales :
a- Voie orale
b- Voie intraveineuse
c- Voie sous-cutanée
d- Voie sublinguale
Réponse: b, c
Explication: L'intraveineuse et la sous-cutanée sont des voies injectables parentérales.

3. Le paracétamol a des propriétés anti-inflammatoires majeures.
Réponse: FAUX
                                            """.trimIndent()
                                            val parsed = viewModel.parseRawTextIntoQuestions(rawImportText)
                                            parsedQuestionsPreview = parsed
                                            parsedQuestionsCount = parsed.size
                                        }
                                    ) {
                                        Text("Insérer un exemple")
                                    }
                                }

                                Text(
                                    text = "Collez des questions numérotées avec « Réponse: » pour les importer automatiquement.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                OutlinedTextField(
                                    value = rawImportText,
                                    onValueChange = { text ->
                                        rawImportText = text
                                        val parsed = viewModel.parseRawTextIntoQuestions(text)
                                        parsedQuestionsPreview = parsed
                                        parsedQuestionsCount = parsed.size
                                    },
                                    placeholder = {
                                        Text("1. Votre question ici...\na- Option 1\nb- Option 2\nRéponse: a\n\n2. Une question vrai ou faux...\nRéponse: VRAI")
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(220.dp)
                                        .testTag("raw_text_import_field")
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (parsedQuestionsCount > 0) QuizSuccess.copy(alpha = 0.15f)
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Text(
                                            text = "$parsedQuestionsCount question(s) détectée(s)",
                                            color = if (parsedQuestionsCount > 0) QuizSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (parsedQuestionsPreview.isNotEmpty()) {
                        item {
                            Text(
                                text = "Aperçu des questions importées :",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }

                        itemsIndexed(parsedQuestionsPreview) { idx, q ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${idx + 1}",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = q.questionText,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Réponse(s) : ${q.correctAnswers.joinToString(", ")} • Type : ${q.type.name}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = QuizSuccess
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(48.dp))
                }
            }
        }
    }

    // Modal Dialog to Add a Question manually
    if (showAddQuestionDialog) {
        AddQuestionDialog(
            onDismiss = { showAddQuestionDialog = false },
            onAdd = { question ->
                manualQuestions.add(question)
                showAddQuestionDialog = false
            }
        )
    }
}

@Composable
fun AddQuestionDialog(
    onDismiss: () -> Unit,
    onAdd: (QuestionEntity) -> Unit
) {
    var qText by remember { mutableStateOf("") }
    var contextText by remember { mutableStateOf("") }
    var qType by remember { mutableStateOf(QuestionType.TRUE_FALSE) }
    var explanation by remember { mutableStateOf("") }

    // Options for QCM
    var optA by remember { mutableStateOf("") }
    var optB by remember { mutableStateOf("") }
    var optC by remember { mutableStateOf("") }
    var optD by remember { mutableStateOf("") }

    // Correct selections
    var trueFalseAnswer by remember { mutableStateOf("VRAI") }
    var qcmAnswerA by remember { mutableStateOf(false) }
    var qcmAnswerB by remember { mutableStateOf(false) }
    var qcmAnswerC by remember { mutableStateOf(false) }
    var qcmAnswerD by remember { mutableStateOf(false) }

    var dialogError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Nouvelle Question",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (dialogError != null) {
                    item {
                        Text(
                            text = dialogError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }

                item {
                    Text("Type de question :", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = qType == QuestionType.TRUE_FALSE,
                            onClick = { qType = QuestionType.TRUE_FALSE },
                            label = { Text("Vrai / Faux") }
                        )
                        FilterChip(
                            selected = qType == QuestionType.MULTIPLE_CHOICE,
                            onClick = { qType = QuestionType.MULTIPLE_CHOICE },
                            label = { Text("Choix Multiples (QCM)") }
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = qText,
                        onValueChange = { qText = it; dialogError = null },
                        label = { Text("Énoncé de la question *") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }

                item {
                    OutlinedTextField(
                        value = contextText,
                        onValueChange = { contextText = it },
                        label = { Text("Mise en situation / Cas clinique (optionnel)") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }

                if (qType == QuestionType.TRUE_FALSE) {
                    item {
                        Text("Bonne réponse :", style = MaterialTheme.typography.labelMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = trueFalseAnswer == "VRAI",
                                onClick = { trueFalseAnswer = "VRAI" }
                            )
                            Text("VRAI")
                            Spacer(modifier = Modifier.width(16.dp))
                            RadioButton(
                                selected = trueFalseAnswer == "FAUX",
                                onClick = { trueFalseAnswer = "FAUX" }
                            )
                            Text("FAUX")
                        }
                    }
                } else {
                    item {
                        Text("Options et réponses correctes :", style = MaterialTheme.typography.labelMedium)
                    }

                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = qcmAnswerA, onCheckedChange = { qcmAnswerA = it })
                            OutlinedTextField(
                                value = optA,
                                onValueChange = { optA = it },
                                label = { Text("Option A") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = qcmAnswerB, onCheckedChange = { qcmAnswerB = it })
                            OutlinedTextField(
                                value = optB,
                                onValueChange = { optB = it },
                                label = { Text("Option B") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = qcmAnswerC, onCheckedChange = { qcmAnswerC = it })
                            OutlinedTextField(
                                value = optC,
                                onValueChange = { optC = it },
                                label = { Text("Option C") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = qcmAnswerD, onCheckedChange = { qcmAnswerD = it })
                            OutlinedTextField(
                                value = optD,
                                onValueChange = { optD = it },
                                label = { Text("Option D") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = explanation,
                        onValueChange = { explanation = it },
                        label = { Text("Explication / Justification du corrigé") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (qText.isBlank()) {
                        dialogError = "L'énoncé est obligatoire."
                        return@Button
                    }

                    if (qType == QuestionType.TRUE_FALSE) {
                        onAdd(
                            QuestionEntity(
                                quizId = 0,
                                questionIndex = 1,
                                contextText = contextText.ifBlank { null },
                                questionText = qText,
                                type = QuestionType.TRUE_FALSE,
                                options = listOf("VRAI", "FAUX"),
                                correctAnswers = listOf(trueFalseAnswer),
                                explanation = explanation.ifBlank { null },
                                positivePoints = 1.0f,
                                negativePoints = 0.5f,
                                maxChoices = 1
                            )
                        )
                    } else {
                        val opts = mutableListOf<String>()
                        val correct = mutableListOf<String>()
                        if (optA.isNotBlank()) {
                            opts.add("a- $optA")
                            if (qcmAnswerA) correct.add("a")
                        }
                        if (optB.isNotBlank()) {
                            opts.add("b- $optB")
                            if (qcmAnswerB) correct.add("b")
                        }
                        if (optC.isNotBlank()) {
                            opts.add("c- $optC")
                            if (qcmAnswerC) correct.add("c")
                        }
                        if (optD.isNotBlank()) {
                            opts.add("d- $optD")
                            if (qcmAnswerD) correct.add("d")
                        }

                        if (opts.size < 2) {
                            dialogError = "Veuillez renseigner au moins 2 options."
                            return@Button
                        }
                        if (correct.isEmpty()) {
                            dialogError = "Veuillez cocher au moins une bonne réponse."
                            return@Button
                        }

                        onAdd(
                            QuestionEntity(
                                quizId = 0,
                                questionIndex = 1,
                                contextText = contextText.ifBlank { null },
                                questionText = qText,
                                type = QuestionType.MULTIPLE_CHOICE,
                                options = opts,
                                correctAnswers = correct,
                                explanation = explanation.ifBlank { null },
                                positivePoints = 1.0f,
                                negativePoints = 0.0f,
                                maxChoices = correct.size
                            )
                        )
                    }
                }
            ) {
                Text("Ajouter")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler")
            }
        }
    )
}
