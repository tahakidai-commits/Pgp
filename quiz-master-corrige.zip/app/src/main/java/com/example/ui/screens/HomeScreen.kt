package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.QuizEntity
import com.example.ui.theme.LightBackground
import com.example.ui.theme.LightBorder
import com.example.ui.theme.LightBorderSubtle
import com.example.ui.theme.LightMutedText
import com.example.ui.theme.PastelBlueBg
import com.example.ui.theme.PastelBlueIcon
import com.example.ui.theme.PastelGreenBg
import com.example.ui.theme.PastelGreenIcon
import com.example.ui.theme.PastelOrangeBg
import com.example.ui.theme.PastelOrangeIcon
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkIcon
import com.example.ui.theme.PastelPurpleBg
import com.example.ui.theme.PastelPurpleIcon
import com.example.ui.theme.PastelTealBg
import com.example.ui.theme.PastelTealIcon
import com.example.ui.theme.PrimaryHeroBrush
import com.example.ui.theme.QuizPrimary
import com.example.ui.theme.QuizSecondary
import com.example.ui.theme.QuizSuccess
import com.example.ui.theme.TextDark
import com.example.ui.viewmodel.QuizViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: QuizViewModel,
    onStartQuiz: (QuizEntity, Boolean) -> Unit, // quiz, practiceMode
    onCreateQuiz: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenDoctorDetail: (QuizEntity?) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val quizzes by viewModel.allQuizzes.collectAsState()
    val attempts by viewModel.allAttempts.collectAsState()

    var quizToDelete by remember { mutableStateOf<QuizEntity?>(null) }
    var selectedQuizForMode by remember { mutableStateOf<QuizEntity?>(null) }
    var selectedCategory by remember { mutableStateOf("Tous") }
    var searchQuery by remember { mutableStateOf("") }
    var currentNavTab by remember { mutableIntStateOf(0) }

    val builtInQuizzes = quizzes.filter { it.isBuiltIn }
    val customQuizzes = quizzes.filter { !it.isBuiltIn }

    val baseCategories = listOf("Tous", "Matière Première Galénique", "Toxicologie", "Pharmacologie", "Gestion Logistique", "Mes Quiz")
    val otherCategories = quizzes
        .map { it.category.trim() }
        .filter { it.isNotBlank() && it !in listOf("Matière Première Galénique", "Gestion Logistique", "Pharmacologie", "Toxicologie", "Mes Quiz") }
        .distinct()
    val allCategoryFilters = baseCategories + otherCategories

    val filteredQuizzes = remember(quizzes, selectedCategory, searchQuery) {
        quizzes.filter { quiz ->
            val matchesCategory = when (selectedCategory) {
                "Tous" -> true
                "Mes Quiz" -> !quiz.isBuiltIn
                else -> quiz.category.equals(selectedCategory, ignoreCase = true)
            }
            val matchesSearch = if (searchQuery.isBlank()) true else {
                quiz.title.contains(searchQuery, ignoreCase = true) ||
                quiz.description.contains(searchQuery, ignoreCase = true) ||
                quiz.category.contains(searchQuery, ignoreCase = true)
            }
            matchesCategory && matchesSearch
        }
    }

    Scaffold(
        modifier = modifier
            .background(LightBackground)
            .testTag("home_screen"),
        topBar = {
            // Medical Top Header matching reference image: Avatar + "Bonjour, Ornela 👋" + Notification Bell & History
            Surface(
                color = Color.White,
                border = BorderStroke(1.dp, LightBorderSubtle)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.img_user_ornela),
                            contentDescription = "Photo de profil Ornela",
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Bonjour,",
                                style = MaterialTheme.typography.bodySmall,
                                color = LightMutedText,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "Ornela 👋",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextDark,
                                fontSize = 17.sp
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Circular Notification button with unread orange dot
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, LightBorder),
                            modifier = Modifier
                                .size(42.dp)
                                .clickable { onOpenDoctorDetail(builtInQuizzes.firstOrNull()) }
                                .testTag("notification_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = TextDark,
                                    modifier = Modifier.size(20.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(top = 9.dp, end = 9.dp)
                                        .size(8.dp)
                                        .background(Color(0xFFF97316), CircleShape)
                                )
                            }
                        }

                        // Circular History button
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, LightBorder),
                            modifier = Modifier.size(42.dp)
                        ) {
                            IconButton(onClick = onOpenHistory, modifier = Modifier.testTag("history_button")) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = "Historique des scores",
                                    tint = TextDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            // Modern Floating/Docked Medical Bottom Navigation Bar matching reference image
            Surface(
                color = Color.White,
                shadowElevation = 8.dp,
                border = BorderStroke(1.dp, LightBorderSubtle)
            ) {
                NavigationBar(
                    containerColor = Color.White,
                    contentColor = QuizPrimary,
                    tonalElevation = 0.dp
                ) {
                    NavigationBarItem(
                        selected = currentNavTab == 0,
                        onClick = { currentNavTab = 0; selectedCategory = "Tous" },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Accueil") },
                        label = { Text("Accueil", fontSize = 11.sp, fontWeight = if (currentNavTab == 0) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QuizPrimary,
                            selectedTextColor = QuizPrimary,
                            unselectedIconColor = LightMutedText,
                            unselectedTextColor = LightMutedText,
                            indicatorColor = Color(0xFFEFF6FF)
                        )
                    )
                    NavigationBarItem(
                        selected = currentNavTab == 1,
                        onClick = {
                            currentNavTab = 1
                            onOpenDoctorDetail(builtInQuizzes.firstOrNull())
                        },
                        icon = { Icon(Icons.Default.DateRange, contentDescription = "Rendez-vous") },
                        label = { Text("Rendez-vous", fontSize = 11.sp, fontWeight = if (currentNavTab == 1) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QuizPrimary,
                            selectedTextColor = QuizPrimary,
                            unselectedIconColor = LightMutedText,
                            unselectedTextColor = LightMutedText,
                            indicatorColor = Color(0xFFEFF6FF)
                        )
                    )
                    NavigationBarItem(
                        selected = currentNavTab == 2,
                        onClick = {
                            currentNavTab = 2
                            onOpenDoctorDetail(builtInQuizzes.firstOrNull())
                        },
                        icon = { Icon(Icons.Default.Forum, contentDescription = "Messages") },
                        label = { Text("Messages", fontSize = 11.sp, fontWeight = if (currentNavTab == 2) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QuizPrimary,
                            selectedTextColor = QuizPrimary,
                            unselectedIconColor = LightMutedText,
                            unselectedTextColor = LightMutedText,
                            indicatorColor = Color(0xFFEFF6FF)
                        )
                    )
                    NavigationBarItem(
                        selected = currentNavTab == 3,
                        onClick = {
                            currentNavTab = 3
                            onOpenHistory()
                        },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profil") },
                        label = { Text("Profil", fontSize = 11.sp, fontWeight = if (currentNavTab == 3) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QuizPrimary,
                            selectedTextColor = QuizPrimary,
                            unselectedIconColor = LightMutedText,
                            unselectedTextColor = LightMutedText,
                            indicatorColor = Color(0xFFEFF6FF)
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCreateQuiz,
                containerColor = QuizPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("create_quiz_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Ajouter un quiz")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Nouveau Quiz", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(LightBackground)
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Hero Blue Banner Card with Doctor Hero Image
            item {
                HeroStatsCard(
                    attemptCount = attempts.size,
                    avgScore = if (attempts.isNotEmpty()) {
                        val total = attempts.map { (it.score / it.maxScore) * 100f }.sum()
                        total / attempts.size
                    } else null,
                    onOpenHistory = onOpenHistory,
                    onTakeAction = {
                        val featured = builtInQuizzes.firstOrNull { it.title.contains("Toxicologie", ignoreCase = true) }
                            ?: builtInQuizzes.firstOrNull()
                        if (featured != null) {
                            selectedQuizForMode = featured
                        } else {
                            onOpenDoctorDetail(null)
                        }
                    }
                )
            }

            // 2. 4 Quick Action Pastel Squircle Buttons (Rendez-vous, Médicaments, Dossier médical, Consultation)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    QuickActionItem(
                        icon = Icons.Default.DateRange,
                        label = "Rendez-vous",
                        bgColor = PastelBlueBg,
                        iconColor = PastelBlueIcon,
                        onClick = { onOpenDoctorDetail(builtInQuizzes.firstOrNull()) }
                    )
                    QuickActionItem(
                        icon = Icons.Default.Medication,
                        label = "Médicaments",
                        bgColor = PastelGreenBg,
                        iconColor = PastelGreenIcon,
                        onClick = { selectedCategory = "Pharmacologie" }
                    )
                    QuickActionItem(
                        icon = Icons.Default.Description,
                        label = "Dossier médical",
                        bgColor = Color(0xFFDBEAFE),
                        iconColor = Color(0xFF1E6BFF),
                        onClick = { selectedCategory = "Toxicologie" }
                    )
                    QuickActionItem(
                        icon = Icons.Default.Forum,
                        label = "Consultation",
                        bgColor = PastelTealBg,
                        iconColor = PastelTealIcon,
                        onClick = { onOpenDoctorDetail(builtInQuizzes.firstOrNull()) }
                    )
                }
            }

            // 3. "Nos services" Section with 3x2 Grid and "Voir tout"
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Nos services",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextDark,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Voir tout",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = QuizPrimary,
                            modifier = Modifier
                                .clickable { selectedCategory = "Tous"; searchQuery = "" }
                                .padding(4.dp)
                        )
                    }

                    // Row 1 of services
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ServiceCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.MedicalServices,
                            title = "Médecine générale",
                            bgColor = PastelBlueBg,
                            iconColor = PastelBlueIcon,
                            onClick = { onOpenDoctorDetail(builtInQuizzes.firstOrNull()) }
                        )
                        ServiceCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.ChildCare,
                            title = "Pédiatrie",
                            bgColor = PastelTealBg,
                            iconColor = PastelTealIcon,
                            onClick = { selectedCategory = "Gestion Logistique" }
                        )
                        ServiceCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Science,
                            title = "Gynécologie",
                            bgColor = PastelPinkBg,
                            iconColor = PastelPinkIcon,
                            onClick = { selectedCategory = "Toxicologie" }
                        )
                    }

                    // Row 2 of services
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ServiceCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Spa,
                            title = "Galénique",
                            bgColor = Color(0xFFFEF3C7),
                            iconColor = Color(0xFFD97706),
                            onClick = { selectedCategory = "Matière Première Galénique" }
                        )
                        ServiceCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Favorite,
                            title = "Cardiologie",
                            bgColor = Color(0xFFFEE2E2),
                            iconColor = Color(0xFFEF4444),
                            onClick = { selectedCategory = "Tous" }
                        )
                        ServiceCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.LocalShipping,
                            title = "Laboratoire",
                            bgColor = PastelPurpleBg,
                            iconColor = PastelPurpleIcon,
                            onClick = { selectedCategory = "Mes Quiz" }
                        )
                    }
                }
            }

            // 4. "Suivez vos traitements / révisions" Tracker Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenHistory() },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, LightBorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFEFF6FF),
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Medication,
                                    contentDescription = null,
                                    tint = QuizPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Suivez vos révisions & scores",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextDark
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (attempts.isNotEmpty()) {
                                    val avg = (attempts.map { (it.score / it.maxScore) * 100f }.sum() / attempts.size).toInt()
                                    "${attempts.size} test(s) terminé(s) • Moyenne: $avg%"
                                } else {
                                    "Recevez des rappels et ne manquez aucune évaluation."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = LightMutedText
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // 5. Search & Category Filtering Bar
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Search bar
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Rechercher un quiz (titre, sujet, notion...)") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = LightMutedText
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Effacer la recherche"
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = QuizPrimary,
                            unfocusedBorderColor = LightBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_quiz_input")
                    )

                    // Header for category filters
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = null,
                                tint = QuizPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Matières & Catégories",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextDark
                            )
                        }

                        if (selectedCategory != "Tous" || searchQuery.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    selectedCategory = "Tous"
                                    searchQuery = ""
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Réinitialiser", style = MaterialTheme.typography.labelSmall, color = QuizPrimary)
                            }
                        }
                    }

                    // Filter Chips Row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("category_filter_row")
                    ) {
                        items(allCategoryFilters) { cat ->
                            val count = when (cat) {
                                "Tous" -> quizzes.size
                                "Mes Quiz" -> customQuizzes.size
                                else -> quizzes.count { it.category.equals(cat, ignoreCase = true) }
                            }
                            CategoryFilterChipItem(
                                category = cat,
                                count = count,
                                isSelected = selectedCategory == cat,
                                onClick = { selectedCategory = cat }
                            )
                        }
                    }
                }
            }

            // Quizzes List: Organized sections when "Tous" without search, or filtered list
            if (selectedCategory == "Tous" && searchQuery.isBlank()) {
                // Section 0: Matière Première Galénique (TD PGP1 2024 & Cours)
                val galQuizzes = builtInQuizzes.filter { it.category == "Matière Première Galénique" }
                if (galQuizzes.isNotEmpty()) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp, bottom = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Spa,
                                    contentDescription = null,
                                    tint = Color(0xFFD97706),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Matière Première Galénique (TD & Support)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFFEF3C7)
                            ) {
                                Text(
                                    text = "${galQuizzes.size} quiz",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFD97706),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    items(galQuizzes, key = { it.id }) { quiz ->
                        QuizCardItem(
                            quiz = quiz,
                            onPlayClick = { selectedQuizForMode = quiz },
                            onDeleteClick = null
                        )
                    }
                }

                // Section 1: Gestion Logistique & Produits de Santé
                val logQuizzes = builtInQuizzes.filter { it.category == "Gestion Logistique" }
                if (logQuizzes.isNotEmpty()) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp, bottom = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.LocalShipping,
                                    contentDescription = null,
                                    tint = Color(0xFF0D9488),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Gestion des Produits de Santé & Logistique",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFCCFBF1)
                            ) {
                                Text(
                                    text = "${logQuizzes.size} quiz",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0D9488),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    items(logQuizzes, key = { it.id }) { quiz ->
                        QuizCardItem(
                            quiz = quiz,
                            onPlayClick = { selectedQuizForMode = quiz },
                            onDeleteClick = null
                        )
                    }
                }

                // Section 2: Pharmacologie
                val pharmaQuizzes = builtInQuizzes.filter { it.category == "Pharmacologie" }
                if (pharmaQuizzes.isNotEmpty()) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp, bottom = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = Color(0xFF6366F1),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "TD Pharmacologie (2025-2026)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFEEF2FF)
                            ) {
                                Text(
                                    text = "${pharmaQuizzes.size} quiz",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF6366F1),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    items(pharmaQuizzes, key = { it.id }) { quiz ->
                        QuizCardItem(
                            quiz = quiz,
                            onPlayClick = { selectedQuizForMode = quiz },
                            onDeleteClick = null
                        )
                    }
                }

                // Section 3: Toxicologie
                val toxQuizzes = builtInQuizzes.filter { it.category == "Toxicologie" }
                if (toxQuizzes.isNotEmpty()) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp, bottom = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Science,
                                    contentDescription = null,
                                    tint = Color(0xFF0EA5E9),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Toxicologie PGP1 (TD & Évaluations)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFE0F2FE)
                            ) {
                                Text(
                                    text = "${toxQuizzes.size} quiz",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0EA5E9),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    items(toxQuizzes, key = { it.id }) { quiz ->
                        QuizCardItem(
                            quiz = quiz,
                            onPlayClick = { selectedQuizForMode = quiz },
                            onDeleteClick = null
                        )
                    }
                }

                // Section 4: Other built-in if any
                val otherBuiltIn = builtInQuizzes.filter { 
                    it.category != "Pharmacologie" && it.category != "Toxicologie" && it.category != "Gestion Logistique" 
                }
                if (otherBuiltIn.isNotEmpty()) {
                    items(otherBuiltIn, key = { it.id }) { quiz ->
                        QuizCardItem(
                            quiz = quiz,
                            onPlayClick = { selectedQuizForMode = quiz },
                            onDeleteClick = null
                        )
                    }
                }

                // Section 5: User-Created Custom Quizzes
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp, bottom = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = Color(0xFF8B5CF6),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Mes Quiz Personnalisés",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "${customQuizzes.size} quiz",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (customQuizzes.isEmpty()) {
                    item {
                        EmptyCustomQuizCard(onCreateQuiz = onCreateQuiz)
                    }
                } else {
                    items(customQuizzes, key = { it.id }) { quiz ->
                        QuizCardItem(
                            quiz = quiz,
                            onPlayClick = { selectedQuizForMode = quiz },
                            onDeleteClick = { quizToDelete = quiz }
                        )
                    }
                }
            } else {
                // Filter is active (Category or Search)
                item {
                    CategoryActiveHeader(
                        category = selectedCategory,
                        quizCount = filteredQuizzes.size,
                        searchQuery = searchQuery,
                        onResetFilter = {
                            selectedCategory = "Tous"
                            searchQuery = ""
                        }
                    )
                }

                if (filteredQuizzes.isEmpty()) {
                    item {
                        EmptyFilterResultCard(
                            category = selectedCategory,
                            searchQuery = searchQuery,
                            onResetFilter = {
                                selectedCategory = "Tous"
                                searchQuery = ""
                            },
                            onCreateQuiz = onCreateQuiz
                        )
                    }
                } else {
                    items(filteredQuizzes, key = { it.id }) { quiz ->
                        QuizCardItem(
                            quiz = quiz,
                            onPlayClick = { selectedQuizForMode = quiz },
                            onDeleteClick = if (!quiz.isBuiltIn) { { quizToDelete = quiz } } else null
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }

    // Modal to choose Practice Mode (instant feedback) vs Exam Mode
    selectedQuizForMode?.let { quiz ->
        AlertDialog(
            onDismissRequest = { selectedQuizForMode = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = quiz.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Choisissez le mode de jeu :",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    // Option 1: Mode Entraînement / Révision
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val q = quiz
                                selectedQuizForMode = null
                                onStartQuiz(q, true)
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Mode Révision (Direct)",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Affiche la correction et le corrigé immédiatement après chaque question.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Option 2: Mode Examen
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val q = quiz
                                selectedQuizForMode = null
                                onStartQuiz(q, false)
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Mode Examen / Évaluation",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Conditions réelles : répondez aux questions, score et corrigé complet affichés à la fin.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { selectedQuizForMode = null }) {
                    Text("Annuler")
                }
            }
        )
    }

    // Delete Confirmation Dialog
    quizToDelete?.let { quiz ->
        AlertDialog(
            onDismissRequest = { quizToDelete = null },
            title = { Text("Supprimer ce quiz ?") },
            text = { Text("Êtes-vous sûr de vouloir supprimer « ${quiz.title} » ? Toutes les questions associées seront effacées.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteQuiz(quiz)
                        quizToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Supprimer")
                }
            },
            dismissButton = {
                TextButton(onClick = { quizToDelete = null }) {
                    Text("Annuler")
                }
            }
        )
    }
}

@Composable
fun HeroStatsCard(
    attemptCount: Int,
    avgScore: Float?,
    onOpenHistory: () -> Unit,
    onTakeAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_stats_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(brush = PrimaryHeroBrush)
                .padding(start = 18.dp, top = 16.dp, bottom = 16.dp, end = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp)
                ) {
                    Text(
                        text = "Votre santé,\nnotre priorité",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Des soins et évaluations PGP de qualité, à portée de main.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f),
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White,
                        modifier = Modifier
                            .clickable { onTakeAction() }
                            .testTag("hero_action_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Prendre un rendez-vous",
                                color = Color(0xFF1D4ED8),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = Color(0xFF1D4ED8),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                // Doctor cutout / hero image
                Image(
                    painter = painterResource(id = R.drawable.img_doctor_hero),
                    contentDescription = "Médecin référent",
                    modifier = Modifier
                        .size(width = 110.dp, height = 125.dp)
                        .clip(RoundedCornerShape(18.dp)),
                    contentScale = ContentScale.Crop
                )
            }
        }
    }
}

@Composable
fun QuickActionItem(
    icon: ImageVector,
    label: String,
    bgColor: Color,
    iconColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .widthIn(min = 72.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = bgColor,
            modifier = Modifier.size(60.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconColor,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = TextDark,
            maxLines = 1
        )
    }
}

@Composable
fun ServiceCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    bgColor: Color,
    iconColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, LightBorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = bgColor,
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextDark,
                maxLines = 1
            )
        }
    }
}

@Composable
fun QuizCardItem(
    quiz: QuizEntity,
    onPlayClick: () -> Unit,
    onDeleteClick: (() -> Unit)?
) {
    val categoryColor = when (quiz.category) {
        "Matière Première Galénique" -> Color(0xFFD97706)
        "Gestion Logistique" -> Color(0xFF0D9488)
        "Toxicologie" -> Color(0xFF0284C7)
        "Pharmacologie" -> Color(0xFF1E6BFF)
        else -> QuizPrimary
    }

    val categoryContainer = when (quiz.category) {
        "Matière Première Galénique" -> Color(0xFFFEF3C7)
        "Gestion Logistique" -> PastelTealBg
        "Toxicologie" -> PastelBlueBg
        "Pharmacologie" -> Color(0xFFEFF6FF)
        else -> Color(0xFFF1F5F9)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quiz_card_${quiz.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        border = BorderStroke(1.dp, LightBorderSubtle),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 1.dp,
            pressedElevation = 3.dp
        )
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = categoryContainer,
                    border = BorderStroke(1.dp, categoryColor.copy(alpha = 0.25f))
                ) {
                    Text(
                        text = quiz.category.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = categoryColor,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFF8FAFC)
                    ) {
                        Text(
                            text = if (quiz.isBuiltIn) "Officiel PGP" else "Personnalisé",
                            style = MaterialTheme.typography.labelSmall,
                            color = LightMutedText,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (onDeleteClick != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = onDeleteClick,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Supprimer le quiz",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = quiz.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = quiz.description,
                style = MaterialTheme.typography.bodySmall,
                color = LightMutedText,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = onPlayClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QuizPrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
                    modifier = Modifier.testTag("play_quiz_${quiz.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Lancer le Quiz", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EmptyCustomQuizCard(onCreateQuiz: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.HelpOutline,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Vous n'avez pas encore créé de quiz",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Créez vos propres questions ou importez-les directement en texte pour vous entraîner sur vos cours !",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedButton(
                onClick = onCreateQuiz,
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Créer mon premier quiz")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryFilterChipItem(
    category: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val (chipIcon, chipColor) = when (category) {
        "Tous" -> Icons.Default.Dashboard to MaterialTheme.colorScheme.primary
        "Gestion Logistique" -> Icons.Default.LocalShipping to Color(0xFF0D9488)
        "Pharmacologie" -> Icons.Default.Psychology to Color(0xFF6366F1)
        "Toxicologie" -> Icons.Default.Science to Color(0xFF0EA5E9)
        "Mes Quiz" -> Icons.Default.School to Color(0xFF8B5CF6)
        else -> Icons.Default.Category to MaterialTheme.colorScheme.secondary
    }

    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = category,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
                Surface(
                    shape = CircleShape,
                    color = if (isSelected) chipColor else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.padding(start = 2.dp)
                ) {
                    Text(
                        text = "$count",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        },
        leadingIcon = {
            Icon(
                imageVector = chipIcon,
                contentDescription = null,
                tint = if (isSelected) chipColor else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = chipColor.copy(alpha = 0.15f),
            selectedLabelColor = chipColor
        ),
        border = if (isSelected) {
            BorderStroke(1.5.dp, chipColor)
        } else {
            BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
        },
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.testTag("filter_chip_${category.lowercase().replace(" ", "_")}")
    )
}

@Composable
fun CategoryActiveHeader(
    category: String,
    quizCount: Int,
    searchQuery: String,
    onResetFilter: () -> Unit
) {
    val (headerIcon, headerColor, headerDescription) = when (category) {
        "Gestion Logistique" -> Triple(
            Icons.Default.LocalShipping,
            Color(0xFF0D9488),
            "Chaîne logistique des produits de santé, sélection LNME, quantification CMM, distribution PUSH/PULL & TD 2024"
        )
        "Pharmacologie" -> Triple(
            Icons.Default.Psychology,
            Color(0xFF6366F1),
            "Pharmacodynamie, cibles moléculaires, pharmacocinétique et TD officiels 2025-2026"
        )
        "Toxicologie" -> Triple(
            Icons.Default.Science,
            Color(0xFF0EA5E9),
            "Évaluation officielle Dr Bosson 2022, TD Toxicologie PGP1, toxicocinétique, voies d'absorption, Probo Koala, intoxications et antidotes"
        )
        "Mes Quiz" -> Triple(
            Icons.Default.School,
            Color(0xFF8B5CF6),
            "Vos quiz personnalisés créés manuellement ou importés à partir de vos cours"
        )
        else -> Triple(
            Icons.Default.Category,
            MaterialTheme.colorScheme.primary,
            if (searchQuery.isNotBlank()) "Résultats correspondant à la recherche « $searchQuery »" else "Quiz de la catégorie $category"
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("category_active_header"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = headerColor.copy(alpha = 0.10f)
        ),
        border = BorderStroke(1.dp, headerColor.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = headerColor.copy(alpha = 0.2f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = headerIcon,
                                contentDescription = null,
                                tint = headerColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (searchQuery.isNotBlank()) "Recherche : « $searchQuery »" else category,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "$quizCount quiz disponible${if (quizCount > 1) "s" else ""}",
                            style = MaterialTheme.typography.labelSmall,
                            color = headerColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                TextButton(
                    onClick = onResetFilter,
                    modifier = Modifier.testTag("reset_filter_button")
                ) {
                    Icon(imageVector = Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tous")
                }
            }

            if (headerDescription.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = headerDescription,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun EmptyFilterResultCard(
    category: String,
    searchQuery: String,
    onResetFilter: () -> Unit,
    onCreateQuiz: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_filter_result_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Aucun quiz trouvé",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (searchQuery.isNotBlank()) {
                    "Aucun résultat pour « $searchQuery » dans $category."
                } else {
                    "Aucun quiz n'est encore enregistré dans la catégorie $category."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onResetFilter,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Afficher tous les quiz")
                }
                OutlinedButton(
                    onClick = onCreateQuiz,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Créer un quiz")
                }
            }
        }
    }
}
