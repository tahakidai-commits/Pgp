package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.data.model.QuizAttemptEntity
import com.example.data.model.QuizEntity
import com.example.data.repository.QuizRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

data class PlayUiState(
    val quiz: QuizEntity? = null,
    val questions: List<QuestionEntity> = emptyList(),
    val currentIndex: Int = 0,
    val userAnswers: Map<Long, Set<String>> = emptyMap(), // questionId -> chosen keys (e.g. "VRAI", "a", "c")
    val isPracticeMode: Boolean = false, // instant correction
    val revealedQuestions: Set<Long> = emptySet(), // in practice mode, whether user hit validate
    val timeElapsedSeconds: Int = 0,
    val questionTimerSeconds: Int = 40,
    val maxQuestionTimerSeconds: Int = 40,
    val isTimerPaused: Boolean = false,
    val isTimerEnabled: Boolean = true,
    val isCompleted: Boolean = false,
    val lastAttempt: QuizAttemptEntity? = null,
    val isLoading: Boolean = false
)

data class QuestionScoreResult(
    val question: QuestionEntity,
    val userSelection: Set<String>,
    val pointsEarned: Float,
    val isFullyCorrect: Boolean,
    val isPartiallyCorrect: Boolean,
    val isWrong: Boolean,
    val isUnanswered: Boolean
)

data class QuizSummaryResult(
    val totalScore: Float,
    val maxScore: Float,
    val percentage: Float,
    val correctCount: Int,
    val partialCount: Int,
    val wrongCount: Int,
    val unansweredCount: Int,
    val questionResults: List<QuestionScoreResult>
)

class QuizViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: QuizRepository

    val allQuizzes: StateFlow<List<QuizEntity>>
    val allAttempts: StateFlow<List<QuizAttemptEntity>>

    private val _playState = MutableStateFlow(PlayUiState())
    val playState: StateFlow<PlayUiState> = _playState.asStateFlow()

    private var timerJob: Job? = null

    init {
        val db = AppDatabase.getDatabase(application)
        repository = QuizRepository(db.quizDao(), db.questionDao(), db.attemptDao())

        allQuizzes = repository.allQuizzes.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allAttempts = repository.allAttempts.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        viewModelScope.launch {
            repository.ensureDefaultQuizSeeded()
        }
    }

    // --- QUIZ PLAY FLOW ---

    fun startQuiz(quiz: QuizEntity, practiceMode: Boolean = false) {
        viewModelScope.launch {
            _playState.update { it.copy(isLoading = true) }
            val questions = repository.getQuestionsForQuizSync(quiz.id)
            timerJob?.cancel()
            _playState.value = PlayUiState(
                quiz = quiz,
                questions = questions,
                currentIndex = 0,
                userAnswers = emptyMap(),
                isPracticeMode = practiceMode,
                revealedQuestions = emptySet(),
                timeElapsedSeconds = 0,
                questionTimerSeconds = 40,
                maxQuestionTimerSeconds = 40,
                isTimerPaused = false,
                isTimerEnabled = true,
                isCompleted = false,
                lastAttempt = null,
                isLoading = false
            )
            startTimer()
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val currentState = _playState.value
                if (currentState.isCompleted) {
                    break
                }
                if (currentState.isTimerPaused) {
                    continue
                }

                val newElapsed = currentState.timeElapsedSeconds + 1

                if (!currentState.isTimerEnabled) {
                    _playState.update { it.copy(timeElapsedSeconds = newElapsed) }
                } else {
                    val remaining = currentState.questionTimerSeconds - 1
                    if (remaining <= 0) {
                        // 40s elapsed for current question
                        if (currentState.currentIndex < currentState.questions.size - 1) {
                            _playState.update {
                                it.copy(
                                    currentIndex = it.currentIndex + 1,
                                    questionTimerSeconds = 40,
                                    timeElapsedSeconds = newElapsed
                                )
                            }
                        } else {
                            // Last question timer ended -> auto finish quiz
                            _playState.update {
                                it.copy(
                                    questionTimerSeconds = 0,
                                    timeElapsedSeconds = newElapsed
                                )
                            }
                            finishQuiz()
                            break
                        }
                    } else {
                        _playState.update {
                            it.copy(
                                questionTimerSeconds = remaining,
                                timeElapsedSeconds = newElapsed
                            )
                        }
                    }
                }
            }
        }
    }

    fun selectOption(questionId: Long, optionKey: String, isMultiple: Boolean) {
        val currentAnswers = _playState.value.userAnswers[questionId] ?: emptySet()
        val newSet = if (isMultiple) {
            if (currentAnswers.contains(optionKey)) {
                currentAnswers - optionKey
            } else {
                currentAnswers + optionKey
            }
        } else {
            if (currentAnswers.contains(optionKey)) {
                emptySet()
            } else {
                setOf(optionKey)
            }
        }

        _playState.update { state ->
            state.copy(
                userAnswers = state.userAnswers + (questionId to newSet)
            )
        }
    }

    fun revealCurrentInPractice(questionId: Long) {
        _playState.update { state ->
            state.copy(revealedQuestions = state.revealedQuestions + questionId)
        }
    }

    fun goToQuestion(index: Int) {
        if (index in _playState.value.questions.indices) {
            _playState.update { it.copy(currentIndex = index, questionTimerSeconds = 40) }
        }
    }

    fun nextQuestion() {
        val next = _playState.value.currentIndex + 1
        if (next < _playState.value.questions.size) {
            _playState.update { it.copy(currentIndex = next, questionTimerSeconds = 40) }
        }
    }

    fun previousQuestion() {
        val prev = _playState.value.currentIndex - 1
        if (prev >= 0) {
            _playState.update { it.copy(currentIndex = prev, questionTimerSeconds = 40) }
        }
    }

    fun toggleTimerPause() {
        _playState.update { it.copy(isTimerPaused = !it.isTimerPaused) }
    }

    fun resetQuestionTimer() {
        _playState.update { it.copy(questionTimerSeconds = 40) }
    }

    fun toggleTimerEnabled() {
        _playState.update { it.copy(isTimerEnabled = !it.isTimerEnabled) }
    }

    fun finishQuiz() {
        timerJob?.cancel()
        val state = _playState.value
        val quiz = state.quiz ?: return
        val questions = state.questions
        val userAnswers = state.userAnswers

        val summary = calculateSummary(questions, userAnswers)

        viewModelScope.launch {
            val answersJsonObj = JSONObject()
            userAnswers.forEach { (qId, selected) ->
                val arr = org.json.JSONArray()
                selected.forEach { arr.put(it) }
                answersJsonObj.put(qId.toString(), arr)
            }

            val attempt = QuizAttemptEntity(
                quizId = quiz.id,
                quizTitle = quiz.title,
                score = summary.totalScore,
                maxScore = summary.maxScore,
                correctCount = summary.correctCount,
                wrongCount = summary.wrongCount,
                unansweredCount = summary.unansweredCount,
                timeTakenSeconds = state.timeElapsedSeconds,
                completedAt = System.currentTimeMillis(),
                userAnswersJson = answersJsonObj.toString()
            )

            val attemptId = repository.recordAttempt(attempt)
            _playState.update {
                it.copy(
                    isCompleted = true,
                    lastAttempt = attempt.copy(id = attemptId)
                )
            }
        }
    }

    fun resetPlayState() {
        timerJob?.cancel()
        _playState.value = PlayUiState()
    }

    // --- SCORING CALCULATION ---

    fun calculateSummary(
        questions: List<QuestionEntity>,
        userAnswers: Map<Long, Set<String>>
    ): QuizSummaryResult {
        var totalScore = 0f
        var maxScore = 0f
        var correctCount = 0
        var partialCount = 0
        var wrongCount = 0
        var unansweredCount = 0

        val questionResults = questions.map { question ->
            val userSelection = userAnswers[question.id] ?: emptySet()
            val correctSet = question.correctAnswers.map { it.trim().lowercase() }.toSet()
            val userNormalized = userSelection.map { it.trim().lowercase() }.toSet()

            var pointsEarned = 0f
            var isFully = false
            var isPartial = false
            var isWrong = false
            var isUnanswered = false

            maxScore += question.positivePoints

            if (userNormalized.isEmpty()) {
                isUnanswered = true
                unansweredCount++
                pointsEarned = 0f
            } else if (question.type == QuestionType.TRUE_FALSE) {
                val trueEquivalents = setOf("vrai", "v", "a", "true")
                val falseEquivalents = setOf("faux", "f", "b", "false")
                val userIsTrue = userNormalized.any { it in trueEquivalents }
                val userIsFalse = userNormalized.any { it in falseEquivalents }
                val correctIsTrue = correctSet.any { it in trueEquivalents }
                val correctIsFalse = correctSet.any { it in falseEquivalents }

                val isCorrect = (userIsTrue && correctIsTrue) || (userIsFalse && correctIsFalse) || (userNormalized == correctSet)
                if (isCorrect) {
                    isFully = true
                    correctCount++
                    pointsEarned = question.positivePoints
                } else {
                    isWrong = true
                    wrongCount++
                    pointsEarned = -question.negativePoints
                }
            } else {
                // QCM Rule from PDF:
                // "Choisir pour les questions ci-après les deux bonnes réponses tout en sachant que le
                // choix des deux réponses donne droit à 1 point et le choix d’une seule réponse sans erreur donne droit à 0,5 point"
                val correctSelected = userNormalized.intersect(correctSet).size
                val wrongSelected = userNormalized.subtract(correctSet).size

                if (wrongSelected > 0) {
                    isWrong = true
                    wrongCount++
                    pointsEarned = if (question.negativePoints > 0) -question.negativePoints else 0f
                } else if (correctSelected == correctSet.size && correctSet.isNotEmpty()) {
                    isFully = true
                    correctCount++
                    pointsEarned = question.positivePoints
                } else if (correctSelected == 1 && correctSet.size > 1) {
                    isPartial = true
                    partialCount++
                    pointsEarned = question.positivePoints / 2f
                } else {
                    isWrong = true
                    wrongCount++
                    pointsEarned = 0f
                }
            }

            totalScore += pointsEarned

            QuestionScoreResult(
                question = question,
                userSelection = userSelection,
                pointsEarned = pointsEarned,
                isFullyCorrect = isFully,
                isPartiallyCorrect = isPartial,
                isWrong = isWrong,
                isUnanswered = isUnanswered
            )
        }

        val percentage = if (maxScore > 0) (kotlin.math.max(0f, totalScore) / maxScore) * 100f else 0f

        return QuizSummaryResult(
            totalScore = totalScore,
            maxScore = maxScore,
            percentage = percentage,
            correctCount = correctCount,
            partialCount = partialCount,
            wrongCount = wrongCount,
            unansweredCount = unansweredCount,
            questionResults = questionResults
        )
    }

    // --- QUIZ CREATION & MANAGEMENT ("C'est moi qui doit ajouter les quizz") ---

    fun createQuizWithQuestions(
        title: String,
        description: String,
        category: String,
        questions: List<QuestionEntity>,
        onSuccess: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val quiz = QuizEntity(
                title = title.ifBlank { "Nouveau Quiz" },
                description = description.ifBlank { "${questions.size} questions personnalisées" },
                category = category.ifBlank { "Général" },
                isBuiltIn = false,
                createdAt = System.currentTimeMillis()
            )
            val quizId = repository.insertQuiz(quiz)
            val mappedQuestions = questions.mapIndexed { index, q ->
                q.copy(id = 0, quizId = quizId, questionIndex = index + 1)
            }
            repository.insertQuestions(mappedQuestions)
            onSuccess(quizId)
        }
    }

    fun deleteQuiz(quiz: QuizEntity) {
        viewModelScope.launch {
            repository.deleteQuiz(quiz)
        }
    }

    fun deleteAttempt(attemptId: Long) {
        viewModelScope.launch {
            repository.deleteAttempt(attemptId)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearAllAttempts()
        }
    }

    // --- TEXT IMPORT PARSER FOR EASY BULK QUIZ CREATION ---
    fun parseRawTextIntoQuestions(rawText: String): List<QuestionEntity> {
        val result = mutableListOf<QuestionEntity>()
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }

        var currentText = ""
        var currentOptions = mutableListOf<String>()
        var currentAnswers = mutableListOf<String>()
        var currentExplanation = ""
        var currentType = QuestionType.MULTIPLE_CHOICE
        var questionIndex = 1

        fun flushCurrent() {
            if (currentText.isNotBlank()) {
                val effectiveOptions = if (currentOptions.isEmpty()) {
                    listOf("VRAI", "FAUX")
                } else {
                    currentOptions.toList()
                }

                val effectiveType = if (effectiveOptions.size == 2 &&
                    effectiveOptions.any { it.contains("vrai", ignoreCase = true) } &&
                    effectiveOptions.any { it.contains("faux", ignoreCase = true) }
                ) {
                    QuestionType.TRUE_FALSE
                } else {
                    currentType
                }

                val finalAnswers = if (currentAnswers.isEmpty()) {
                    if (effectiveType == QuestionType.TRUE_FALSE) listOf("VRAI") else listOf("a")
                } else {
                    currentAnswers.toList()
                }

                result.add(
                    QuestionEntity(
                        quizId = 0,
                        questionIndex = questionIndex++,
                        questionText = currentText,
                        type = effectiveType,
                        options = effectiveOptions,
                        correctAnswers = finalAnswers,
                        explanation = currentExplanation.ifBlank { null },
                        positivePoints = 1.0f,
                        negativePoints = if (effectiveType == QuestionType.TRUE_FALSE) 0.5f else 0.0f,
                        maxChoices = if (finalAnswers.size > 1) finalAnswers.size else 1
                    )
                )
            }
            currentText = ""
            currentOptions = mutableListOf()
            currentAnswers = mutableListOf()
            currentExplanation = ""
            currentType = QuestionType.MULTIPLE_CHOICE
        }

        for (line in lines) {
            val lower = line.lowercase()
            when {
                // New question header e.g. "1- ", "1. ", "Q1: ", "Q: "
                line.matches(Regex("""^(\d+[\.\-\)]\s*|Q\s*\d*[\.\:\-]\s*).*""", RegexOption.IGNORE_CASE)) -> {
                    flushCurrent()
                    currentText = line.replace(Regex("""^(\d+[\.\-\)]\s*|Q\s*\d*[\.\:\-]\s*)""", RegexOption.IGNORE_CASE), "").trim()
                    if (currentText.isEmpty()) currentText = line
                }
                // Options e.g. "a- ", "a) ", "A. "
                line.matches(Regex("""^[a-eA-E][\)\.\-]\s*.*""")) -> {
                    val opt = line
                    currentOptions.add(opt)
                }
                // Explicit True / False indicator in line
                lower.startsWith("réponse:") || lower.startsWith("reponse:") || lower.startsWith("corrigé:") || lower.startsWith("corrige:") -> {
                    val ansStr = line.substringAfter(":").trim()
                    // split by comma or spaces
                    val answers = ansStr.split(Regex("[,;\\s]+")).filter { it.isNotBlank() }
                    currentAnswers.addAll(answers)
                }
                lower.startsWith("explication:") || lower.startsWith("justification:") -> {
                    currentExplanation = line.substringAfter(":").trim()
                }
                currentText.isEmpty() -> {
                    currentText = line
                }
                else -> {
                    // if it looks like VRAI / FAUX answer directly at end of question
                    if (lower.endsWith("vrai") || lower.endsWith("faux")) {
                        val words = line.split(" ")
                        val last = words.last().uppercase()
                        currentAnswers.add(last)
                        currentText += " " + words.dropLast(1).joinToString(" ")
                    } else {
                        currentText += " $line"
                    }
                }
            }
        }
        flushCurrent()
        return result
    }

    companion object {
        fun evaluateAnswers(
            questions: List<QuestionEntity>,
            userAnswers: Map<Long, Set<String>>
        ): QuizSummaryResult {
            var totalScore = 0f
            var maxScore = 0f
            var correctCount = 0
            var partialCount = 0
            var wrongCount = 0
            var unansweredCount = 0

            val questionResults = questions.map { question ->
                val userSelection = userAnswers[question.id] ?: emptySet()
                val correctSet = question.correctAnswers.map { it.trim().lowercase() }.toSet()
                val userNormalized = userSelection.map { it.trim().lowercase() }.toSet()

                var pointsEarned = 0f
                var isFully = false
                var isPartial = false
                var isWrong = false
                var isUnanswered = false

                maxScore += question.positivePoints

                if (userNormalized.isEmpty()) {
                    isUnanswered = true
                    unansweredCount++
                    pointsEarned = 0f
                } else if (question.type == QuestionType.TRUE_FALSE) {
                    if (userNormalized == correctSet) {
                        isFully = true
                        correctCount++
                        pointsEarned = question.positivePoints
                    } else {
                        isWrong = true
                        wrongCount++
                        pointsEarned = -question.negativePoints
                    }
                } else {
                    val correctMatches = userNormalized.intersect(correctSet).size
                    val wrongMatches = userNormalized.minus(correctSet).size

                    if (userNormalized == correctSet) {
                        isFully = true
                        correctCount++
                        pointsEarned = question.positivePoints
                    } else if (wrongMatches == 0 && correctMatches > 0) {
                        isPartial = true
                        partialCount++
                        pointsEarned = question.positivePoints * (correctMatches.toFloat() / correctSet.size.coerceAtLeast(1))
                    } else {
                        isWrong = true
                        wrongCount++
                        pointsEarned = 0f
                    }
                }

                totalScore += pointsEarned

                QuestionScoreResult(
                    question = question,
                    userSelection = userSelection,
                    pointsEarned = pointsEarned,
                    isFullyCorrect = isFully,
                    isPartiallyCorrect = isPartial,
                    isWrong = isWrong,
                    isUnanswered = isUnanswered
                )
            }

            val percentage = if (maxScore > 0) (kotlin.math.max(0f, totalScore) / maxScore) * 100f else 0f

            return QuizSummaryResult(
                totalScore = totalScore,
                maxScore = maxScore,
                percentage = percentage,
                correctCount = correctCount,
                partialCount = partialCount,
                wrongCount = wrongCount,
                unansweredCount = unansweredCount,
                questionResults = questionResults
            )
        }

        fun parseTextToQuestions(rawText: String): List<QuestionEntity> {
            val result = mutableListOf<QuestionEntity>()
            val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }

            var currentText = ""
            var currentOptions = mutableListOf<String>()
            var currentAnswers = mutableListOf<String>()
            var currentExplanation = ""
            var currentType = QuestionType.MULTIPLE_CHOICE
            var questionIndex = 1

            fun flushCurrent() {
                if (currentText.isNotBlank()) {
                    val effectiveOptions = if (currentOptions.isEmpty()) {
                        listOf("VRAI", "FAUX")
                    } else {
                        currentOptions.toList()
                    }

                    val effectiveType = if (effectiveOptions.size == 2 &&
                        effectiveOptions.any { it.contains("vrai", ignoreCase = true) } &&
                        effectiveOptions.any { it.contains("faux", ignoreCase = true) }
                    ) {
                        QuestionType.TRUE_FALSE
                    } else {
                        currentType
                    }

                    val finalAnswers = if (currentAnswers.isEmpty()) {
                        if (effectiveType == QuestionType.TRUE_FALSE) listOf("VRAI") else listOf("a")
                    } else {
                        currentAnswers.toList()
                    }

                    result.add(
                        QuestionEntity(
                            quizId = 0,
                            questionIndex = questionIndex++,
                            questionText = currentText,
                            type = effectiveType,
                            options = effectiveOptions,
                            correctAnswers = finalAnswers,
                            explanation = currentExplanation.ifBlank { null },
                            positivePoints = 1.0f,
                            negativePoints = if (effectiveType == QuestionType.TRUE_FALSE) 0.5f else 0.0f,
                            maxChoices = if (finalAnswers.size > 1) finalAnswers.size else 1
                        )
                    )
                }
                currentText = ""
                currentOptions = mutableListOf()
                currentAnswers = mutableListOf()
                currentExplanation = ""
                currentType = QuestionType.MULTIPLE_CHOICE
            }

            for (line in lines) {
                val lower = line.lowercase()
                when {
                    line.matches(Regex("^\\d+[\\.\\)]\\s*.*")) -> {
                        flushCurrent()
                        currentText = line.replace(Regex("^\\d+[\\.\\)]\\s*"), "")
                    }
                    line.matches(Regex("^[a-eA-E][\\-\\)]\\s*.*")) -> {
                        currentOptions.add(line)
                    }
                    lower.startsWith("réponse:") || lower.startsWith("reponse:") || lower.startsWith("rep:") -> {
                        val ansStr = line.substringAfter(":").trim()
                        val answers = ansStr.split(Regex("[,;\\s]+")).filter { it.isNotBlank() }
                        currentAnswers.addAll(answers)
                    }
                    lower.startsWith("explication:") || lower.startsWith("justification:") -> {
                        currentExplanation = line.substringAfter(":").trim()
                    }
                    currentText.isEmpty() -> {
                        currentText = line
                    }
                    else -> {
                        currentText += " $line"
                    }
                }
            }
            flushCurrent()
            return result
        }
    }
}
