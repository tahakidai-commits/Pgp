package com.example.data.seed

import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.data.model.QuizEntity

object GaleniqueMatierePremiereData {

    fun createQuiz(): QuizEntity {
        return QuizEntity(
            id = 60L,
            title = "TD Pharmacie Galénique - Matières Premières PGP1 (2024)",
            description = "TD de Pharmacie Galénique (Matières Premières Pharmaceutiques) PGP1 Année Académique 2024 - 45 questions (Vrai/Faux et QCM) avec corrigé officiel et explications détaillées.",
            category = "Matière Première Galénique",
            isBuiltIn = true,
            createdAt = 1710000060000L
        )
    }

    fun getQuestionsForQuiz(quizId: Long): List<QuestionEntity> = getQuestions(quizId)

    fun getQuestions(quizId: Long): List<QuestionEntity> {
        val list = mutableListOf<QuestionEntity>()
        var idx = 0
        val ctx = "TD Pharmacie Galénique — Matières Premières Pharmaceutiques PGP1 2024 (\"Age quod agis\") • Barème : réponse juste = 1 pt, réponse fausse = 0 pt, sans réponse = 0 pt"

        fun addTrueFalse(num: Int, text: String, correct: String, explanation: String) {
            idx++
            list.add(
                QuestionEntity(
                    quizId = quizId,
                    questionIndex = idx,
                    contextText = ctx,
                    questionText = "$num. $text",
                    type = QuestionType.TRUE_FALSE,
                    options = listOf("VRAI", "FAUX"),
                    correctAnswers = listOf(correct),
                    explanation = explanation,
                    positivePoints = 1.0f,
                    negativePoints = 0.0f,
                    maxChoices = 1
                )
            )
        }

        fun addSingleChoice(
            num: Int,
            text: String,
            options: List<String>,
            correctKey: String,
            explanation: String
        ) {
            idx++
            list.add(
                QuestionEntity(
                    quizId = quizId,
                    questionIndex = idx,
                    contextText = ctx,
                    questionText = "$num. $text",
                    type = QuestionType.SINGLE_CHOICE,
                    options = options,
                    correctAnswers = listOf(correctKey),
                    explanation = explanation,
                    positivePoints = 1.0f,
                    negativePoints = 0.0f,
                    maxChoices = 1
                )
            )
        }

        fun addMultiChoice(
            num: Int,
            text: String,
            options: List<String>,
            correctKeys: List<String>,
            explanation: String
        ) {
            idx++
            list.add(
                QuestionEntity(
                    quizId = quizId,
                    questionIndex = idx,
                    contextText = ctx,
                    questionText = "$num. $text",
                    type = QuestionType.MULTIPLE_CHOICE,
                    options = options,
                    correctAnswers = correctKeys,
                    explanation = explanation,
                    positivePoints = 1.0f,
                    negativePoints = 0.0f,
                    maxChoices = correctKeys.size
                )
            )
        }

        // Q1
        addSingleChoice(
            1,
            "Les excipients origine et classification : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. La gélatine est un excipient d'origine animale",
                "b. La lanoline est un excipient d'origine végétale",
                "c. L'oxyde de titane est un excipient d'origine synthétique"
            ),
            "a",
            "a. VRAI. La gélatine est d'origine animale. La lanoline est en réalité d'origine animale (pas végétale) et l'oxyde de titane est d'origine minérale (pas synthétique)."
        )

        // Q2
        addTrueFalse(
            2,
            "Les excipients à effets notoires ne sont pas interdits dans la préparation des médicaments.",
            "VRAI",
            "VRAI. Ils sont autorisés mais doivent être signalés sur l'étiquetage (cours p.4)."
        )

        // Q3
        addTrueFalse(
            3,
            "La qualité la plus importante des excipients est qu'ils ne sont pas actifs sur le plan pharmacologique.",
            "VRAI",
            "VRAI. C'est ce qu'on appelle l'inertie pharmacologique de l'excipient."
        )

        // Q4
        addTrueFalse(
            4,
            "Le rôle de protection vis-à-vis des microorganismes permet à l'excipient d'améliorer l'efficacité du PA.",
            "FAUX",
            "FAUX. Ce rôle de protection sert à assurer la stabilité et la conservation, pas à améliorer l'efficacité du principe actif (tableau p.4)."
        )

        // Q5
        addTrueFalse(
            5,
            "Le principe actif peut être un médicament.",
            "FAUX",
            "FAUX. D'après le support (p.2), un médicament est l'association d'un principe actif et d'un excipient : le PA seul n'est pas un médicament."
        )

        // Q6
        addSingleChoice(
            6,
            "Les glycérides : parmi les items suivants, une seule est fausse.",
            listOf(
                "a. Ils sont obtenus par estérification du glucose avec un ou plusieurs acides gras",
                "b. Il existe trois formes de glycérides (les monoglycérides, les diglycérides et triglycérides)",
                "c. Les huiles végétales sont obtenues en général par trois procédés"
            ),
            "a",
            "a. FAUSSE. Les glycérides sont obtenus par estérification du glycérol (et non du glucose) avec un ou plusieurs acides gras."
        )

        // Q7
        addTrueFalse(
            7,
            "Le stérilet peut être considéré comme un médicament.",
            "FAUX",
            "FAUX. Le stérilet est un dispositif médical, il ne répond pas à la définition OMS du médicament."
        )

        // Q8
        addTrueFalse(
            8,
            "L'adjuvant est un excipient.",
            "VRAI",
            "VRAI."
        )

        // Q9
        addSingleChoice(
            9,
            "Les principes actifs : parmi les items suivants, un seul est faux.",
            listOf(
                "a. L'huile essentielle d'eucalyptus a des propriétés aromatisantes et digestives",
                "b. Les poudres opothérapiques ne sont pratiquement plus utilisées",
                "c. Les teintures végétales liquides sont obtenues en traitant les plantes séchées par l'alcool"
            ),
            "a",
            "a. FAUX. L'huile essentielle d'eucalyptus a des propriétés expectorantes et antiseptiques, pas digestives."
        )

        // Q10
        addSingleChoice(
            10,
            "Les excipients origine et classification : parmi les excipients suivants, un seul est d'origine synthétique.",
            listOf(
                "a. Le talc",
                "b. Le Carbomère",
                "c. La vaseline"
            ),
            "b",
            "b. Le Carbomère est d'origine synthétique. Le talc et la vaseline sont d'origine minérale (cours p.8)."
        )

        // Q11
        addTrueFalse(
            11,
            "L'encéphalopathie Bovine Spongiforme (ESB) est l'un des problèmes liés à l'opothérapie.",
            "VRAI",
            "VRAI. Risque de transmission de prions, raison pour laquelle les poudres opothérapiques ont été abandonnées."
        )

        // Q12
        addTrueFalse(
            12,
            "La gélatine est un mélange de nature protéique.",
            "VRAI",
            "VRAI (cours protéines p.20)."
        )

        // Q13
        addSingleChoice(
            13,
            "Les protéines : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. La gélatine est une substance liquide translucide, transparente ou légèrement jaune",
                "b. La gélatine est obtenue par ébullition prolongée des tissus conjonctifs ou des os des animaux",
                "c. Il existe de la gélatine végétale"
            ),
            "b",
            "b. VRAI. La gélatine est obtenue par ébullition prolongée des tissus conjonctifs ou des os des animaux. (a) est faux car la gélatine est solide, pas liquide ; (c) est faux car il n'existe pas de gélatine végétale."
        )

        // Q14
        addTrueFalse(
            14,
            "Les matières premières médicamenteuses désignent tout produit rentrant dans la composition d'un médicament.",
            "VRAI",
            "VRAI (définition p.2)."
        )

        // Q15
        addSingleChoice(
            15,
            "Les glycérides : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. Le beurre de cacao est un excipient solide qui est facile à conserver",
                "b. Le beurre de karité est la glycéride solide la plus utilisée en pharmacie",
                "c. L'huile de camphre stérilisée et neutralisée est utilisée dans les préparations injectables",
                "d. Toutes les propositions sont fausses"
            ),
            "c",
            "c. VRAI. L'huile de camphre stérilisée et neutralisée est utilisée en préparations injectables. (a) est faux car le beurre de cacao rancit facilement ; (b) est faux car le beurre de karité n'est pas la glycéride solide la plus utilisée."
        )

        // Q16
        addTrueFalse(
            16,
            "L'inertie d'un excipient vis-à-vis du conditionnement signifie qu'il ne doit pas avoir d'interaction entre le conditionnement primaire et l'excipient.",
            "VRAI",
            "VRAI. Il s'agit bien du conditionnement primaire, et non secondaire (cours p.6, QCD)."
        )

        // Q17
        addSingleChoice(
            17,
            "Les protéines : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. La gélatine est un excipient solide lipophile",
                "b. La gélatine est un excipient solide hydrophile",
                "c. La caséine est une protéine d'origine végétale"
            ),
            "b",
            "b. VRAI. La gélatine est un excipient solide hydrophile (cours p.8). La caséine est en réalité une protéine d'origine animale, pas végétale."
        )

        // Q18
        addTrueFalse(
            18,
            "Un médicament tel qu'il est présenté au malade est constitué d'un ou plusieurs principes actifs, d'un ou plusieurs excipients et d'un conditionnement.",
            "VRAI",
            "VRAI."
        )

        // Q19
        addTrueFalse(
            19,
            "La cire de cachalot est d'origine animale.",
            "VRAI",
            "VRAI."
        )

        // (20 = champ NOM dans le formulaire original, non repris ici)

        // Q21
        addSingleChoice(
            21,
            "Les alcools : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. L'alcool peut être dilué pour obtenir un titre de 35°",
                "b. Le glycérol est un liquide visqueux incolore qui a un goût sucré et chaud",
                "c. L'alcool titré à 90° est appelé alcool absolu"
            ),
            "b",
            "b. VRAI. Le glycérol est un liquide visqueux incolore au goût sucré et chaud. L'alcool absolu est titré à 100° et non 90°."
        )

        // Q22
        addTrueFalse(
            22,
            "L'excipient permet de réaliser la forme galénique.",
            "VRAI",
            "VRAI."
        )

        // Q23
        addSingleChoice(
            23,
            "Les sucres : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. Le glucose est insoluble dans l'eau et dans l'alcool",
                "b. Comme inconvénient, le glucose apporte beaucoup de calories à l'organisme",
                "c. Il existe quatre types d'amidon figurant à la pharmacopée"
            ),
            "b",
            "b. VRAI selon le cours : le glucose apporte beaucoup de calories à l'organisme (inconvénient). Remarque : (c) est également exact selon la pharmacopée (4 amidons), mais c'est bien (b) qui est retenue comme réponse du cours."
        )

        // Q24
        addSingleChoice(
            24,
            "Les excipients origine et classification : parmi les excipients suivants, un seul n'est pas d'origine minérale.",
            listOf(
                "a. L'amidon",
                "b. La lanoline",
                "c. La gomme arabique",
                "d. Le saccharose",
                "e. Toutes ces propositions sont fausses"
            ),
            "e",
            "e. VRAI. Amidon, gomme arabique et saccharose sont d'origine végétale ; la lanoline est d'origine animale. Aucun d'entre eux n'est d'origine minérale."
        )

        // Q25
        addSingleChoice(
            25,
            "Les eaux utilisées en pharmacie : parmi les eaux suivantes, une provoque une hémolyse si injectée seule.",
            listOf(
                "a. L'eau pour préparation injectable",
                "b. L'eau pour hémodialyse",
                "c. L'eau hautement purifiée"
            ),
            "a",
            "a. L'eau pour préparation injectable est hypotonique et provoque une hémolyse si elle est injectée seule."
        )

        // Q26
        addSingleChoice(
            26,
            "Les cires : parmi les propriétés suivantes concernant les cires, une seule est vraie.",
            listOf(
                "a. Leur point de fusion est de 45°",
                "b. Elles sont solubles dans l'eau",
                "c. Elles ont une faible viscosité lorsqu'elles sont fondues"
            ),
            "c",
            "c. VRAI. Les cires ont une faible viscosité à l'état fondu. Elles sont insolubles dans l'eau et leur point de fusion est supérieur à 45° (p.20)."
        )

        // Q27
        addTrueFalse(
            27,
            "Les conservateurs assurent la stabilité du médicament.",
            "VRAI",
            "VRAI."
        )

        // Q28
        addMultiChoice(
            28,
            "Les glycérides : parmi les items suivants, deux sont vrais.",
            listOf(
                "a. Les glycérides liquides sont essentiellement des triglycérides",
                "b. Les glycérides liquides sont utilisés dans la fabrication des pommades",
                "c. Le beurre de karité s'oxyde rapidement",
                "d. Le beurre de karité est utilisé comme excipient dans la fabrication des suppositoires",
                "f. Le beurre de cacao est obtenu par pression à partir de graines décortiquées de théobroma cacao"
            ),
            listOf("a", "f"),
            "a & f. Les glycérides liquides sont essentiellement des triglycérides, et le beurre de cacao est obtenu par pression à partir de graines décortiquées de Theobroma cacao."
        )

        // Q29
        addTrueFalse(
            29,
            "Le véhicule permet à l'excipient d'arriver là où il doit agir.",
            "FAUX",
            "FAUX. Le véhicule permet au principe actif (et non à l'excipient) d'arriver là où il doit agir."
        )

        // Q30
        addSingleChoice(
            30,
            "Les PEG : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. Les PEG pâteux ont une masse molaire supérieure à 800 g/mol",
                "b. Les PEG ne sont pas biodégradables",
                "c. Les PEG sont d'origine naturelle"
            ),
            "a",
            "a. VRAI. Les PEG pâteux ont une masse molaire supérieure à 800 g/mol. (b) est faux car ils sont biodégradables ; (c) est faux car ils sont d'origine synthétique."
        )

        // Q31
        addTrueFalse(
            31,
            "La gélatine est utilisée comme excipient pour les suppositoires et les ovules en association avec l'oxyde d'éthylène.",
            "FAUX",
            "FAUX. Il s'agit de la gélatine glycérinée, c'est-à-dire de la gélatine associée à la glycérine, et non à l'oxyde d'éthylène."
        )

        // Q32
        addTrueFalse(
            32,
            "Les excipients peuvent être liquides.",
            "VRAI",
            "VRAI. Exemples : huiles, eau, glycérol."
        )

        // Q33
        addTrueFalse(
            33,
            "Le blanc d'œuf sert à clarifier le vin.",
            "VRAI",
            "VRAI."
        )

        // Q34
        addMultiChoice(
            34,
            "Les excipients origine et classification : parmi les excipients suivants, deux sont d'origine animale.",
            listOf(
                "a. Le stéarate de sodium",
                "b. Phosphate de calcium",
                "c. La méthylcellulose",
                "d. Le Lactose",
                "e. Le Chlorure de sodium"
            ),
            listOf("a", "d"),
            "a & d. Le stéarate de sodium et le lactose sont d'origine animale."
        )

        // (35 = champ PRENOMS dans le formulaire original, non repris ici)

        // Q36
        addSingleChoice(
            36,
            "Les édulcorants : parmi les items concernant les édulcorants, un seul est vrai.",
            listOf(
                "a. La saccharine est moins sucrée que le saccharose",
                "b. Un des avantages des édulcorants intenses, c'est qu'ils sont moins diabétogènes et moins cariogènes que le saccharose",
                "c. Les succédanés des sucres sont plus toxiques que les édulcorants intenses"
            ),
            "b",
            "b. VRAI. Les édulcorants intenses sont moins diabétogènes et moins cariogènes que le saccharose."
        )

        // Q37
        addTrueFalse(
            37,
            "Les vaccins sont des PA d'origine animale.",
            "FAUX",
            "FAUX. Les vaccins sont des PA d'origine microbiologique/biotechnologique (p.38)."
        )

        // Q38
        addTrueFalse(
            38,
            "Un médicament est une association de plusieurs principes actifs.",
            "FAUX",
            "FAUX. Un médicament peut ne contenir qu'un seul principe actif."
        )

        // Q39
        addTrueFalse(
            39,
            "L'excipient peut être un médicament.",
            "VRAI",
            "VRAI. Exemple du cours (p.24) : la vaseline officinale est un médicament."
        )

        // Q40
        addTrueFalse(
            40,
            "Le beurre de cacao est obtenu par pression à partir de graines décortiquées de théobroma cacao.",
            "VRAI",
            "VRAI."
        )

        // Q41
        addTrueFalse(
            41,
            "La caséine est la protéine du lait végétal.",
            "FAUX",
            "FAUX. La caséine est la protéine du lait animal."
        )

        // Q42
        addSingleChoice(
            42,
            "Les sucres : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. Le miel contient 90% de glucose",
                "b. Les amidons sont inodores et solubles dans l'eau froide",
                "c. L'acétophtalate de cellulose est utilisée pour faire les enrobages gastro-résistants"
            ),
            "c",
            "c. VRAI. L'acétophtalate de cellulose est utilisé pour faire les enrobages gastro-résistants."
        )

        // Q43
        addSingleChoice(
            43,
            "Les hydrocarbures : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. La vaseline officinale est un médicament",
                "b. La vaseline est un délitant servant à faciliter le glissement d'objet",
                "c. La vaseline blanche est soluble dans l'eau",
                "d. La vaseline jaune aide à réparer les effets hydratants du quotidien"
            ),
            "a",
            "a. VRAI. La vaseline officinale est un médicament (p.24)."
        )

        // (44 = champ MATRICULE dans le formulaire original, non repris ici)

        // Q45
        addMultiChoice(
            45,
            "Les cires : parmi les cires suivantes, deux sont d'origine animale.",
            listOf(
                "a. La cire de cachalot",
                "b. La cire de jojoba",
                "c. La cire de lanoline",
                "d. La cire de carnauba",
                "e. La cire de candelilla"
            ),
            listOf("a", "c"),
            "a & c. La cire de cachalot et la cire de lanoline sont d'origine animale. Les cires de carnauba et de candelilla sont d'origine végétale."
        )

        // Q46
        addSingleChoice(
            46,
            "Les excipients rôles et qualités : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. L'utilisation de l'éthanol comme excipient nécessite des précautions d'emploi à cause du risque de toxicité",
                "b. Les excipients à effet notoire sont interdits dans la préparation des médicaments",
                "c. Le véhicule permet à l'excipient d'arriver là où il doit agir",
                "d. L'utilisation du glycérol comme excipient nécessite des précautions d'emploi à cause des risques d'allergie"
            ),
            "a",
            "a. VRAI. L'utilisation de l'éthanol comme excipient nécessite des précautions d'emploi en raison du risque de toxicité (effet notoire)."
        )

        // Q47
        addTrueFalse(
            47,
            "La principale méthode de préparation des huiles essentielles est la filtration.",
            "FAUX",
            "FAUX. Les huiles essentielles sont principalement préparées par distillation / entraînement à la vapeur, pas par filtration."
        )

        // Q48
        addSingleChoice(
            48,
            "Les excipients origine et classification : parmi les items suivants, un seul est vrai.",
            listOf(
                "a. Le beurre de karité s'oxyde rapidement",
                "b. Le beurre de cacao est un excipient solide",
                "c. Le beurre de karité est utilisé comme excipient dans la fabrication des suppositoires"
            ),
            "b",
            "b. VRAI. Le beurre de cacao est un excipient solide."
        )

        return list
    }
}
