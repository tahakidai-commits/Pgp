package com.example.data.seed

import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.data.model.QuizEntity

object EvaluationTox2022Data {

    fun createQuiz(): QuizEntity {
        return QuizEntity(
            id = 50L,
            title = "Évaluation Toxicologie PGP1 (10/08/2022) - Dr Bosson",
            description = "Épreuve officielle complète (40 questions Forms, 40 min, 20 pts) corrigée selon le cours de 36 pages du Pr TIGORI. Traite de la toxicocinétique, voies d'absorption, Probo Koala, toxines, antidotes, détoxification et intoxications aiguës/subaiguës/chroniques.",
            category = "Toxicologie",
            isBuiltIn = true,
            createdAt = 1710000050000L
        )
    }

    fun getQuestions(quizId: Long): List<QuestionEntity> {
        return listOf(
            // Question 1 (Form #6)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 1,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #6 (0.5 pt)",
                questionText = "1 (Form #6). La toxicologie est la science qui étudie les propriétés thérapeutiques des médicaments. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. La toxicologie étudie les propriétés toxiques, nocives et délétères des xénobiotiques sur les organismes vivants. L'étude des propriétés thérapeutiques est l'objet de la pharmacologie.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 2 (Form #7)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 2,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #7 (0.5 pt)",
                questionText = "2 (Form #7). Miss Traoré avale 20 comprimés de Paracétamol 1g. La quantité de Paracétamol prise par miss Traoré est : (0.5 points)",
                type = QuestionType.MULTIPLE_CHOICE,
                options = listOf(
                    "a. Un médicament",
                    "b. Un toxique",
                    "c. Un poison",
                    "d. Une toxine"
                ),
                correctAnswers = listOf("b", "c"),
                explanation = "b & c (Un toxique + un poison). À dose thérapeutique (3 à 4 g/jour chez l'adulte), le paracétamol est un médicament. À 20 g (dose massive très hépatotoxique), il devient un toxique et un poison. Ce n'est pas une toxine car il ne s'agit pas d'une substance naturelle élaborée par un être vivant.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 2
            ),

            // Question 3 (Form #8)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 3,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #8 (0.5 pt)",
                questionText = "3 (Form #8). Une période de 23 heures après la prise des 20g de Paracétamol, le toxicologue dit que miss Traoré fait une intoxication au Paracétamol. Miss Traoré est donc sujette à : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Une intoxication aiguë",
                    "b. Une intoxication chronique"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) Une intoxication aiguë. Prise unique massive avec survenue des troubles dans un délai n'excédant pas 24 heures (ici 23 heures). L'intoxication chronique résulte d'expositions répétées à petites doses sur des mois/années.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 4 (Form #9)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 4,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #9 (0.5 pt)",
                questionText = "4 (Form #9). En août 2006, le Probo koala déverse des déchets toxiques à Abidjan, à Akouedo. Trois semaines après le déversement des déchets à la décharge d'Akouédo, des habitants vomissent et présentent d'autres signes d'intoxication. On parle d'intoxication subaiguë. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. L'intoxication subaiguë correspond à des manifestations survenant après des jours à 3 semaines d'exposition répétée ou continue. (Rappel : suraiguë = minutes/heures, aiguë = < 24h, subaiguë = jours à 3 semaines, chronique = mois/années).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 5 (Form #10)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 5,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #10 (0.5 pt)",
                questionText = "5 (Form #10). Laquelle de ces opérations (détoxification et détoxication) a lieu avant et laquelle a lieu après la pénétration du toxique dans l'organisme ? (0.5 points)",
                type = QuestionType.MULTIPLE_CHOICE,
                options = listOf(
                    "a. La détoxication a lieu avant la pénétration du toxique dans l'organisme.",
                    "b. La détoxification a lieu avant la pénétration du toxique dans l'organisme.",
                    "c. La détoxication a lieu après la pénétration du toxique dans l'organisme.",
                    "d. La détoxification a lieu après la pénétration du toxique dans l'organisme."
                ),
                correctAnswers = listOf("b", "c"),
                explanation = "b & c. Selon le cours : La détoxification a lieu AVANT pénétration (moyens physiques ou chimiques d'évacuation, décontamination, lavage). La détoxication a lieu APRÈS pénétration (processus métabolique biologique enzymatique hépatique).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 2
            ),

            // Question 6 (Form #11)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 6,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #11 (0.5 pt)",
                questionText = "6 (Form #11). La porte d’entrée d’un toxique dans l’organisme est appelée : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Type d’exposition",
                    "b. Voie d’absorption"
                ),
                correctAnswers = listOf("b"),
                explanation = "b) Voie d’absorption. C'est la voie anatomique par laquelle le xénobiotique franchit les barrières biologiques pour pénétrer dans l'organisme (voie digestive, respiratoire, cutanée ou parentérale).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 7 (Form #12)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 7,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #12 (0.5 pt)",
                questionText = "7 (Form #12). La principale voie d'absorption du monoxyde de carbone qui est un toxique volatil, c'est : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La peau",
                    "b. Les voies aériennes supérieures",
                    "c. Les muqueuses oculaires"
                ),
                correctAnswers = listOf("b"),
                explanation = "b) Les voies aériennes supérieures (appareil respiratoire). Pour un gaz toxique ou volatil comme le monoxyde de carbone (CO), l'inhalation pulmonaire constitue la voie de pénétration quasi exclusive.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 8 (Form #13)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 8,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #13 (0.5 pt)",
                questionText = "8 (Form #13). La toxicité d’une substance pour un organisme peut être modifiée par l’exposition à une autre substance. On parle de synergie : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Lorsque l’introduction d’une substance dans l’organisme réduit la toxicité d’une autre substance.",
                    "b. Lorsque l’effet global de l’exposition à deux substances est égal à la somme des effets de chaque substance ou si l’effet global est plus grand que la somme des effets individuels"
                ),
                correctAnswers = listOf("b"),
                explanation = "b) Option proposée dans l'épreuve. Note de cours Pr TIGORI : Rigoureusement, la synergie vraie correspond à un effet global strictement supérieur à la somme (effet > somme). Si égal à la somme = additivité. Si réduction de toxicité = antagonisme.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 9 (Form #14)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 9,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #14 (0.5 pt)",
                questionText = "9 (Form #14). Pendant ces fêtes de pâques, Koudougnon est sous un traitement médicamenteux d'antibiotiques. Ses amis lui offrent 1 bouteille de bière et 1 bouteille de vin. Peut-il consommer ces bouteilles d'alcool ? (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf("a. Oui", "b. Non"),
                correctAnswers = listOf("b"),
                explanation = "b) Non. L'alcool est formellement déconseillé lors d'un traitement antibiotique en raison d'interactions métaboliques majeures et du risque d'effets secondaires graves (effet antabuse, hépatotoxicité).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 10 (Form #15)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 10,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #15 (0.5 pt)",
                questionText = "10 (Form #15). Pour quelle raison Koudougnon ne peut-il pas consommer ces bouteilles d'alcool avec ses antibiotiques ? Parce que : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La prise d'alcool ne modifie pas le métabolisme des médicaments",
                    "b. L’alcool éthylique est un inhibiteur enzymatique presqu’universel."
                ),
                correctAnswers = listOf("b"),
                explanation = "b) L'alcool éthylique en prise aiguë est un inhibiteur enzymatique presqu'universel des cytochromes hépatiques. Il ralentit l'élimination des médicaments et augmente considérablement leur toxicité.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 11 (Form #16)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 11,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #16 (0.5 pt)",
                questionText = "11 (Form #16). Les agents des stations à essence sont exposés aux effets toxiques du benzène car ils manipulent chaque jour du carburant pour les voitures. Cette exposition relève de la toxicologie professionnelle. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. L'exposition à des xénobiotiques toxiques sur le lieu et pendant l'exercice du travail relève de la toxicologie professionnelle / toxicologie du travail.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 12 (Form #17)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 12,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #17 (0.5 pt)",
                questionText = "12 (Form #17). Ces dernières années, beaucoup de jeunes s'adonnent à la consommation de la drogue. Le domaine de la toxicologie qui s'intéresse à ce phénomène est : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. L’hygiène sociale",
                    "b. La toxicologie de l’environnement",
                    "c. L’hygiène alimentaire",
                    "d. Le domaine des expertises judiciaires"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) L'hygiène sociale (toxicologie sociale). Elle étudie les pharmacodépendances, l'abus de substances, la toxicomanie et leurs répercussions sanitaires et sociétales.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 13 (Form #18)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 13,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #18 (0.5 pt)",
                questionText = "13 (Form #18). Les mycotoxines sont produites par certaines moisissures et on peut les trouver dans la nourriture. Ces substances naturelles sont des toxines. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. Une toxine est une substance toxique naturelle produite par un être vivant. Les mycotoxines sont produites par des moisissures (champignons microscopiques) et sont donc bien des toxines.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 14 (Form #19)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 14,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #19 (0.5 pt)",
                questionText = "14 (Form #19). Lorsque le toxique pénètre dans l'organisme par voie injectable, il est moins dangereux que par voie orale. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. La voie injectable est beaucoup plus dangereuse car la biodisponibilité est immédiate et intégrale (100% en IV), sans effet de premier passage hépatique ni barrière digestive.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 15 (Form #20)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 15,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #20 (0.5 pt)",
                questionText = "15 (Form #20). Certains habitants d'Akouedo ont présenté des effets liés à la toxicité des déchets déversés après 1 semaine d'exposition, on parle d'exposition aiguë. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. Une exposition d'une semaine relève de l'exposition subaiguë (jours à semaines). L'exposition aiguë correspond à une exposition unique ou répétée sur moins de 24 heures.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 16 (Form #21)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 16,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #21 (0.5 pt)",
                questionText = "16 (Form #21). Les effets de toxicité après 3 semaines d'exposition aux déchets toxiques sont liés à une exposition chronique. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. Trois semaines d'exposition correspondent à une exposition subaiguë (jusqu'à 3 semaines ou 1 mois). L'exposition chronique nécessite une durée prolongée continue ou répétée d'au moins 1 à 3 mois.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 17 (Form #22)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 17,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #22 (0.5 pt)",
                questionText = "17 (Form #22). La toxicologie moderne ouvre plusieurs axes de recherche dont l’expertise médico-légale encore appelée expertise judiciaire. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. Cours Pr TIGORI p.7-12 : La toxicologie moderne comprend l'expertise médico-légale/judiciaire, la toxicologie professionnelle, alimentaire, environnementale/écotoxicologie, sociale, biotoxicologie et réglementaire.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 18 (Form #23)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 18,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #23 (0.5 pt)",
                questionText = "18 (Form #23). On parle de surdosage médicamenteux lorsque : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Les posologies prescrites ne suffisent pas à soigner le patient",
                    "b. Les doses indiquées sont exactement suffisantes",
                    "c. Les prises de médicaments conduisent à des concentrations biologiques largement supérieures aux concentrations thérapeutiques",
                    "d. La marge thérapeutique est trop faible."
                ),
                correctAnswers = listOf("c"),
                explanation = "c) Les concentrations biologiques dépassent largement les concentrations thérapeutiques, franchissant le seuil toxique.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 19 (Form #24)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 19,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #24 (0.5 pt)",
                questionText = "19 (Form #24). L’hygiène alimentaire se préoccupe de la santé du consommateur. Elle s’attache à fixer des normes rigoureuses pour les additifs, à rechercher les résidus toxiques issus des pratiques culturales et des processus de transformations des denrées alimentaires par l’homme, ainsi qu'au contrôle : (0.5 points)",
                type = QuestionType.MULTIPLE_CHOICE,
                options = listOf(
                    "a. De la présence de mycotoxines dans les aliments",
                    "b. De la date de péremption indiquée sur les emballages des produits cosmétiques",
                    "c. De la destruction effective des aliments avariés."
                ),
                correctAnswers = listOf("a", "c"),
                explanation = "a & c. L'hygiène alimentaire surveille la présence de mycotoxines dans les aliments et contrôle la destruction effective des aliments avariés. La date de péremption des cosmétiques (b) relève de la cosmétologie réglementaire.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 2
            ),

            // Question 20 (Form #25)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 20,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #25 (0.5 pt)",
                questionText = "20 (Form #25). Un xénobiotique administré par la voie orale a une action plus rapide que s’il avait été administré par : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La voie intraveineuse",
                    "b. La voie intramusculaire."
                ),
                correctAnswers = listOf("b"),
                explanation = "Option retenue dans l'évaluation. Note scientifique : La voie orale est la plus lente parmi les voies classiques (IV > IM > SC > Orale) en raison de la dissolution digestive et du premier passage hépatique.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 21 (Form #26)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 21,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #26 (0.5 pt)",
                questionText = "21 (Form #26). La notion de véhicule associé est fondamentale dans la biodisponibilité des xénobiotiques. Deux personnes sont exposées de manière identique à des polluants pétroliers et solvants organiques (benzène, toluène, xylène...). La première avec régime allégé en lipides est peu incommodée, la seconde avec alimentation hyperlipidique souffre atrocement. Qu'est-ce qui justifie cette différence d'intensité ? (0.5 points)",
                type = QuestionType.MULTIPLE_CHOICE,
                options = listOf(
                    "a. Une intolérance naturelle",
                    "b. La sensibilisation",
                    "c. La nature du véhicule associé à travers l’alimentation",
                    "d. La différence de régime alimentaire basée sur l’abondance ou non de lipides."
                ),
                correctAnswers = listOf("c", "d"),
                explanation = "c & d. Cours Pr TIGORI p.20-23 : Les solvants organiques (benzène, toluène, xylène) sont hautement liposolubles. Une alimentation riche en graisses agit comme un véhicule lipidique favorisant leur solubilisation, absorption digestive et diffusion tissulaire.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 2
            ),

            // Question 22 (Form #27)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 22,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #27 (0.5 pt)",
                questionText = "22 (Form #27). Le bacille botulique, Clostridium botulinum est responsable de toxi-infections alimentaires redoutables du fait de la virulence de la toxine mise en jeu. La toxine est : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Un toxique naturel élaboré par le micro-organisme",
                    "b. Un toxique industriel",
                    "c. Un parasite qui a su intégrer la chaîne alimentaire."
                ),
                correctAnswers = listOf("a"),
                explanation = "a) Un toxique naturel élaboré par le micro-organisme. La toxine botulique est une neurotoxine bactérienne naturelle produite par Clostridium botulinum, l'une des toxines les plus puissantes connues.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 23 (Form #28)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 23,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #28 (0.5 pt)",
                questionText = "23 (Form #28). On vous signale dans votre entourage la présence d’un enfant de huit ans qui, depuis sa naissance, « ne supporte pas » la pénicilline. Vous expliquez aux parents troublés, qu’il s’agit d’un cas : (0.5 points)",
                type = QuestionType.MULTIPLE_CHOICE,
                options = listOf(
                    "a. D’intolérance naturelle,",
                    "b. D’idiosyncrasie,",
                    "c. De tolérance,",
                    "d. De pharmacodépendance."
                ),
                correctAnswers = listOf("a", "b"),
                explanation = "a & b. L'idiosyncrasie et l'intolérance naturelle sont synonymes dans le cours du Pr TIGORI : réactivité anormale d'origine génétique présente dès la naissance sans phase préalable de sensibilisation immunologique.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 2
            ),

            // Question 24 (Form #29)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 24,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #29 (0.5 pt)",
                questionText = "24 (Form #29). Un effet toxique systémique concerne : (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La zone de contact du toxique avec l’organisme,",
                    "b. Un ou deux organes voisins,",
                    "c. L’organisme dans son ensemble du fait de la distribution du toxique dans la circulation générale,",
                    "d. Les organes évacuateurs tels que les reins."
                ),
                correctAnswers = listOf("c"),
                explanation = "c) L’organisme dans son ensemble du fait de la distribution du toxique dans la circulation générale (contrairement à l'effet local qui reste circonscrit au point d'application/contact).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 25 (Form #30)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 25,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #30 (0.5 pt)",
                questionText = "25 (Form #30). La toxicologie moderne ouvre plusieurs axes de recherche dont l’expertise médico-légale encore appelée expertise judiciaire. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. L'expertise judiciaire/médico-légale est l'une des disciplines clés de la toxicologie permettant la recherche et l'identification des poisons dans le cadre de la justice.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 26 (Form #31)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 26,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #31 (0.5 pt)",
                questionText = "26 (Form #31). Une quantité de substance qui, introduite dans l’organisme, se révèle inférieure à la dose pouvant provoquer un malaise est la dose-seuille. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. Dans cette formulation d'évaluation, la dose-seuil délimite la quantité frontière en-dessous de laquelle aucun trouble ou malaise n'est décelable cliniquement.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 27 (Form #32)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 27,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #32 (0.5 pt)",
                questionText = "27 (Form #32). Une personne en contact avec une substance toxique est une personne contaminée. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. La contamination est le simple contact physique ou présence de la substance toxique sur la peau, les vêtements ou les muqueuses, avant ou sans qu'il y ait forcément intoxication avérée.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 28 (Form #33)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 28,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #33 (0.5 pt)",
                questionText = "28 (Form #33). L’ochratoxine A ou OTA est une mycotoxine. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. L'ochratoxine A (OTA) est une mycotoxine majeure produite par les moisissures Aspergillus et Penicillium, néphrotoxique et cancérogène, souvent dosée dans le café et le cacao.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 29 (Form #34)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 29,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #34 (0.5 pt)",
                questionText = "29 (Form #34). La toxicité d’une substance pour un organisme peut être modifiée par l’exposition à une autre substance. On parle de synergie lorsque l’introduction d’une substance dans l’organisme réduit la toxicité d’une autre substance. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. Lorsque l'introduction d'une substance réduit la toxicité d'une autre, il s'agit d'un ANTAGONISME (et non d'une synergie, qui amplifie l'effet).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 30 (Form #35)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 30,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #35 (0.5 pt)",
                questionText = "30 (Form #35). La muqueuse oculaire constitue la principale voie d'absorption de l'acide cyanidrique qui est un toxique volatil. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. L'acide cyanhydrique (HCN) est un gaz hautement volatil absorbé de façon prédominante et foudroyante par la voie respiratoire (alvéolaire). La voie oculaire est accessoire.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 31 (Form #36)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 31,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #36 (0.5 pt)",
                questionText = "31 (Form #36). Les intoxications par le monoxyde de carbone (CO) ne sont jamais mortelles. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. Le monoxyde de carbone (CO) est hautement mortel (formation de carboxyhémoglobine HbCO et anoxie cellulaire), responsable de nombreux décès chaque année.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 32 (Form #37)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 32,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #37 (0.5 pt)",
                questionText = "32 (Form #37). L'intoxication au méthanol est aggravée par la prise d'éthanol simultanée. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. L'éthanol est l'ANTIDOTE du méthanol ! L'éthanol a une affinité 10 fois supérieure pour l'alcool déshydrogénase (ADH), bloquant ainsi la transformation du méthanol en acide formique toxique.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 33 (Form #38)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 33,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #38 (0.5 pt)",
                questionText = "33 (Form #38). L'antidote d'une intoxication exclusive par benzodiazépines est le flumazénil. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. Le flumazénil (Anexate) est l'antagoniste spécifique et compétitif des récepteurs des benzodiazépines au niveau du récepteur GABA-A.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 34 (Form #39)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 34,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #39 (0.5 pt)",
                questionText = "34 (Form #39). La toxicologie s’intéresse aux moyens préventifs et curatifs permettant de combattre la nocivité des toxiques. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. La toxicologie étudie la prévention (normes, limites d'exposition) et les thérapeutiques curatives (antidotes, épuration digestive et rénale).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 35 (Form #40)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 35,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #40 (0.5 pt)",
                questionText = "35 (Form #40). La pharmacologie s’intéresse aux moyens préventifs et curatifs permettant de combattre la nocivité des toxiques. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("FAUX"),
                explanation = "FAUX. C'est le rôle de la toxicologie (toxicologie clinique et médicale). La pharmacologie traite des médicaments pour le traitement des pathologies.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 36 (Form #41)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 36,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #41 (0.5 pt)",
                questionText = "36 (Form #41). Les mycotoxines sont produites par certaines moisissures et on peut les trouver dans la nourriture. Ces substances naturelles sont des toxines. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. Les mycotoxines sont bien des toxines naturelles produites par des moisissures fongiques contaminant la chaîne alimentaire.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 37 (Form #42)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 37,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #42 (0.5 pt)",
                questionText = "37 (Form #42). L’érythropoïétine (EPO) fait partie des tests anti-dopages effectués au cours des compétitions internationales de cyclisme. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. L'érythropoïétine (EPO) augmente l'hématocrite et la capacité de transport d'oxygène ; elle est interdite et systématiquement recherchée lors des contrôles antidopage (toxicologie du sport).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 38 (Form #43)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 38,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #43 (0.5 pt)",
                questionText = "38 (Form #43). En cas d’ingestion, l’évacuation du toxique peut passer par : (0.5 points)",
                type = QuestionType.MULTIPLE_CHOICE,
                options = listOf(
                    "a. Des vomissements provoqués",
                    "b. Le lavage gastrique",
                    "c. L’administration de charbon activé",
                    "d. Une injection sous-cutanée d’apomorphine."
                ),
                correctAnswers = listOf("a", "b", "c", "d"),
                explanation = "Toutes les propositions (a, b, c, d) sont des techniques d'évacuation ou de détoxification digestive mentionnées dans le cours : vomissements provoqués, lavage gastrique, charbon activé (adsorption) et apomorphine SC (émétique puissant).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 4
            ),

            // Question 39 (Form #44)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 39,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #44 (0.5 pt)",
                questionText = "39 (Form #44). La toxicologie moderne ouvre plusieurs axes de recherche dont l’écotoxicologie. (0.5 points)",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf("VRAI"),
                explanation = "VRAI. L'écotoxicologie étudie la diffusion, la bioaccumulation et les effets délétères des polluants sur les écosystèmes et la biosphère.",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),

            // Question 40 (Form #45)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 40,
                contextText = "Évaluation Toxicologie PGP1 (10/08/2022) • Dr Bosson • Formulaire #45 (0.5 pt)",
                questionText = "40 (Form #45). À la date du 2 juin 2010, comment peut-on qualifier l’intoxication liée à une exposition de certaines populations à des rejets gazeux directement déversés dans l’air ambiant par une usine de matières plastiques depuis février 2010 ? (0.5 points)",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Une intoxication aiguë",
                    "b. Une intoxication chronique",
                    "c. Une intoxication suraiguë",
                    "d. Une intoxication subaiguë."
                ),
                correctAnswers = listOf("b"),
                explanation = "b) Une intoxication chronique. De février 2010 au 2 juin 2010 (4 mois d'exposition continue), la durée excède le seuil de 3 mois défini dans le cours du Pr TIGORI (p.33-34) pour l'exposition chronique. (Note : certains référentiels admettent la transition subaiguë/chronique).",
                positivePoints = 0.5f,
                negativePoints = 0.0f,
                maxChoices = 1
            )
        )
    }
}
