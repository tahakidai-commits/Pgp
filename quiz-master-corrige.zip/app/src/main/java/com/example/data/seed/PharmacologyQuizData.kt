package com.example.data.seed

import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.data.model.QuizEntity

object PharmacologyQuizData {

    fun createFullQuiz(): QuizEntity {
        return QuizEntity(
            id = 1L,
            title = "TD Pharmacologie (Complet)",
            description = "Travaux Dirigés Pharmacologie / PGP1 (2025-2026) - 65 questions avec barème officiel et corrigé détaillé.",
            category = "Pharmacologie",
            isBuiltIn = true,
            createdAt = 1710000000000L
        )
    }

    fun createQcdPartQuiz(): QuizEntity {
        return QuizEntity(
            id = 2L,
            title = "TD Pharmacologie - Vrai / Faux",
            description = "Questions à choix direct (QCD 1 à 30). Bonne réponse = +1 pt, mauvaise = -0.5 pt, non répondu = 0 pt.",
            category = "Pharmacologie",
            isBuiltIn = true,
            createdAt = 1710000001000L
        )
    }

    fun createQcmPartQuiz(): QuizEntity {
        return QuizEntity(
            id = 3L,
            title = "TD Pharmacologie - QCM & Cas Cliniques",
            description = "Questions à choix multiples (QCM 31 à 65). 2 bonnes réponses par question = 1 pt, 1 bonne réponse = 0.5 pt.",
            category = "Pharmacologie",
            isBuiltIn = true,
            createdAt = 1710000002000L
        )
    }

    fun getQuestionsForQuiz(quizId: Long): List<QuestionEntity> {
        return when (quizId) {
            1L -> getFullQuestions(quizId)
            2L -> getQcdQuestions(quizId)
            3L -> getQcmQuestions(quizId)
            else -> emptyList()
        }
    }

    private fun getFullQuestions(quizId: Long): List<QuestionEntity> {
        val qcd = getQcdQuestions(quizId)
        val qcm = getQcmQuestions(quizId)
        return qcd + qcm
    }

    fun getQcdQuestions(quizId: Long): List<QuestionEntity> {
        val questions = listOf(
            Triple(1, "La pharmacologie est une science qui permet d’élucider les mécanismes d’action des médicaments", "VRAI"),
            Triple(2, "La pharmacologie générale permet de comprendre les interactions entre les êtres vivants et les médicaments", "VRAI"),
            Triple(3, "Plus le T1/2 d’un médicament est long, plus le nombre de prise journalière est important", "FAUX"),
            Triple(4, "La thérapeutique est un moyen utilisé par les professionnels de la santé pour traiter les malades .", "VRAI"),
            Triple(5, "En ingestion chronique, l’alcool est capable de diminuer l’efficacité de certains médicaments.", "VRAI"),
            Triple(6, "La pharmacologie générale comprend la pharmacocinétique, la pharmacologie spéciale et la pharmacodynamie.", "FAUX"),
            Triple(7, "Un médicament peut être sous la forme liée aussi bien dans l’espace vasculaire que dans l’espace tissulaire.", "VRAI"),
            Triple(8, "L’albumine est la principale protéine qui fixe plus de médicaments au cours du processus de pharmacocinétique.", "VRAI"),
            Triple(9, "L’antagonisme non compétitif peut avoir lieu sur un même site d’action.", "FAUX"),
            Triple(10, "Tous les médicaments qui traitent une même maladie ont le même mécanisme d’action.", "FAUX"),
            Triple(11, "Tous les médicaments qui traitent une même maladie appartiennent à la même classe pharmacologique.", "FAUX"),
            Triple(12, "Tous les médicaments appartenant à la même classe pharmacologique ont les mêmes effets secondaires", "FAUX"),
            Triple(13, "Plus le taux de fixation aux protéines plasmatiques d’un médicament est élevé plus le médicament est efficace.", "FAUX"),
            Triple(14, "Toutes les classes pharmacologiques qui traitent la même pathologie appartiennent à la même classe thérapeutique.", "VRAI"),
            Triple(15, "L’irrigation sanguine limite généralement la diffusion tissulaire des médicaments.", "VRAI"),
            Triple(16, "Un excipient est une substance qui n’a pas d’indication en thérapeutique mais peut entrainer des effets indésirables.", "VRAI"),
            Triple(17, "La barrière fœto-placentaire ne se laisse traverser que par des substances lipophiles.", "FAUX"),
            Triple(18, "Un déficit héréditaire dans le système enzymatique peut modifier la biotransformation des médicaments.", "VRAI"),
            Triple(19, "Le développement préclinique est la partie expérimentale in vitro et in vivo qui a lieu chez l'homme.", "FAUX"),
            Triple(20, "Toutes les barrières de l’organisme ont les mêmes composantes excepté le placenta.", "FAUX"),
            Triple(21, "La potentialisation est le fait d’obtenir un métabolite plus actif que le médicament d’origine", "FAUX"),
            Triple(22, "L’automédication concerne aussi bien les médicaments modernes que les médicaments traditionnels", "VRAI"),
            Triple(23, "Un médicament bien conservé reste efficace au-delà de sa date de péremption", "FAUX"),
            Triple(24, "Les réactions de phase I permettent d’avoir des composés partiellement hydrosolubles.", "VRAI"),
            Triple(25, "Le foie est le principal organe de métabolisation des médicaments donc il renferme un grand nombre d'enzymes microsomiales.", "FAUX"),
            Triple(26, "Un médicament fortement lié aux protéines plasmatiques se retrouve préférentiellement dans l’espace plasmatique.", "VRAI"),
            Triple(27, "Deux agonistes ayant un même récepteur peuvent avoir des affinités différentes pour ce récepteur", "VRAI"),
            Triple(28, "La liposolubilité est la principale condition de passage des médicaments dans les urines.", "FAUX"),
            Triple(29, "Les réactions allergiques sont dues aux propriétés pharmacologiques des médicaments.", "FAUX"),
            Triple(30, "La sécrétion active est un mécanisme d’excrétion des médicaments saturable car elle nécessite de l’énergie", "FAUX")
        )

        return questions.map { (index, text, answer) ->
            QuestionEntity(
                quizId = quizId,
                questionIndex = index,
                contextText = "Section I - Questions à choix direct (QCD) : Répondre par VRAI (A) ou FAUX (B)\nBarème : Bonne réponse = +1 pt, Mauvaise réponse = -0,5 pt, Sans réponse = 0 pt",
                questionText = "$index- $text",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf(answer),
                explanation = "Corrigé officiel : $answer",
                positivePoints = 1.0f,
                negativePoints = 0.5f,
                maxChoices = 1
            )
        }
    }

    fun getQcmQuestions(quizId: Long): List<QuestionEntity> {
        val list = mutableListOf<QuestionEntity>()

        val case1 = "Mr A L souffre d’une lésion de l’intestin grêle et prend un médicament (M) qualifié de pansement gastrique pour une action locale. (Questions 31 à 37)"
        val case1b = "Deux jours après Mr AL prend un autre médicament D par automédication car il sentait des maux de tête. D est un médicament à prendre par voie orale pour une action générale."

        val case2 = "Après une consultation médicale, Mr KAMESS reçoit une ordonnance comportant 3 médicaments M1, M2 et M3. M1 est un médicament à marge thérapeutique étroite (MMTE). M1 et M2 se lient aux protéines plasmatiques respectivement à 98% et 96%. M3 est à la fois inducteur de l’enzyme qui dégrade M1 et inhibiteur de l’enzyme qui dégrade M2. (Questions 56 à 65)"
        val case2Transport = "Les médicaments M2 et M3 sont excrétés via le phénomène de sécrétion active à travers les mêmes transporteurs. M2 a une forte affinité pour ces transporteurs."
        val case2Agonist = "M1 est un agoniste entier tandis que M3 est un agoniste partiel vis-à-vis de la même pathologie."
        val case2AutoM4 = "Mr KAMESS non satisfait par les résultats du traitement initié par le médecin, décide d’utiliser le médicament M4 par automédication. Il se trouve que M4 est un antagoniste compétitif de M1 et un antagoniste non compétitif de M3."

        fun addQcm(
            index: Int,
            context: String?,
            questionText: String,
            options: List<String>,
            correct: List<String>,
            explanation: String? = null
        ) {
            val qcmRule = "Section II - QCM (Choisir les 2 réponses) : 2 bonnes = +1 pt, 1 bonne sans erreur = +0.5 pt"
            val combinedContext = if (context != null) "$context\n\n$qcmRule" else qcmRule
            list.add(
                QuestionEntity(
                    quizId = quizId,
                    questionIndex = index,
                    contextText = combinedContext,
                    questionText = "$index- $questionText",
                    type = QuestionType.MULTIPLE_CHOICE,
                    options = options,
                    correctAnswers = correct,
                    explanation = explanation ?: "Corrigé officiel : ${correct.joinToString(", ")}",
                    positivePoints = 1.0f,
                    negativePoints = 0.0f,
                    maxChoices = 2
                )
            )
        }

        // Q31
        addQcm(
            31, case1,
            "Indiquer les deux réponses inexactes concernant ce médicament. Il",
            listOf(
                "a- Subit l’effet de premier passage intestinal",
                "b- N’atteint pas la circulation générale",
                "c- Subit l’effet de premier passage hépatique",
                "d- Est éliminé sous la forme intacte"
            ),
            listOf("a", "c"),
            "Corrigé : a et c sont inexactes (M est un pansement à action locale, il ne subit pas les premiers passages digestifs/hépatiques)."
        )

        // Q32
        addQcm(
            32, case1,
            "Choisir les deux bonnes réponses. Ce médicament (M)",
            listOf(
                "a- Est éliminé sous forme inchangée",
                "b- Est éliminé par voie rénale",
                "c- Est éliminé par voie hépatique",
                "d- Est éliminé par voie intestinale"
            ),
            listOf("a", "d"),
            "Corrigé : a et d (éliminé sous forme inchangée par voie intestinale)."
        )

        // Q33
        addQcm(
            33, "$case1\n$case1b",
            "Indiquer les deux bonnes propositions. La prise concomitante de M et D",
            listOf(
                "a- Peut rendre D inefficace",
                "b- Peut rendre D plus toxique",
                "c- Peut empêcher l’absorption de D",
                "d- Ne modifie pas l’action de D"
            ),
            listOf("a", "c"),
            "Corrigé : a et c (le pansement gastrique M adsorbe ou tapisse, empêchant l'absorption de D et rendant D inefficace)."
        )

        // Q34
        addQcm(
            34, "$case1\n$case1b",
            "Indiquer les deux mauvaises propositions. La prise concomitante de M et D",
            listOf(
                "a- Peut rendre M inefficace",
                "b- Peut rendre M plus toxique",
                "c- N’empêche pas l’élimination de M",
                "d- Ne modifie pas l’efficacité de M"
            ),
            listOf("a", "b"),
            "Corrigé : a et b sont les deux mauvaises propositions."
        )

        // Q35
        addQcm(
            35, "$case1\n$case1b",
            "Les deux conséquences liées à la prise concomitante des médicaments M et D sont :",
            listOf(
                "a- Une aggravation des maux de tête de Mr AL",
                "b- Une augmentation des effets indésirables de D",
                "c- Une augmentation de l’efficacité de D",
                "d- Une diminution de la biodisponibilité de D"
            ),
            listOf("a", "d"),
            "Corrigé : a et d (diminution de biodisponibilité de D, donc aggravation/persistance des maux de tête)."
        )

        // Q36
        addQcm(
            36, "$case1\n$case1b",
            "Indiquer les deux causes probables qui ont poussé Mr AL à prendre le médicament D",
            listOf(
                "a- La méconnaissance du symptôme de la maladie de Mr AL",
                "b- L’obtention de D sur conseil de son voisin non professionnel de santé",
                "c- Aisance financière qui lui permet d’acheter ce qu’il souhaite",
                "d- Difficulté à expliquer ses symptômes à un médecin par pudeur"
            ),
            listOf("a", "b"),
            "Corrigé : a et b."
        )

        // Q37
        addQcm(
            37, "$case1\n$case1b",
            "Indiquer deux conséquences de la pratique de Mr AL pour l’obtention du médicament D",
            listOf(
                "a- Mr AL peut se tromper de diagnostic",
                "b- La prise optimale du médicament D par Mr AL",
                "c- La survenue d’effets toxiques",
                "d- Le respect des précautions d’emploi de D"
            ),
            listOf("a", "c"),
            "Corrigé : a et c (erreur diagnostique et risque de toxicité de l'automédication non éclairée)."
        )

        // Q38
        addQcm(
            38, null,
            "Indiquer les deux paramètres qui ne permettent pas de quantifier l’absorption des médicaments",
            listOf(
                "a- Le coefficient de résorption",
                "b- La demi-vie du médicament",
                "c- La biodisponibilité",
                "d- L’effet thérapeutique"
            ),
            listOf("b", "d"),
            "Corrigé : b et d (la demi-vie et l'effet thérapeutique ne quantifient pas l'absorption)."
        )

        // Q39
        addQcm(
            39, null,
            "Indiquer les deux bonnes propositions, le lait maternel",
            listOf(
                "a- A un pH supérieur à celui du sang",
                "b- Favorise l’accumulation des médicaments ayant un pH inférieur à 7",
                "c- Favorise l’accumulation des médicaments ayant un pH supérieur à 7",
                "d- Est le siège du phénomène « ions trapping ou piège à ions »"
            ),
            listOf("c", "d"),
            "Corrigé : c et d (le lait maternel plus acide favorise le piégeage ionique des bases faibles, pH > 7)."
        )

        // Q40
        addQcm(
            40, null,
            "Indiquer les deux bonnes propositions, les effets indésirables d’un médicament",
            listOf(
                "a- Surviennent aux doses toxiques",
                "b- Sont toujours de survenue imprévisible",
                "c- Surviennent chez tous les patients",
                "d- Sont constants pour une dose donnée."
            ),
            listOf("a", "b"),
            "Corrigé : a et b (d'après le corrigé officiel TD)."
        )

        // Q41
        addQcm(
            41, null,
            "Identifier les deux bonnes propositions concernant la P-glycoprotéine (PGP), elle",
            listOf(
                "a- Se comporte comme un transporteur membranaire",
                "b- Est logée au niveau des plusieurs barrières de l’organisme",
                "c- Est qualifiée de protéine de reflux pour divers médicaments",
                "d- Fonctionne indifféremment des inducteurs et inhibiteurs enzymatiques"
            ),
            listOf("b", "c"),
            "Corrigé : b et c (présente dans de multiples barrières physiologiques et agit comme pompe d'efflux)."
        )

        // Q42
        addQcm(
            42, null,
            "Le volume de distribution d’un médicament",
            listOf(
                "a- Se calcule en divisant la concentration sanguine du médicament à la quantité de médicament administrée",
                "b- Se calcule en multipliant la concentration sanguine du médicament à la quantité de médicament administrée",
                "c- Est exprimé en Litre par Kilogramme (L/Kg)",
                "d- N’est pas une représentation anatomique de la répartition de la molécule"
            ),
            listOf("c", "d"),
            "Corrigé : c et d (Vd est un volume fictif exprimé en L ou L/kg, non anatomique)."
        )

        // Q43
        addQcm(
            43, null,
            "Deux parmi les propositions suivantes sont correctes, lesquelles ? une prodrogue",
            listOf(
                "a- Est utilisée uniquement en vue d’une action générale",
                "b- Est considérée comme un placebo",
                "c- Agit à travers son métabolite",
                "d- Est utilisée uniquement pour les essais cliniques"
            ),
            listOf("a", "c"),
            "Corrigé : a et c (inactive au départ, elle agit via son métabolite actif après biotransformation)."
        )

        // Q44
        addQcm(
            44, null,
            "Les deux facteurs physiopathologiques pouvant influencer la biotransformation des médicaments sont",
            listOf(
                "a- Les maladies hépatiques",
                "b- Les enfants",
                "c- L’alcool",
                "d- Le tabac"
            ),
            listOf("a", "b"),
            "Corrigé : a et b (facteurs physiopathologiques / âge / pathologie hépatique vs toxiques/environnementaux)."
        )

        // Q45
        addQcm(
            45, null,
            "Deux parmi les éléments suivants peuvent se comporter comme des inducteurs enzymatiques lesquels ?",
            listOf(
                "a- Le tabac",
                "b- L’alcool en ingestion occasionnelle",
                "c- L’alcool en ingestion chronique",
                "d- Le jus de pamplemousse"
            ),
            listOf("a", "c"),
            "Corrigé : a et c (le tabac et l'alcool chronique sont des inducteurs, le pamplemousse est un inhibiteur)."
        )

        // Q46
        addQcm(
            46, null,
            "Indiquer les deux bonnes propositions, le cycle entéro-hépatique",
            listOf(
                "a- Est lié à l’action des enzymes intestinales",
                "b- Concerne les métabolites conjugués",
                "c- Est un processus d’élimination des médicaments",
                "d- Permet une augmentation de la biodisponibilité du médicament"
            ),
            listOf("b", "d"),
            "Corrigé : b et d (hydrolyse des glucuronoconjugués dans la bile et réabsorption augmentant la biodisponibilité)."
        )

        // Q47
        addQcm(
            47, null,
            "Indiquer les deux facteurs exogènes qui influencent l’excrétion rénale des médicaments",
            listOf(
                "a- Les âges extrêmes",
                "b- La modification du pH urinaire",
                "c- Le phénomène de compétition au niveau de la sécrétion tubulaire",
                "d- L’insuffisance rénale"
            ),
            listOf("b", "c"),
            "Corrigé : b et c (facteurs exogènes modifiables / interactions vs facteurs physiopathologiques intrinsèques)."
        )

        // Q48
        addQcm(
            48, null,
            "Choisir les deux bonnes propositions, un effet indésirable grave",
            listOf(
                "a- Nécessite un traitement correcteur avec hospitalisation",
                "b- Nécessite un traitement correcteur sans hospitalisation",
                "c- Ne nécessite pas un traitement correcteur",
                "d- Est susceptible de mettre la vie du patient en danger"
            ),
            listOf("a", "d"),
            "Corrigé : a et d (critères de gravité en pharmacovigilance : hospitalisation ou mise en jeu du pronostic vital)."
        )

        // Q49
        addQcm(
            49, null,
            "Les vaccins ne sont pas des médicaments",
            listOf(
                "a- Préventifs",
                "b- Curatifs",
                "c- Substitutifs",
                "d- Prophylactiques"
            ),
            listOf("b", "c"),
            "Corrigé : b et c (les vaccins sont préventifs et prophylactiques, pas curatifs ni substitutifs)."
        )

        // Q50
        addQcm(
            50, null,
            "Choisir les deux bonnes propositions, l’observance thérapeutique",
            listOf(
                "a- Est recherchée lors de la surveillance d’un traitement",
                "b- Est recherchée au cours des essais cliniques de phase I",
                "c- Prend en compte les recommandations orales du prescripteur",
                "d- Est un paramètre pharmacocinétique"
            ),
            listOf("a", "c"),
            "Corrigé : a et c (surveillance de l'adhésion au traitement et respect des conseils oraux et écrits)."
        )

        // Q51
        addQcm(
            51, null,
            "Choisir les deux bonnes propositions, les essais cliniques de phase III",
            listOf(
                "a- Permettent de confirmer l’efficacité du médicament",
                "b- Consistent à comparer la substance à un médicament de référence",
                "c- Se déroulent sur un petit effectif",
                "d- Permettent de déterminer les effets pharmacodynamiques de la substance"
            ),
            listOf("a", "b"),
            "Corrigé : a et b (phase pivot comparative multicentrique pour confirmer l'efficacité)."
        )

        // Q52
        addQcm(
            52, null,
            "Indiquer les deux formes d’automédication",
            listOf(
                "a- La consommation d’un ancien médicament présent dans la pharmacie domestique",
                "b- Se procurer un médicament après un conseil pharmaceutique",
                "c- Acheter un médicament après présentation d’une ordonnance",
                "d- Prendre un médicament après un conseil d’un voisin de quartier"
            ),
            listOf("a", "d"),
            "Corrigé : a et d (automédication directe sans professionnel)."
        )

        // Q53
        addQcm(
            53, null,
            "Parmi les dénominations suivantes, deux concernent les médicaments",
            listOf(
                "a- Dénomination clinique",
                "b- Dénomination spéciale",
                "c- Dénomination commune",
                "d- Dénomination thérapeutique"
            ),
            listOf("c", "d"),
            "Corrigé : c et d (DCI - Dénomination Commune Internationale, etc.)."
        )

        // Q54
        addQcm(
            54, null,
            "Choisir les deux types de médicaments suivants",
            listOf(
                "a- Médicaments pharmacologiques",
                "b- Médicaments chimiques",
                "c- Médicaments substitutifs",
                "d- Médicaments prophylactiques"
            ),
            listOf("c", "d"),
            "Corrigé : c et d."
        )

        // Q55
        addQcm(
            55, null,
            "Indiquer les deux propositions exactes, Le placebo",
            listOf(
                "a- Est utilisé dans les essais cliniques de phase IIb",
                "b- Intervient dans les essais cliniques de phase III",
                "c- Est comparé à la substance de référence",
                "d- Est comparé à la substance soumise à l’étude"
            ),
            listOf("b", "d"),
            "Corrigé : b et d."
        )

        // Q56
        addQcm(
            56, case2,
            "La prise concomitante de M1 et de M2 peut :",
            listOf(
                "a- Augmenter les effets indésirables de M2",
                "b- Peut faire apparaitre les effets toxiques de M1",
                "c- Peut renforcer l’efficacité de M1",
                "d- Peut diminuer les effets indésirables de M2"
            ),
            listOf("a", "b"),
            "Corrigé : a et b (déplacement de liaison protéique pour M1 à marge étroite = toxicité, et effets de M2)."
        )

        // Q57
        addQcm(
            57, case2,
            "La prise concomitante de M1 et de M3 permet de",
            listOf(
                "a- Renforcer l’efficacité de M1",
                "b- Renforcer l’efficacité de M3",
                "c- Diminuer la biodisponibilité de M1",
                "d- Diminuer l’efficacité de M1"
            ),
            listOf("c", "d"),
            "Corrigé : c et d (M3 est inducteur de l'enzyme dégradant M1, donc M1 est éliminé plus vite = biodisponibilité et efficacité diminuées)."
        )

        // Q58
        addQcm(
            58, case2,
            "La prise concomitante de M2 et de M3 permet de",
            listOf(
                "a- Diminuer la biodisponibilité de M2",
                "b- Augmenter les effets indésirables de M2",
                "c- Renforcer l’efficacité de M2",
                "d- Diminuer l’efficacité de M2"
            ),
            listOf("b", "c"),
            "Corrigé : b et c (M3 est inhibiteur enzymatique de M2, concentration de M2 s'élève = augmentation d'efficacité et effets indésirables)."
        )

        // Q59
        addQcm(
            59, case2,
            "La prise concomitante de M2 et de M3",
            listOf(
                "a- Ne modifie pas l’efficacité de M3",
                "b- Diminue les effets indésirables de M3",
                "c- Renforce l’efficacité de M3",
                "d- Ne modifie pas les effets indésirables de M3"
            ),
            listOf("a", "d"),
            "Corrigé : a et d (M2 n'affecte pas le métabolisme de M3)."
        )

        // Q60
        addQcm(
            60, "$case2\n$case2Transport",
            "Choisir les deux bonnes propositions :",
            listOf(
                "a- L’excrétion de M3 peut être retardée",
                "b- L’excrétion de M2 peut être retardée",
                "c- Les effets indésirables de M2 peuvent apparaitre",
                "d- M2 sera premièrement excrété"
            ),
            listOf("a", "d"),
            "Corrigé : a et d (M2 ayant une plus forte affinité pour les transporteurs, il est excrété en premier et retarde M3)."
        )

        // Q61
        addQcm(
            61, "$case2\n$case2Agonist",
            "Choisir les deux bonnes propositions concernant ces agonistes",
            listOf(
                "a- L’activité intrinsèque de M1 est égale à 1",
                "b- L’activité intrinsèque de M1 est inférieure à 1",
                "c- L’activité intrinsèque de M1 est supérieure à 1",
                "d- M1 est plus efficace que M3"
            ),
            listOf("a", "d"),
            "Corrigé : a et d (agoniste entier : activité intrinsèque alpha = 1, efficacité maximale supérieure à l'agoniste partiel M3)."
        )

        // Q62
        addQcm(
            62, "$case2\n$case2Agonist",
            "Indiquer les deux bonnes propositions suivantes",
            listOf(
                "a- L’activité intrinsèque de M3 est égale à 1",
                "b- L’activité intrinsèque de M3 est comprise en 0 et 1",
                "c- L’activité intrinsèque de M3 est égale à 0",
                "d- M3 peut se comporter comme un antagoniste"
            ),
            listOf("b", "d"),
            "Corrigé : b et d (agoniste partiel : 0 < alpha < 1, et en présence d'un agoniste entier il peut se comporter comme un antagoniste compétitif partiel)."
        )

        // Q63
        addQcm(
            63, "$case2\n$case2AutoM4",
            "Choisir les deux bonnes propositions",
            listOf(
                "a- L’activité intrinsèque de M4 est égale à 1",
                "b- L’activité intrinsèque de M4 est comprise en 0 et 1",
                "c- L’activité intrinsèque de M4 est égale à 0",
                "d- L’activité intrinsèque de M4 est inférieure à 1"
            ),
            listOf("c", "d"),
            "Corrigé : c et d (un antagoniste a une activité intrinsèque alpha = 0, ce qui est strictement < 1)."
        )

        // Q64
        addQcm(
            64, "$case2\n$case2AutoM4",
            "Choisir les deux propositions inexactes :",
            listOf(
                "a- M4 peut augmenter l’efficacité de M1",
                "b- M1 et M4 ont le même récepteur",
                "c- M1 et M4 rentreront en compétition",
                "d- M1 et M4 auront les mêmes effets indésirables"
            ),
            listOf("a", "d"),
            "Corrigé : a et d sont les deux propositions inexactes (M4 antagonise M1 et n'a pas les mêmes effets)."
        )

        // Q65
        addQcm(
            65, "$case2\n$case2AutoM4",
            "Choisir les deux bonnes propositions",
            listOf(
                "a- M4 peut modifier le site d’action de M3",
                "b- M4 et M3 ont le même site d’action",
                "c- M4 peut diminuer l’efficacité de M3",
                "d- M4 et M3 rentreront en compétition"
            ),
            listOf("a", "c"),
            "Corrigé : a et c (antagonisme non compétitif : liaison allostérique modifiant la confirmation du site d'action et diminuant l'effet max)."
        )

        return list
    }
}
