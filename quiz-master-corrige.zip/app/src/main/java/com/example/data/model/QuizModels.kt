package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import org.json.JSONArray

enum class QuestionType {
    TRUE_FALSE,
    MULTIPLE_CHOICE,
    SINGLE_CHOICE
}

@Entity(tableName = "quizzes")
data class QuizEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val category: String,
    val isBuiltIn: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val quizId: Long,
    val questionIndex: Int,
    val contextText: String? = null,
    val questionText: String,
    val type: QuestionType,
    val options: List<String>,
    val correctAnswers: List<String>,
    val explanation: String? = null,
    val positivePoints: Float = 1.0f,
    val negativePoints: Float = 0.5f,
    val maxChoices: Int = 1
)

@Entity(tableName = "quiz_attempts")
data class QuizAttemptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val quizId: Long,
    val quizTitle: String,
    val score: Float,
    val maxScore: Float,
    val correctCount: Int,
    val wrongCount: Int,
    val unansweredCount: Int,
    val timeTakenSeconds: Int,
    val completedAt: Long = System.currentTimeMillis(),
    val userAnswersJson: String
)

class Converters {
    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        if (list == null) return "[]"
        val array = JSONArray()
        list.forEach { array.put(it) }
        return array.toString()
    }

    @TypeConverter
    fun toStringList(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        val result = mutableListOf<String>()
        val array = JSONArray(json)
        for (i in 0 until array.length()) {
            result.add(array.getString(i))
        }
        return result
    }

    @TypeConverter
    fun fromQuestionType(type: QuestionType): String = type.name

    @TypeConverter
    fun toQuestionType(value: String): QuestionType {
        return try {
            QuestionType.valueOf(value)
        } catch (e: Exception) {
            QuestionType.MULTIPLE_CHOICE
        }
    }
}
