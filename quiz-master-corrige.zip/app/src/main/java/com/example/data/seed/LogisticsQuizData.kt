package com.example.data.seed

import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.data.model.QuizEntity

object LogisticsQuizData {

    fun createFullQuiz(): QuizEntity {
        return QuizEntity(
            id = 20L,
            title = "TD Gestion Logistique PGP1 (Complet)",
            description = "TD Gestion Logistique des Produits de Santé PGP1 - 42 questions avec corrigé officiel (+1/-1 en Vrai/Faux, +1/0 en QCM).",
            category = "Gestion Logistique",
            isBuiltIn = true,
            createdAt = 1710000020000L
        )
    }

    fun createVraiFauxQuiz(): QuizEntity {
        return QuizEntity(
            id = 21L,
            title = "TD Logistique - Vrai ou Faux",
            description = "Partie I (Q1 à Q25) : 25 questions Vrai ou Faux sur les produits de santé, médicaments essentiels et approvisionnement (+1 pt si exact, -1 pt si faux).",
            category = "Gestion Logistique",
            isBuiltIn = true,
            createdAt = 1710000021000L
        )
    }

    fun createQcmQuiz(): QuizEntity {
        return QuizEntity(
            id = 22L,
            title = "TD Logistique - QCM à Choix Unique",
            description = "Partie II (Q26 à Q42) : 17 QCM sur CMM, LNME, substitution, chaîne d'approvisionnement, prévisions, PUSH/PULL, PSP (+1 pt si exact, 0 pt si faux).",
            category = "Gestion Logistique",
            isBuiltIn = true,
            createdAt = 1710000022000L
        )
    }

    fun getQuestionsForQuiz(quizId: Long): List<QuestionEntity> {
        return when (quizId) {
            20L -> getFullQuestions(quizId)
            21L -> getPart1VraiFaux(quizId)
            22L -> getPart2Qcm(quizId, offset = 0)
            else -> emptyList()
        }
    }

    private fun getFullQuestions(quizId: Long): List<QuestionEntity> {
        val p1 = getPart1VraiFaux(quizId)
        val p2 = getPart2Qcm(quizId, offset = 25)
        return p1 + p2
    }

    fun getPart1VraiFaux(quizId: Long): List<QuestionEntity> {
        return listOf(
            QuestionEntity(
                quizId = quizId,
                questionIndex = 1,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les produits De santé participent uniquement au bien-être physique",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. Selon la définition de la santé par l'OMS, elle englobe le bien-être physique, mental et social, et non pas uniquement physique.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 2,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les médicaments ne possèdent Que des propriétés curatives.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. Les médicaments possèdent des propriétés préventives (vaccins, prophylaxie), diagnostiques, palliatives ou substitutives, en plus des propriétés curatives.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 3,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Seules les maladies humaines sont prises en charge par les médicaments",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. Il existe également les médicaments vétérinaires destinés aux animaux.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 4,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Tout produit de diagnostic médical est un médicament",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. De nombreux produits de diagnostic in vitro (réactifs, bandelettes, automates) sont classés comme dispositifs médicaux (DMDIV) et non comme médicaments.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 5,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les médicaments essentiels sont sélectionnés en fonction de la prévalence des maladies",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. La prévalence et la charge de morbidité des maladies prioritaires constituent un critère fondamental pour la sélection des médicaments essentiels selon l'OMS.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 6,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les médicaments essentiels sont sélectionnés en fonction De la prévalence des patients",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. L'expression appropriée est la prévalence de la pathologie / morbidité dans la population, non pas la 'prévalence des patients'.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 7,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "La facilité d'emploi est un critère de sélection Des médicaments essentiels",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. La facilité d'administration et d'observance (ex: posologie simple, conservation aisée) est l'un des critères de choix retenus par l'OMS.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 8,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les spécialités pharmaceutiques peuvent être des médicaments essentiels",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. Un médicament essentiel est identifié par sa DCI mais peut tout à fait être commercialisé et dispensé sous forme de spécialité pharmaceutique.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 9,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les médicaments génériques Sont toujours des médicaments essentiels",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. Beaucoup de médicaments génériques concernent des molécules de confort ou non prioritaires ne figurant pas sur la Liste Nationale des Médicaments Essentiels (LNME).",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 10,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Toute substitution dans la délivrance de médicaments est décidée par le pharmacien .",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. Le prescripteur peut apposer une mention de non-substitution (ex: 'Non Substituable' justifiée médicalement), et la substitution obéit à une réglementation stricte.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 11,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Le médicament peut être symptomatiques",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. Un médicament peut agir purement sur les symptômes sans éliminer la cause étiologique (ex: antalgiques, antipyrétiques).",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 12,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les produits SRMNIN sont uniquement destinés aux enfants",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. SRMNIN correspond à Santé de la Reproduction, de la Mère, du Nouveau-né, de l'Infant et de l'Adolescent/Nutrition (concerne donc aussi les mères et les femmes enceintes).",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 13,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "La contrefaçon d'un médicament porte uniquement sur le mauvais dosage des principes actifs.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. La contrefaçon peut concerner l'absence totale de PA, la présence de substances toxiques, l'usurpation d'identité/marque, ou le conditionnement falsifié.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 14,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "La pharmacie peut procéder à la destruction Des PPI",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. La destruction des produits pharmaceutiques inutilisables / périmés (PPI) obéit à une procédure réglementée stricte avec commission agréée et procès-verbal officiel, et ne se fait pas unilatéralement à la pharmacie.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 15,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les équipements de laboratoires Sont des dispositifs médicaux",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. Ils entrent dans la catégorie des dispositifs médicaux de diagnostic in vitro (DMDIV) et équipements médicaux.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 16,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "La chaine d'approvisionnement ne gère que des flux physiques",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. La chaîne d'approvisionnement gère simultanément 3 types de flux : physiques (produits), d'informations (données, stocks, commandes) et financiers.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 17,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "La chaine d'approvisionnement prend en compte les installations Des stockages et les moyens de transport",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. Les entrepôts, magasins, équipements de chaîne du froid et flottes logistiques constituent l'infrastructure essentielle de la chaîne.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 18,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Les ONG sont partie prenantes De la chaine d’approvisionnement",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. Les ONG partenaires techniques et financiers jouent un rôle actif dans l'approvisionnement et la distribution de produits de santé prioritaires.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 19,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "La disponibilité est un critère de sélection des produits De santé",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. La disponibilité commerciale et la pérennité d'approvisionnement chez les fabricants sont indispensables lors de la sélection.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 20,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "La quantification Peut être basée sur les données épidémiologiques De la sous région.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. La méthode de morbidité / épidémiologique est l'une des méthodes majeures de quantification des besoins sanitaires.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 21,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Seuls les apports nationaux financent Les acquisitions des produits De santé",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. Les bailleurs internationaux (Fonds Mondial, Gavi, USAID, Banque Mondiale) contribuent largement au financement des produits de santé.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 22,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "La quantification comprend 4 étapes",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. Selon le guide standard de quantification : 1. Préparation, 2. Prévisions (Forecasting), 3. Planification des approvisionnements (Supply planning), 4. Révision et actualisation.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 23,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "En système d'allocations c'est Le niveau supérieur qui détermine les quantités de produits reçus Par le niveau inférieur",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. C'est le principe du système PUSH (dotation / allocation), où le niveau échelon supérieur impose et calcule les dotations pour les structures subordonnées.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 24,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "L'adjudication est un mode d’acquisition de produits Entre le fournisseur Et la centrale d'achat",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "Corrigé : Vrai. L'adjudication (appel d'offres) est le mode contractuel standard par lequel la centrale d'achat sélectionne ses fournisseurs selon le code des marchés publics.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 25,
                contextText = "Consigne : Cochez Vrai ou Faux (+1 si exact, -1 si faux, 0 si pas de réponse)",
                questionText = "Le gré à gré est un mode d’acquisition de produits entre La centrale d'achat et les structures sanitaires",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "Corrigé : Faux. La relation entre la centrale d'achat et les structures sanitaires relève de la cession/distribution publique (commandes ou dotations), tandis que le gré à gré est une procédure exceptionnelle de passation de marché avec un fournisseur sans mise en concurrence.",
                positivePoints = 1.0f,
                negativePoints = 1.0f,
                maxChoices = 1
            )
        )
    }

    fun getPart2Qcm(quizId: Long, offset: Int = 0): List<QuestionEntity> {
        return listOf(
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 1,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "CMM signifie :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Consommation moyenne mensuelle",
                    "b. Consommation mensuelle moyenne",
                    "c. Consommation de Médicaments du Mois"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. CMM = Consommation Moyenne Mensuelle (indicateur clé en gestion des stocks pour le calcul du stock de sécurité et des commandes).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 2,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Les produits de santé comprennent :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. kits et DM",
                    "b. kits, DM et médicaments",
                    "c. médicaments, DM et équipements médicaux"
                ),
                correctAnswers = listOf("b"),
                explanation = "Corrigé : b. Selon le cours, les produits de santé englobent les médicaments, les dispositifs médicaux (DM) et les kits.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 3,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Font partie des médicaments :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. les produits utilisés pour la prothèse dentaire",
                    "b. les plaquettes sanguines",
                    "c. les produits stériles à usage médical"
                ),
                correctAnswers = listOf("c"),
                explanation = "Corrigé : c. Les produits stériles à usage médical font partie des médicaments (les prothèses sont des DM et les plaquettes relèvent des produits sanguins labiles).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 4,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Font partie des médicaments :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. les produits réduisant l'accoutumance au tabac",
                    "b. les objets de pansement",
                    "c. les articles de désinfection"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. Les substituts nicotiniques et médicaments de sevrage tabagique sont légalement des médicaments.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 5,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Les médicaments essentiels :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Sont les plus courant",
                    "b. Satisfont aux besoins de la majorité de la population",
                    "c. Sont indispensables au traitement de toute pathologie"
                ),
                correctAnswers = listOf("b"),
                explanation = "Corrigé : b. Définition officielle de l'OMS : les médicaments essentiels sont ceux qui satisfont aux besoins de santé prioritaires de la majorité de la population.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 6,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "En Côte d'Ivoire, la LNME est révisée tous les :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. 2 ans",
                    "b. 3 ans",
                    "c. 5 ans"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. 2 ans (la Liste Nationale des Médicaments Essentiels est révisée de façon biennale, calquée sur les recommandations OMS).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 7,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "La substitution tient compte de :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. la DCI",
                    "b. la durée du traitement",
                    "c. la référence du pharmacien"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. La substitution générique repose impérativement sur la même Dénomination Commune Internationale (DCI), même forme et même dosage.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 8,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Est partie prenante de la chaine d'approvisionnement des produits de santé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Le district sanitaire",
                    "b. Le gouvernement",
                    "c. Le patient"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. Le district sanitaire (échelon opérationnel intermédiaire de stockage et distribution).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 9,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Est partie prenante de la chaine d'approvisionnement des produits de santé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. L'autorité locale",
                    "b. Le prescripteur",
                    "c. Le fournisseur"
                ),
                correctAnswers = listOf("c"),
                explanation = "Corrigé : c. Le fournisseur (acteur direct de la chaîne amont assurant la production et la livraison).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 10,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Une fonction principale de la chaine d'approvisionnement est :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. la distribution des produits jusqu'au client final",
                    "b. L'inventaire",
                    "c. Le contrôle qualité"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. La distribution des produits jusqu'au client final (bénéficiaire / patient) constitue la finalité première de la chaîne logistique.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 11,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Est un critère de sélection des produits de santé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. le coût abordable",
                    "b. crédibilité du fournisseur",
                    "c. La facilité de transport"
                ),
                correctAnswers = listOf("b"),
                explanation = "Corrigé : b. La crédibilité / qualification du fournisseur (fiabilité, conformité BPF).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 12,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Les prévisions constituent :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La 1ère étape de la quantification",
                    "b. La 2ème étape de la quantification",
                    "c. La 3ème étape de la quantification"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. La 1ère étape technique de la quantification (Forecasting / Prévisions des besoins).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 13,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "La Quantification peut être basée sur :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. les données de morbidité",
                    "b. Les pathologies saisonnières",
                    "c. Les pathologies dominantes"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. Les données de morbidité (méthode de morbidité basée sur l'incidence/prévalence et les protocoles de traitement standard).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 14,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Le système d’allocation est aussi appelé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. PULL",
                    "b. PUSH",
                    "c. PUTT"
                ),
                correctAnswers = listOf("b"),
                explanation = "Corrigé : b. PUSH (système poussé ou dotation, où le stock est calculé et expédié par l'échelon supérieur).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 15,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "Le système de réquisition est aussi appelé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. PULL",
                    "b. PUTT",
                    "c. PUSH"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. PULL (système tiré ou de réquisition, où c'est le niveau utilisateur qui commande en fonction de ses consommations).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 16,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "La centrale d'achat du système public national est :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La NPSP CI",
                    "b. La DPCI",
                    "c. UBIPHARM"
                ),
                correctAnswers = listOf("a"),
                explanation = "Corrigé : a. La Nouvelle Pharmacie de la Santé Publique de Côte d'Ivoire (NPSP CI). (UBIPHARM est un grossiste privé, DPCI est l'ancienne dénomination).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 17,
                contextText = "Consigne : Cochez la réponse exacte (+1 si bonne réponse, 0 si fausse ou absence)",
                questionText = "La chaine d'approvisionnement comprend :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. 3 niveaux de stockage",
                    "b. 5 niveaux de stockage",
                    "c. 4 niveaux de stockage"
                ),
                correctAnswers = listOf("c"),
                explanation = "Corrigé : c. 4 niveaux de stockage (Niveau central/NPSP, Niveau régional/dépôt intermédiaire, Niveau district, Niveau périphérique/formations sanitaires).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            )
        )
    }
}
