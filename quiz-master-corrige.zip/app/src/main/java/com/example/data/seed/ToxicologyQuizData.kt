package com.example.data.seed

import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.data.model.QuizEntity

object ToxicologyQuizData {

    fun createFullQuiz(): QuizEntity {
        return QuizEntity(
            id = 10L,
            title = "TD Toxicologie PGP1 (Complet)",
            description = "Travaux Dirigés Toxicologie PGP1 - 40 questions avec corrigé officiel et explications détaillées (Vrai/Faux, QCM, Cas Pratiques 1 & 2).",
            category = "Toxicologie",
            isBuiltIn = true,
            createdAt = 1710000010000L
        )
    }

    fun createVraiFauxQuiz(): QuizEntity {
        return QuizEntity(
            id = 11L,
            title = "TD Toxicologie - Vrai ou Faux",
            description = "Partie I : 10 questions Vrai ou Faux sur les bases et notions de toxicologie (+1 pt si correct, -0.5 pt si faux).",
            category = "Toxicologie",
            isBuiltIn = true,
            createdAt = 1710000011000L
        )
    }

    fun createQcmQuiz(): QuizEntity {
        return QuizEntity(
            id = 12L,
            title = "TD Toxicologie - QCM & Cas Pratiques",
            description = "Parties II, III et Cas Pratiques 1 & 2 (30 questions) : récepteurs, toxines, mécanismes d'action, solvants, mycotoxines, urgences.",
            category = "Toxicologie",
            isBuiltIn = true,
            createdAt = 1710000012000L
        )
    }

    fun getQuestionsForQuiz(quizId: Long): List<QuestionEntity> {
        return when (quizId) {
            10L -> getFullQuestions(quizId)
            11L -> getPart1VraiFaux(quizId)
            12L -> getPart2AndCases(quizId)
            else -> emptyList()
        }
    }

    private fun getFullQuestions(quizId: Long): List<QuestionEntity> {
        val p1 = getPart1VraiFaux(quizId)
        val p2 = getPart2QcmUneReponse(quizId, offset = 10)
        val p3 = getPart3QcmDeuxReponses(quizId, offset = 20)
        val p4 = getCasPratique1(quizId, offset = 30)
        val p5 = getCasPratique2(quizId, offset = 35)
        return p1 + p2 + p3 + p4 + p5
    }

    private fun getPart2AndCases(quizId: Long): List<QuestionEntity> {
        val p2 = getPart2QcmUneReponse(quizId, offset = 0)
        val p3 = getPart3QcmDeuxReponses(quizId, offset = 10)
        val p4 = getCasPratique1(quizId, offset = 20)
        val p5 = getCasPratique2(quizId, offset = 25)
        return p2 + p3 + p4 + p5
    }

    // --- I - Répondre par vrai ou faux (10 questions) ---
    fun getPart1VraiFaux(quizId: Long, offset: Int = 0): List<QuestionEntity> {
        val items = listOf(
            Triple(
                1,
                "Les xénobiotiques sont des substances étrangères introduites dans un organisme vivant.",
                "VRAI" to "Un xénobiotique est par définition une molécule chimique ou biologique étrangère à un organisme vivant (médicaments, polluants, additifs, etc.)."
            ),
            Triple(
                2,
                "Une substance est toxique lorsque, après pénétration dans l’organisme, à une dose relativement élevée, elle provoque, des troubles d’une ou de plusieurs fonctions de l’organisme pouvant aller jusqu à la mort.",
                "VRAI" to "Définition de la substance toxique : substance provoquant des altérations fonctionnelles ou lésionnelles après pénétration dans l'organisme."
            ),
            Triple(
                3,
                "Le mot poison n’est synonyme du mot toxique.",
                "FAUX" to "Le mot poison est réservé dans le langage courant aux substances utilisées avec intention de nuire (attentat criminel), mais sur le plan toxicologique, toxique et poison sont souvent employés comme synonymes avec cette nuance d'usage."
            ),
            Triple(
                4,
                "La toxicologie c’est l’étude du devenir d’un toxique dans l’organisme.",
                "FAUX" to "L'étude du devenir du toxique dans l'organisme est la toxicocinétique (absorption, distribution, métabolisme, élimination). La toxicologie au sens large étudie la nature, les effets et les mécanismes d'action des toxiques."
            ),
            Triple(
                5,
                "La DJA d’une substance est la dose minimale de cette substance que l’homme peut consommer tous les jours, jusqu’à la fin de ses jours, sans compromettre sa santé.",
                "FAUX" to "La DJA (Dose Journalière Acceptable) est la dose MAXIMALE (et non minimale) qu'un être humain peut ingérer quotidiennement sa vie durant sans risque appréciable pour la santé."
            ),
            Triple(
                6,
                "L’hygiène sociale étudie les phénomènes de toxicomanie.",
                "VRAI" to "La toxicologie sociale ou l'hygiène sociale prend en charge l'étude, la prévention et les conséquences sanitaires des toxicomanies et dépendances."
            ),
            Triple(
                7,
                "La toxicité est la capacité inhérente à une substance de produire un effet nuisible sur l’organisme vivant.",
                "VRAI" to "La toxicité est bien une propriété intrinsèque / inhérente à la substance chimique ou biologique."
            ),
            Triple(
                8,
                "La toxine est une substance synthétique élaborée par un micro-organisme.",
                "FAUX" to "Une toxine est une substance NATURELLE (non synthétique) élaborée par un être vivant (micro-organisme, champignon, plante ou venin animal)."
            ),
            Triple(
                9,
                "L’intoxication aiguë est celle liée à une exposition n’excédant pas 24 heures.",
                "VRAI" to "Par définition, l'intoxication aiguë résulte d'une exposition unique ou multiple sur une période n'excédant pas 24 heures."
            ),
            Triple(
                10,
                "Les acides gras sont des cibles moléculaires des toxiques.",
                "FAUX" to "Bien que les lipides membranaires subissent la peroxydation lipidique sous l'effet de radicaux libres, les cibles moléculaires directes canoniques (récepteurs, enzymes, ADN) sont des macromolécules spécifiques."
            )
        )

        return items.map { (index, text, answerAndExpl) ->
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + index,
                contextText = "TD Toxicologie PGP1 — Section I : Répondre par VRAI (A) ou FAUX (B)\nBarème : Bonne réponse = +1 pt, Erreur = -0,5 pt, Sans réponse = 0 pt",
                questionText = "$index- $text",
                type = QuestionType.TRUE_FALSE,
                options = listOf("VRAI", "FAUX"),
                correctAnswers = listOf(answerAndExpl.first),
                explanation = "Corrigé : ${answerAndExpl.first}. ${answerAndExpl.second}",
                positivePoints = 1.0f,
                negativePoints = 0.5f,
                maxChoices = 1
            )
        }
    }

    // --- II - QCM à une bonne réponse (10 questions) ---
    fun getPart2QcmUneReponse(quizId: Long, offset: Int = 10): List<QuestionEntity> {
        val list = mutableListOf<QuestionEntity>()

        fun addSingleChoice(
            num: Int,
            questionText: String,
            options: List<String>,
            correctKey: String,
            explanation: String
        ) {
            list.add(
                QuestionEntity(
                    quizId = quizId,
                    questionIndex = offset + num,
                    contextText = "TD Toxicologie PGP1 — Section II : QCM à une bonne réponse (1 point)",
                    questionText = "$num- $questionText",
                    type = QuestionType.SINGLE_CHOICE,
                    options = options,
                    correctAnswers = listOf(correctKey),
                    explanation = explanation,
                    positivePoints = 1.0f,
                    negativePoints = 0.0f,
                    maxChoices = 1
                )
            )
        }

        addSingleChoice(
            num = 1,
            questionText = "Un récepteur est une structure :",
            options = listOf(
                "A) essentiellement protéique",
                "B) glycémique"
            ),
            correctKey = "a",
            explanation = "Les récepteurs biologiques sont des macromolécules cellulaires de nature essentiellement protéique."
        )

        addSingleChoice(
            num = 2,
            questionText = "La détoxification consiste :",
            options = listOf(
                "A) à détruire le toxique présent dans les aliments ou dans l’environnement avant l’exposition de l’homme",
                "B) à détruire le toxique ingéré par l’homme"
            ),
            correctKey = "a",
            explanation = "La détoxification est le procédé d'élimination ou de destruction du toxique in vitro / dans la matrice alimentaire ou environnementale avant ingestion (à distinguer de la détoxication biologique métabolique in vivo)."
        )

        addSingleChoice(
            num = 3,
            questionText = "Ce toxique est une toxine, lequel :",
            options = listOf(
                "A) Le monoxyde de carbone (CO)",
                "B) L’aflatoxine"
            ),
            correctKey = "b",
            explanation = "L'aflatoxine est une mycotoxine naturelle élaborée par Aspergillus flavus. Le CO est un composé chimique inorganique gazeux."
        )

        addSingleChoice(
            num = 4,
            questionText = "La porte d’entrée d’un toxique dans l’organisme est appelée :",
            options = listOf(
                "A) type d’exposition ou voie d’absorption",
                "B) Voie de distribution"
            ),
            correctKey = "a",
            explanation = "La porte d'entrée correspond à la voie d'absorption ou voie d'exposition (orale, respiratoire, cutanéo-muqueuse)."
        )

        addSingleChoice(
            num = 5,
            questionText = "Dans le domaine industriel et agricole, la toxicovigilance s’applique :",
            options = listOf(
                "A) à la quantité de production",
                "B) aux produits chimiques"
            ),
            correctKey = "b",
            explanation = "La toxicovigilance surveille les effets toxiques et indésirables liés à l'exposition aux produits chimiques (pesticides, solvants, etc.)."
        )

        addSingleChoice(
            num = 6,
            questionText = "Les intoxications d’origine microbienne sont aussi appelées :",
            options = listOf(
                "A) mycotoxines",
                "B) toxi-infections"
            ),
            correctKey = "b",
            explanation = "Les intoxications causées par des bactéries ou micro-organismes (ou leurs toxines) sont appelées toxi-infections alimentaires."
        )

        addSingleChoice(
            num = 7,
            questionText = "Les additifs alimentaires sont utilisés pour :",
            options = listOf(
                "A) assurer la conservation du produit fini",
                "B) maintenir l’aliment chaud"
            ),
            correctKey = "a",
            explanation = "Les additifs servent à la conservation, la stabilisation, la texture ou la présentation des denrées alimentaires."
        )

        addSingleChoice(
            num = 8,
            questionText = "Ces poisons font partie de la liste des poisons employés à des fins criminelles :",
            options = listOf(
                "A) les dérivés de l’arsenic",
                "B) eaux de javel"
            ),
            correctKey = "a",
            explanation = "Historiquement, l'arsenic et ses dérivés ont été célèbres pour leur utilisation comme poisons d'homicide sans goût ni odeur."
        )

        addSingleChoice(
            num = 9,
            questionText = "Pour lutter contre toutes les intoxications, des organismes d’urgence sont mis en place en France et partout dans le monde. Ce sont :",
            options = listOf(
                "A) les centres antipoisons",
                "B) les centres antipollution"
            ),
            correctKey = "a",
            explanation = "Ce sont les Centres Antipoison et de Toxicovigilance (CAPTV) qui assurent une réponse médicale d'urgence 24h/24."
        )

        addSingleChoice(
            num = 10,
            questionText = "Les effets sont dits réversibles lorsqu’ils :",
            options = listOf(
                "A) s’intensifient après arrêt de l’exposition",
                "B) disparaissent après cessation de l’exposition à la substance toxique"
            ),
            correctKey = "b",
            explanation = "Un effet toxique réversible régresse et s'annule lorsque le contact avec le toxique est interrompu et que celui-ci est éliminé."
        )

        return list
    }

    // --- III - QCM à deux réponses correctes (10 questions) ---
    fun getPart3QcmDeuxReponses(quizId: Long, offset: Int = 20): List<QuestionEntity> {
        val list = mutableListOf<QuestionEntity>()

        fun addDoubleChoice(
            num: Int,
            questionText: String,
            options: List<String>,
            correctKeys: List<String>,
            explanation: String
        ) {
            list.add(
                QuestionEntity(
                    quizId = quizId,
                    questionIndex = offset + num,
                    contextText = "TD Toxicologie PGP1 — Section III : QCM à deux réponses correctes\nBarème : 2 bonnes = +1 pt, 1 bonne sans erreur = +0.5 pt, erreur = 0 pt",
                    questionText = "$num- $questionText",
                    type = QuestionType.MULTIPLE_CHOICE,
                    options = options,
                    correctAnswers = correctKeys,
                    explanation = explanation,
                    positivePoints = 1.0f,
                    negativePoints = 0.0f,
                    maxChoices = 2
                )
            )
        }

        addDoubleChoice(
            num = 1,
            questionText = "Selon les définitions historiques et les principes de Paracelse :",
            options = listOf(
                "A) Le mot toxicologie provient de termes grecs signifiant « l'étude des flèches ».",
                "B) C'est la dose qui fait le poison, aucune substance n'est toxique en elle-même.",
                "C) Le terme poison est réservé dans l'usage général à l'attentat criminel.",
                "D) La toxicocinétique est l'étude du devenir d'un médicament dans l'organisme."
            ),
            correctKeys = listOf("b", "c"),
            explanation = "Corrigé : B et C. Paracelse : « Tout est poison, rien n'est sans poison ; seule la dose fait qu'une chose n'est pas un poison ». Dans l'usage général, le poison renvoie à l'acte criminel."
        )

        addDoubleChoice(
            num = 2,
            questionText = "Concernant l'Érythropoïétine (EPO) mentionnée comme cas particulier :",
            options = listOf(
                "A) C'est une glycoprotéine sécrétée principalement par le foie.",
                "B) Sa sécrétion est accrue dans l'organisme par l'hypoxie.",
                "C) Sa sécrétion est stimulée par un excès d'oxygène dans les tissus.",
                "D) Elle est considérée comme un xénobiotique lorsqu'elle est d'origine exogène (administrée par un sportif)."
            ),
            correctKeys = listOf("b", "d"),
            explanation = "Corrigé : B et D. L'hypoxie stimule la production d'EPO (sécrétée à 90% par le rein). Lorsqu'elle est administrée de l'extérieur en dopage, elle se comporte comme un xénobiotique."
        )

        addDoubleChoice(
            num = 3,
            questionText = "Dans le domaine de la toxicologie professionnelle :",
            options = listOf(
                "A) Le trichloréthylène est un solvant organique très utilisé dans l'industrie textile.",
                "B) L'exposition non protégée au trichloréthylène peut causer une baisse de la libido et des anomalies cardiaques.",
                "C) Le médecin du travail doit passer au moins la moitié de son temps dans les ateliers.",
                "D) Le bilan biologique d'embauche se fait uniquement après le premier arrêt-maladie de l'ouvrier."
            ),
            correctKeys = listOf("a", "b"),
            explanation = "Corrigé : A et B. Le trichloréthylène est un solvant dégraissant largement employé (textile, mécanique). Son inhalation cause des troubles du SNC, asthénie, baisse de la libido et arythmies cardiaques."
        )

        addDoubleChoice(
            num = 4,
            questionText = "À propos de la Dose Journalière Acceptable (DJA) :",
            options = listOf(
                "A) Elle représente la dose maximale qu'un être humain peut consommer chaque jour toute sa vie sans compromettre sa santé.",
                "B) Le toxicologue et le législateur n'ont aucun pouvoir sur sa détermination.",
                "C) Elle s'applique principalement aux polluants ou aux additifs alimentaires.",
                "D) Elle est calculée en multipliant la dose sans effet (DSE) de l'animal par un facteur de 100."
            ),
            correctKeys = listOf("a", "c"),
            explanation = "Corrigé : A et C. La DJA est la dose maximale admissible quotidienne à vie sans effet toxique observable. Elle s'applique aux additifs et résidus. (Pour rappel, elle s'obtient en divisant la DSE par le facteur de sécurité 100)."
        )

        addDoubleChoice(
            num = 5,
            questionText = "Au sujet des mycotoxines et de la détoxification :",
            options = listOf(
                "A) L'aflatoxine B1 est un puissant cancérogène hépatique de catégorie 1.",
                "B) L'ochratoxine A (OTA) est une toxine élaborée par des bactéries présentes dans le cacao.",
                "C) L'adsorption sur de l'argile ou du charbon activé est une méthode chimique de détoxification.",
                "D) Le traitement à l'ozone (O3) fait partie des méthodes physiques de détoxification."
            ),
            correctKeys = listOf("a", "d"),
            explanation = "Corrigé : A et D. L'aflatoxine B1 est classée cancérogène avéré pour l'homme (Groupe 1 CIRC, carcinome hépatocellulaire). Le traitement par agents oxydants/ozone est compté dans les méthodes de détoxification physique/chimique des denrées."
        )

        addDoubleChoice(
            num = 6,
            questionText = "Si un patient est victime d'une ingestion malheureuse de produit toxique :",
            options = listOf(
                "A) Il faut obligatoirement lui faire boire de l'huile de palme pour neutraliser le toxique.",
                "B) Si l'ingestion date de moins d'une heure, on peut tenter de faire vomir la victime.",
                "C) Entre 1 heure et 2 heures après l'ingestion, il est recommandé d'administrer un pansement gastrique (charbon activé).",
                "D) Le lait est un excellent antidote universel car il détruit tous les toxiques liposolubles."
            ),
            correctKeys = listOf("b", "c"),
            explanation = "Corrigé : B et C. Dans les délais très précoces (<1h sans contre-indication de produit caustique ni moussant) et l'administration de charbon activé (adsorbant universel) entre 1 et 2h. Le lait et l'huile sont formellement proscrits."
        )

        addDoubleChoice(
            num = 7,
            questionText = "Concernant la classification des intoxications selon la durée d'exposition :",
            options = listOf(
                "A) Une intoxication aiguë est liée à une exposition n'excédant pas 24 heures.",
                "B) Une intoxication subaiguë résulte d'une exposition qui s'étend de 14 à 90 jours.",
                "C) L'intoxication chronique découle d'une exposition allant de 2 à 3 jours au maximum.",
                "D) L'intoxication suraiguë s'étend obligatoirement sur une période de 3 mois à plusieurs années."
            ),
            correctKeys = listOf("a", "b"),
            explanation = "Corrigé : A et B. Intoxication aiguë : durée < 24 h. Intoxication subaiguë : exposition répétée sur 14 à 90 jours (subchronique). L'intoxication chronique dépasse généralement 3 mois à des années."
        )

        addDoubleChoice(
            num = 8,
            questionText = "Sur les mécanismes d'action moléculaires des toxiques :",
            options = listOf(
                "A) Le monoxyde de carbone (CO) se lie à l'hémoglobine pour former de la carboxyhémoglobine, bloquant le transport de l'oxygène.",
                "B) Les cyanures agissent en provoquant la peroxydation des acides gras de la membrane cellulaire.",
                "C) Les agents alkylants se fixent par liaison covalente sur les acides nucléiques (ADN ou ARN).",
                "D) Les radicaux libres détruisent les récepteurs stéréospécifiques de l'insuline."
            ),
            correctKeys = listOf("a", "c"),
            explanation = "Corrigé : A et C. Le CO forme la carboxyhémoglobine avec une affinité 200 à 250 fois supérieure à celle de l'oxygène. Les alkylants créent des liaisons covalentes directes sur l'ADN bloquant sa réplication."
        )

        addDoubleChoice(
            num = 9,
            questionText = "Concernant les essais de toxicité aiguë (DL50) chez l'animal :",
            options = listOf(
                "A) La DL50 correspond à la dose unique supposée tuer 100 % des animaux d'un lot.",
                "B) Après administration du produit, les animaux sont observés pendant une période de 14 jours.",
                "C) Si la DL50 par voie orale est inférieure ou égale à 5 mg/kg, le produit est considéré comme extrêmement toxique.",
                "D) Les essais de toxicité aiguë se font obligatoirement par des méthodes alternatives (cultures de tissus) pour éviter l'usage d'animaux."
            ),
            correctKeys = listOf("b", "c"),
            explanation = "Corrigé : B et C. La période d'observation standard après dose unique est de 14 jours. Une DL50 orale ≤ 5 mg/kg caractérise une substance de toxicité extrême (classe 1 de Hodge et Sterner)."
        )

        addDoubleChoice(
            num = 10,
            questionText = "Selon la classification du CIRC sur le pouvoir cancérogène :",
            options = listOf(
                "A) L'arsenic, le benzène et la fumée de tabac sont classés dans le Groupe 1 (cancérogènes pour l'homme).",
                "B) Le formaldéhyde et le cadmium appartiennent au Groupe 2A (probablement cancérogènes pour l'homme).",
                "C) Le Groupe 4 réunit les agents qui n'ont pas encore pu être classés par les experts.",
                "D) Le Groupe 1 correspond aux agents dont le caractère cancérogène est probablement faux pour l'homme."
            ),
            correctKeys = listOf("a", "b"),
            explanation = "Corrigé : A et B. Groupe 1 = Cancérogène certain pour l'homme (arsenic, benzène, tabac). Groupe 2A = Probablement cancérogène pour l'homme selon l'énoncé du cours."
        )

        return list
    }

    // --- Cas Pratique 1 : Alerte sanitaire dans une usine agroalimentaire (5 questions) ---
    fun getCasPratique1(quizId: Long, offset: Int = 30): List<QuestionEntity> {
        val list = mutableListOf<QuestionEntity>()
        val context = "Cas Pratique 1 : Alerte sanitaire dans une usine agroalimentaire\n" +
                "Contexte :\n" +
                "La clinique du travail d'une unité agro-industrielle spécialisée dans la fabrication de jus de fruits exotiques et le conditionnement d'arachides fait face à plusieurs signalements :\n" +
                "1. Atelier Conditionnement : Plusieurs ouvriers se plaignent de maux de tête, de baisse de la libido et de fatigue anormale. Un audit révèle que l'encre des emballages et la colle des cartons contiennent des solvants organiques volatils, notamment du trichloréthylène. Les ouvriers omettent souvent de porter leurs masques et ont l'habitude de prendre leur pause déjeuner directement sur leur plan de travail.\n" +
                "2. Atelier Matières Premières : Le laboratoire interne de contrôle de qualité a détecté un taux anormalement élevé d'aflatoxine B1 dans un lot d'arachides suite à une mauvaise gestion de l'humidité pendant le stockage."

        fun addCaseQuestion(
            num: Int,
            questionText: String,
            options: List<String>,
            correctKey: String,
            explanation: String
        ) {
            list.add(
                QuestionEntity(
                    quizId = quizId,
                    questionIndex = offset + num,
                    contextText = context,
                    questionText = "$num. $questionText",
                    type = QuestionType.SINGLE_CHOICE,
                    options = options,
                    correctAnswers = listOf(correctKey),
                    explanation = explanation,
                    positivePoints = 1.0f,
                    negativePoints = 0.0f,
                    maxChoices = 1
                )
            )
        }

        addCaseQuestion(
            num = 1,
            questionText = "Qu'appelle-t-on exactement « dose-seuil » d'une substance toxique ?",
            options = listOf(
                "A) La quantité de substance éliminée par l'organisme au cours d'une période n'excédant pas 24 heures.",
                "B) La dose minimale toxique que l'homme peut consommer tous les jours sans compromettre sa santé."
            ),
            correctKey = "b",
            explanation = "Selon le document : B) La dose minimale toxique que l'homme peut consommer tous les jours sans compromettre sa santé."
        )

        addCaseQuestion(
            num = 2,
            questionText = "Parmi les propositions suivantes, quel trouble ou modification observe-t-on lors d'une exposition non protégée au trichloréthylène ?",
            options = listOf(
                "A) Une plus grande sensibilité aux boissons alcoolisées ainsi que des manifestations hématologiques et des anomalies d'ECG.",
                "B) Une élévation immédiate et permanente de la tension artérielle par antagonisme fonctionnel."
            ),
            correctKey = "a",
            explanation = "L'exposition au trichloréthylène entraîne une intolérance à l'alcool (« flush » du trichloréthylène), des troubles hématologiques et des anomalies électrocardiographiques."
        )

        addCaseQuestion(
            num = 3,
            questionText = "Comment l'aflatoxine B1 est-elle classée en matière de toxicité à long terme selon les données du cours ?",
            options = listOf(
                "C) Classé comme cancérogène catégorie 1.",
                "D) Agent probablement non cancérogène pour l'homme (Groupe 4 du CIRC)."
            ),
            correctKey = "c",
            explanation = "L'aflatoxine B1 est classée cancérogène avéré de catégorie 1 par le CIRC."
        )

        addCaseQuestion(
            num = 4,
            questionText = "Quelle est la définition exacte de la Dose Journalière Acceptable (DJA) d'une substance ?",
            options = listOf(
                "A) La quantité de toxique résiduelle maximale tolérée dans les emballages en plomb des boîtes de conserve.",
                "D) La dose maximale de cette substance que l'homme peut consommer tous les jours, jusqu'à la fin de ses jours, sans compromettre sa santé."
            ),
            correctKey = "d",
            explanation = "Définition officielle : La dose maximale d'une substance que l'être humain peut ingérer chaque jour toute sa vie sans danger pour la santé."
        )

        addCaseQuestion(
            num = 5,
            questionText = "Quelles sont les principales voies d'absorption ou portes d'entrée d'un xénobiotique dans l'organisme ?",
            options = listOf(
                "A) La bouche (ingestion), les voies aériennes supérieures (inhalation), la peau et les muqueuses",
                "B) Uniquement la voie intraveineuse et le passage transplacentaire fœtal."
            ),
            correctKey = "a",
            explanation = "Les 3 voies majeures d'exposition naturelle et professionnelle sont l'ingestion digestive, l'inhalation pulmonaire et la pénétration percutanée/muqueuse."
        )

        return list
    }

    // --- Cas pratique 2 : "Urgences toxicologiques à l'hôpital" (5 questions) ---
    fun getCasPratique2(quizId: Long, offset: Int = 35): List<QuestionEntity> {
        val list = mutableListOf<QuestionEntity>()
        val context = "Cas pratique 2 : « Urgences toxicologiques à l'hôpital »\n" +
                "En tant que futur préparateur et gestionnaire en pharmacie stagiaire au bloc des urgences, vous assistez l'équipe médicale lors de l'admission de plusieurs patients présentant des tableaux d'intoxication sévères :\n" +
                "1. Patient A : Un technicien de maintenance retrouvé inconscient dans une chaufferie mal ventilée. Les analyses sanguines révèlent une formation massive de carboxyhémoglobine (CarHb).\n" +
                "2. Patient B : Un agriculteur admis pour des troubles neuromusculaires sévères après avoir manipulé des insecticides organophosphorés sans équipement de protection individuelle.\n" +
                "3. Patient C : Une jeune femme admise pour une ingestion massive de cyanure dans un but d'autolyse. Le médecin mentionne un blocage cellulaire par formation de chélates au niveau des coenzymes."

        fun addHospitalQuestion(
            num: Int,
            subTitle: String,
            questionText: String,
            options: List<String>,
            correctKey: String,
            explanation: String
        ) {
            list.add(
                QuestionEntity(
                    quizId = quizId,
                    questionIndex = offset + num,
                    contextText = "$context\n\nQuestion $num : $subTitle",
                    questionText = "$num- ($subTitle)\n$questionText",
                    type = QuestionType.SINGLE_CHOICE,
                    options = options,
                    correctAnswers = listOf(correctKey),
                    explanation = explanation,
                    positivePoints = 1.0f,
                    negativePoints = 0.0f,
                    maxChoices = 1
                )
            )
        }

        addHospitalQuestion(
            num = 1,
            subTitle = "Cibles protéiques et transporteurs",
            questionText = "Concernant l'intoxication du Patient A (monoxyde de carbone), quel est le mécanisme moléculaire exact décrit dans le cours ?",
            options = listOf(
                "A) Le monoxyde de carbone détruit directement l'acide désoxyribonucléique (ADN) par alkylation covalente.",
                "B) Le monoxyde de carbone a une grande affinité pour l'hémoglobine, se fixant préférentiellement sur ce transporteur pour donner la carboxyhémoglobine et provoquer un déficit en oxygène des tissus."
            ),
            correctKey = "b",
            explanation = "Le CO possède une affinité pour l'hémoglobine 200 à 250 fois supérieure à celle de l'O2, formant la carboxyhémoglobine (HbCO) et entraînant une anoxie tissulaire aiguë."
        )

        addHospitalQuestion(
            num = 2,
            subTitle = "Inhibition enzymatique",
            questionText = "Le Patient B présente une intoxication par les insecticides organophosphorés. Quel type d'effet biochimique et de mécanisme d'action subit-il ?",
            options = listOf(
                "C) Un effet morphologique irréversible visible uniquement en microscopie électronique.",
                "D) Un effet biochimique consistant en l'inhibition des systèmes enzymatiques, plus précisément l'inhibition des cholinestérases."
            ),
            correctKey = "d",
            explanation = "Les organophosphorés phosphorylent de manière irréversible le site estérasique de l'acétylcholinestérase, provoquant une accumulation d'acétylcholine (syndrome cholinergique muscarinique et nicotinique)."
        )

        addHospitalQuestion(
            num = 3,
            subTitle = "Cibles coenzymatiques",
            questionText = "Concernant l'intoxication au cyanure du Patient C, comment le cours explique-t-il l'atteinte au niveau des coenzymes ?",
            options = listOf(
                "A) Les cyanures provoquent la formation de chélates (complexes) avec des métaux tels que le cuivre ou le zinc contenus dans des coenzymes indispensables au bon fonctionnement des enzymes.",
                "B) Les cyanures s'incorporent directement à l'ARN en se comportant comme des antimétabolites.."
            ),
            correctKey = "a",
            explanation = "Les cyanures (ions CN-) bloquent la chaîne respiratoire mitochondriale en formant des complexes stables avec le fer ferrique (Fe3+) et métaux des cytochromes et coenzymes."
        )

        addHospitalQuestion(
            num = 4,
            subTitle = "Atteinte des lipides et radicaux libres",
            questionText = "Le cours mentionne le tétrachlorure de carbone pour illustrer l'atteinte des lipides. Quel phénomène biochimique est mis en jeu par ce type de toxique ?",
            options = listOf(
                "A) Une liaison covalente stéréospecifique sur un récepteur hormonal à l'insuline.",
                "B) La peroxydation des acides gras poly-insaturés sous l'effet de l'apparition de radicaux libres, pouvant participer à la nécrose."
            ),
            correctKey = "b",
            explanation = "Le CCl4 est bioactivé par les cytochromes P450 en radical trichlorométhyle (CCl3•), déclenchant une lipoperoxydation en chaîne des membranes hépatocytaires et la nécrose centrolobulaire."
        )

        addHospitalQuestion(
            num = 5,
            subTitle = "Atteinte des acides nucléiques et apoptose",
            questionText = "Quelle est l'affirmation exacte concernant l'action des toxiques sur les acides nucléiques et le mécanisme d'apoptose selon votre cours ?",
            options = listOf(
                "B) Le méthotrexate est un agent alkylant qui bloque l'action des récepteurs des benzodiazépines.",
                "C) L'apoptose est un mécanisme de mort programmée des cellules qui élimine les cellules présentant des anomalies ; la perte de cette faculté favorise la prolifération des cellules cancéreuses."
            ),
            correctKey = "c",
            explanation = "L'apoptose élimine les cellules dont l'ADN présente des mutations irréparables. L'échappement à l'apoptose induit par certains toxiques favorise la cancérogenèse."
        )

        return list
    }
}
