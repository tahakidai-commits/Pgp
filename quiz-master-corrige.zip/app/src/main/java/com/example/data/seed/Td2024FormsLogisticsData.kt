package com.example.data.seed

import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.data.model.QuizEntity

object Td2024FormsLogisticsData {

    fun createQuiz(): QuizEntity {
        return QuizEntity(
            id = 40L,
            title = "TD 2024 - Gestion des Produits de Santé PGP1",
            description = "Corrigé officiel du TD 2024 (42 questions dans l'ordre exact du formulaire Microsoft Forms) selon C-LOGISTIQUES.pdf. Barème : A = Vrai (+1 pt), B = Faux (+1 pt).",
            category = "Gestion Logistique",
            isBuiltIn = true,
            createdAt = 1710000040000L
        )
    }

    fun getQuestions(quizId: Long): List<QuestionEntity> {
        return listOf(
            // 1
            QuestionEntity(
                quizId = quizId,
                questionIndex = 1,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "1. Une fonction principale de la chaîne d'approvisionnement est :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La distribution des produits jusqu'au client final",
                    "b. L'inventaire",
                    "c. Le contrôle qualité"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) La distribution des produits jusqu'au client final - C-LOGISTIQUES.pdf p.32 cours.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 2
            QuestionEntity(
                quizId = quizId,
                questionIndex = 2,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "2. Toute substitution dans la délivrance de médicaments est décidée par le pharmacien.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX. La substitution est strictement encadrée par la réglementation et ne relève pas d'une décision unilatérale ou arbitraire du pharmacien.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 3
            QuestionEntity(
                quizId = quizId,
                questionIndex = 3,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "3. La disponibilité est un critère de sélection des produits de santé.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - C-LOGISTIQUES.pdf p.28. La disponibilité sur le marché fait partie des critères de sélection.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 4
            QuestionEntity(
                quizId = quizId,
                questionIndex = 4,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "4. Le système d'allocation est aussi appelé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. PULL",
                    "b. PUSH",
                    "c. PUTT"
                ),
                correctAnswers = listOf("b"),
                explanation = "b) PUSH - C-LOGISTIQUES.pdf p.32 : Dans le système d'allocation (PUSH), le niveau supérieur détermine les quantités allouées.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 6 (skip 5 matricule)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 5,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "6. La quantification peut être basée sur :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Les données de morbidité",
                    "b. Les pathologies saisonnières",
                    "c. Les pathologies dominantes"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) Les données de morbidité - C'est la méthode épidémiologique (C-LOGISTIQUES.pdf p.33).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 7
            QuestionEntity(
                quizId = quizId,
                questionIndex = 6,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "7. Les médicaments essentiels sont sélectionnés en fonction de la préférence des patients.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX (C-LOGISTIQUES.pdf p.28 : sélectionnés selon la prévalence des pathologies, l'efficacité, la sécurité et le coût).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 8
            QuestionEntity(
                quizId = quizId,
                questionIndex = 7,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "8. Font partie des médicaments :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Les produits utilisés pour la prothèse dentaire",
                    "b. Les plaquettes sanguines",
                    "c. Les produits stériles à usage médical"
                ),
                correctAnswers = listOf("c"),
                explanation = "c) Les produits stériles à usage médical (a = Dispositif Médical, b = PSL produit sanguin labile géré par le CNTS).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 9
            QuestionEntity(
                quizId = quizId,
                questionIndex = 8,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "9. Les équipements de laboratoires sont des dispositifs médicaux.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - C-LOGISTIQUES.pdf p.16 (Dispositifs Médicaux durables et DMDIV).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 11 (skip 10 nom)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 9,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "11. La contrefaçon d'un médicament porte uniquement sur le mauvais dosage des principes actifs.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX - C-LOGISTIQUES.pdf p.14 : la contrefaçon inclut aussi l'absence de PA, un emballage trompeur, un faux étiquetage ou une imitation.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 12
            QuestionEntity(
                quizId = quizId,
                questionIndex = 10,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "12. Les spécialités pharmaceutiques peuvent être des médicaments essentiels.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI. Les médicaments essentiels inscrits sous DCI peuvent être commercialisés et dispensés sous forme de spécialités pharmaceutiques.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 13
            QuestionEntity(
                quizId = quizId,
                questionIndex = 11,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "13. La facilité d'emploi est un critère de sélection des médicaments essentiels.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - C-LOGISTIQUES.pdf p.28 : critère important pour favoriser l'observance thérapeutique.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 14
            QuestionEntity(
                quizId = quizId,
                questionIndex = 12,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "14. En système d'allocation, c'est le niveau supérieur qui détermine les quantités de produits reçus par le niveau inférieur.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - Définition du système PUSH (C-LOGISTIQUES.pdf p.32).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 15
            QuestionEntity(
                quizId = quizId,
                questionIndex = 13,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "15. Font partie des médicaments :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Les produits réduisant l'accoutumance au tabac",
                    "b. Les objets de pansement",
                    "c. Les articles de désinfection"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) Les produits réduisant l'accoutumance au tabac (sevrage tabagique = médicaments par présentation ; pansements = DM consommables, désinfection = entretien).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 16
            QuestionEntity(
                quizId = quizId,
                questionIndex = 14,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "16. La quantification comprend 4 étapes.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - C-LOGISTIQUES.pdf p.30, Figure 1 (1. Préparation, 2. Prévisions, 3. Planification, 4. Révision).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 17
            QuestionEntity(
                quizId = quizId,
                questionIndex = 15,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "17. La centrale d'achat du système public national est :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La NPSPCI",
                    "b. La DPCI",
                    "c. UBIPHARM"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) La NPSP-CI - C-LOGISTIQUES.pdf p.27 (Nouvelle Pharmacie de la Santé Publique de Côte d'Ivoire).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 18
            QuestionEntity(
                quizId = quizId,
                questionIndex = 16,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "18. Les médicaments essentiels :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Sont les plus courants",
                    "b. Satisfont aux besoins de la majorité de la population",
                    "c. Sont indispensables au traitement de toute pathologie"
                ),
                correctAnswers = listOf("b"),
                explanation = "b) Satisfont aux besoins de la majorité de la population - Définition de l'OMS (C-LOGISTIQUES.pdf p.28).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 19
            QuestionEntity(
                quizId = quizId,
                questionIndex = 17,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "19. L'adjudication est un mode d'acquisition de produits entre le fournisseur et la centrale d'achat.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI. L'adjudication (appel d'offres) est la modalité principale d'acquisition des marchés publics.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 20
            QuestionEntity(
                quizId = quizId,
                questionIndex = 18,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "20. Les médicaments essentiels sont sélectionnés en fonction de la prévalence des maladies.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - C-LOGISTIQUES.pdf p.28.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 21
            QuestionEntity(
                quizId = quizId,
                questionIndex = 19,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "21. Est un critère de sélection des produits de santé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Le coût abordable",
                    "b. La crédibilité du fournisseur",
                    "c. La facilité de transport"
                ),
                correctAnswers = listOf("b"),
                explanation = "b) La crédibilité du fournisseur - Critère primordial cité p.28. Le coût abordable est aussi un critère. La facilité de transport est fausse.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 22
            QuestionEntity(
                quizId = quizId,
                questionIndex = 20,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "22. Les ONG sont partie prenante de la chaîne d'approvisionnement.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - C-LOGISTIQUES.pdf p.29 (partenaires techniques et d'appui).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 23
            QuestionEntity(
                quizId = quizId,
                questionIndex = 21,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "23. Les produits de santé comprennent :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Kits et DM",
                    "b. Kits, DM et médicaments",
                    "c. Médicaments, DM et équipements médicaux"
                ),
                correctAnswers = listOf("b"),
                explanation = "b) Kits, DM et médicaments (C-LOGISTIQUES.pdf p.1).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 24
            QuestionEntity(
                quizId = quizId,
                questionIndex = 22,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "24. Est partie prenante de la chaîne d'approvisionnement des produits de santé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. L'autorité locale",
                    "b. Le prescripteur",
                    "c. Le fournisseur"
                ),
                correctAnswers = listOf("c"),
                explanation = "c) Le fournisseur - Acteur direct amont de la chaîne logistique (p.29). L'autorité locale n'est pas partie prenante directe, le prescripteur est utilisateur final.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 25
            QuestionEntity(
                quizId = quizId,
                questionIndex = 23,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "25. La pharmacie peut procéder à la destruction des PPI.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX - C-LOGISTIQUES.pdf p.17 : la destruction sécurisée des PPI implique une commission agréée avec procès-verbal, la pharmacie ne procède pas seule.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 26
            QuestionEntity(
                quizId = quizId,
                questionIndex = 24,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "26. La chaîne d'approvisionnement prend en compte les installations de stockage et les moyens de transport.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI. Les entrepôts, magasins et moyens de transport constituent les infrastructures logistiques de base.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 27
            QuestionEntity(
                quizId = quizId,
                questionIndex = 25,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "27. La chaîne d'approvisionnement ne gère que des flux physiques.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX - C-LOGISTIQUES.pdf p.13 : elle intègre 3 flux majeurs : physique, informationnel et financier.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 28
            QuestionEntity(
                quizId = quizId,
                questionIndex = 26,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "28. La substitution tient compte de :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La DCI",
                    "b. La durée du traitement",
                    "c. La préférence du pharmacien"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) La DCI (Dénomination Commune Internationale, avec forme galénique et dosage identiques).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 30 (skip 29 prénoms)
            QuestionEntity(
                quizId = quizId,
                questionIndex = 27,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "30. Seuls les apports nationaux financent les acquisitions des produits de santé.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX - C-LOGISTIQUES.pdf p.32 : apports nationaux combinés aux apports externes (bailleurs, partenaires internationaux).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 31
            QuestionEntity(
                quizId = quizId,
                questionIndex = 28,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "31. La chaîne d'approvisionnement comprend :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. 3 niveaux de stockage",
                    "b. 5 niveaux de stockage",
                    "c. 4 niveaux de stockage"
                ),
                correctAnswers = listOf("c"),
                explanation = "c) 4 niveaux de stockage : Central (NPSP), Régional (Bouaké & antennes), District sanitaire, et ESPC (formations sanitaires).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 32
            QuestionEntity(
                quizId = quizId,
                questionIndex = 29,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "32. Les médicaments génériques sont toujours des médicaments essentiels.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX. De nombreux médicaments génériques commercialisés ne répondent pas aux critères de sélection de la LNME.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 33
            QuestionEntity(
                quizId = quizId,
                questionIndex = 30,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "33. Les produits de santé participent uniquement au bien-être physique.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX. La définition de l'OMS de la santé couvre le bien-être physique, mental et social.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 34
            QuestionEntity(
                quizId = quizId,
                questionIndex = 31,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "34. En Côte d'Ivoire, la LNME est révisée tous les :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. 2 ans",
                    "b. 3 ans",
                    "c. 5 ans"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) 2 ans (révision biennale calquée sur les recommandations de l'OMS).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 35
            QuestionEntity(
                quizId = quizId,
                questionIndex = 32,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "35. CMM signifie :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Consommation moyenne mensuelle",
                    "b. Consommation mensuelle moyenne",
                    "c. Consommation de Médicaments du Mois"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) Consommation Moyenne Mensuelle - C-LOGISTIQUES.pdf p.30 (indicateur clé du calcul des besoins et réapprovisionnements).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 36
            QuestionEntity(
                quizId = quizId,
                questionIndex = 33,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "36. Les médicaments ne possèdent que des propriétés curatives.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX. Les médicaments ont également des propriétés préventives, symptomatiques et diagnostiques.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 37
            QuestionEntity(
                quizId = quizId,
                questionIndex = 34,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "37. Les prévisions constituent :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. La 1ère étape de la quantification",
                    "b. La 2ème étape de la quantification",
                    "c. La 3ème étape de la quantification"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) La 1ère étape de la quantification (Forecasting / Prévisions).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 38
            QuestionEntity(
                quizId = quizId,
                questionIndex = 35,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "38. Le médicament peut être symptomatique.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - C-LOGISTIQUES.pdf p.13 (ex : antalgiques).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 39
            QuestionEntity(
                quizId = quizId,
                questionIndex = 36,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "39. Tout produit de diagnostic médical est un médicament.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX - C-LOGISTIQUES.pdf p.16 : la majorité des produits de diagnostic sont des DMDIV (Dispositifs Médicaux de Diagnostic In Vitro).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 40
            QuestionEntity(
                quizId = quizId,
                questionIndex = 37,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "40. Le gré à gré est un mode d'acquisition de produits entre la centrale d'achat et les structures sanitaires.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX. Le gré à gré est une passation de marché fournisseur/centrale. Entre centrale et structures sanitaires, c'est de la distribution (PUSH ou PULL).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 41
            QuestionEntity(
                quizId = quizId,
                questionIndex = 38,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "41. Seules les maladies humaines sont prises en charge par les médicaments.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX. Les médicaments vétérinaires traitent les maladies animales.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 42
            QuestionEntity(
                quizId = quizId,
                questionIndex = 39,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "42. Est partie prenante de la chaîne d'approvisionnement des produits de santé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. Le district sanitaire",
                    "b. Le gouvernement",
                    "c. Le patient"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) Le district sanitaire - Niveau opérationnel logistique clé (le gouvernement et le patient figurent également sur le schéma global p.29).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 43
            QuestionEntity(
                quizId = quizId,
                questionIndex = 40,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "43. Les produits SRMNIN sont uniquement destinés aux enfants.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "B - FAUX. SRMNIN = Santé Reproductive, Maternelle, Nouveau-né, Enfant, Adolescent et Nutrition (femmes et mères également ciblées).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 44
            QuestionEntity(
                quizId = quizId,
                questionIndex = 41,
                contextText = "TD 2024 (Microsoft Forms) • C-LOGISTIQUES.pdf",
                questionText = "44. Le système de réquisition est aussi appelé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a. PULL",
                    "b. PUTT",
                    "c. PUSH"
                ),
                correctAnswers = listOf("a"),
                explanation = "a) PULL - Système tiré (réquisition) où le niveau demandeur détermine ses commandes.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            // 45
            QuestionEntity(
                quizId = quizId,
                questionIndex = 42,
                contextText = "TD 2024 (Microsoft Forms) • Consigne : A = VRAI / B = FAUX",
                questionText = "45. La quantification peut être basée sur les données épidémiologiques de la sous-région.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "A - VRAI - C-LOGISTIQUES.pdf p.33 (données de substitution en cas d'absence de données nationales fiables).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            )
        )
    }
}
