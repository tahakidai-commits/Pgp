package com.example.data.seed

import com.example.data.model.QuestionEntity
import com.example.data.model.QuestionType
import com.example.data.model.QuizEntity

object EpreuveLogistiqueData {

    fun createFullQuiz(): QuizEntity {
        return QuizEntity(
            id = 30L,
            title = "Épreuve : Gestion des Produits de Santé & Logistique",
            description = "Épreuve complète réorganisée (40 questions : 25 Vrai/Faux + 15 QCM) avec corrigé du cours détaillé, justifications de pages et barème officiel (+1 pt si exact, 0 pt si faux ou non répondu).",
            category = "Gestion Logistique",
            isBuiltIn = true,
            createdAt = 1710000030000L
        )
    }

    fun createVraiFauxQuiz(): QuizEntity {
        return QuizEntity(
            id = 31L,
            title = "Épreuve Logistique - Vrai / Faux (Partie 1)",
            description = "Partie 1 (25 questions Vrai/Faux) : Médicaments, DM, médicaments essentiels, DCI, substitution, EPI, contrefaçon, SRMNIA-N, chaîne logistique, quantification (+1 pt / 0 pt).",
            category = "Gestion Logistique",
            isBuiltIn = true,
            createdAt = 1710000031000L
        )
    }

    fun createQcmQuiz(): QuizEntity {
        return QuizEntity(
            id = 32L,
            title = "Épreuve Logistique - QCM (Partie 2)",
            description = "Partie 2 (15 QCM Q26 à Q40) : Parties prenantes, achat, flux, dispositifs médicaux, LNME, quantification, circuits privé/public (NPSP-CI), systèmes PUSH/PULL, PPI (+1 pt / 0 pt).",
            category = "Gestion Logistique",
            isBuiltIn = true,
            createdAt = 1710000032000L
        )
    }

    fun getQuestionsForQuiz(quizId: Long): List<QuestionEntity> {
        return when (quizId) {
            30L -> getFullQuestions(quizId)
            31L -> getPart1VraiFaux(quizId)
            32L -> getPart2Qcm(quizId, offset = 0)
            else -> emptyList()
        }
    }

    private fun getFullQuestions(quizId: Long): List<QuestionEntity> {
        val p1 = getPart1VraiFaux(quizId)
        val p2 = getPart2Qcm(quizId, offset = 25)
        return p1 + p2
    }

    fun getPart1VraiFaux(quizId: Long): List<QuestionEntity> {
        return listOf(
            QuestionEntity(
                quizId = quizId,
                questionIndex = 1,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Le médicament n'a que des propriétés curatives.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Justification (p. 13) : Un médicament a des propriétés curatives, préventives, symptomatiques et diagnostiques.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 2,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les produits stables préparés à partir du sang et de ses composés sont des médicaments.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Ce sont les Médicaments Dérivés du Sang (MDS) stables (albumine, immunoglobulines). Les PSL (ex: plaquettes) sont gérés par le CNTS.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 3,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les objets de pansement sont des médicaments.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Justification (p. 16) : Ce sont des Dispositifs Médicaux (DM) consommables.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 4,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les détergents sont des médicaments.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Ce sont des produits d'entretien et de désinfection.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 5,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les produits supprimant l'accoutumance au tabac sont des médicaments.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Par définition légale, ce sont des médicaments par présentation (sevrage tabagique).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 6,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les produits utilisés pour les prothèses dentaires sont des médicaments.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Ce sont des Dispositifs Médicaux (DM).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 7,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les médicaments essentiels servent au traitement des maladies les plus répandues.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Justification (p. 28) : Ils satisfont aux besoins de la majorité de la population selon la prévalence des maladies.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 8,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "DCI signifie Dénomination Connue Internationalement.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Justification (p. 15) : DCI = Dénomination Commune Internationale.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 9,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Le PGP peut unilatéralement procéder à toute substitution de produits prescrits.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — La substitution est strictement encadrée par la réglementation et n'est pas unilatérale.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 10,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les produits de santé comprennent 4 grands groupes.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Les 4 groupes : 1) Médicaments, 2) Dispositifs Médicaux, 3) Kits, 4) Produits sanguins/vaccins.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 11,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les Équipements de Protection Individuelle (EPI) sont des durables.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Les EPI (gants, masques, surblouses) sont des consommables (usage unique). Les durables sont les lits, autoclaves, microscopes.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 12,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Un médicament est contrefait si et seulement si le dosage du PA est erroné.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Justification (p. 14) : La contrefaçon inclut l'absence de PA, le sous-dosage, un mauvais conditionnement, une fausse étiquette ou l'imitation.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 13,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les ARV sont des produits de la SRMNIA-N.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Les ARV relèvent du programme VIH. La SRMNIA-N concerne la Santé Reproductive, Maternelle, Nouveau-né, Enfant, Adolescent et Nutrition.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 14,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "L'ocytocine est un produit de la SRMNIA-N.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Produit traceur essentiel en santé maternelle.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 15,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Seule la chaleur influence la qualité du médicament.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Justification (p. 33) : La chaleur, l'humidité, la lumière et l'air influencent la qualité.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 16,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "La contrefaçon ne porte que sur le principe actif.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — La contrefaçon peut porter sur l'emballage, le conditionnement ou l'étiquetage.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 17,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les transitaires sont partie prenante de la chaîne d'approvisionnement.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Justification (p. 29) : Ils interviennent dans le transit logistique.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 18,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "La chaîne d'approvisionnement se résume à des flux physiques.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Justification (p. 13) : Elle comprend 3 flux : physique, d'information et financier.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 19,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "La planification des approvisionnements est une étape de la quantification.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Justification (p. 30, Fig. 1) : C'est la 3ᵉ étape de la quantification.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 20,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les données de consommation servent à la quantification.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Justification (p. 33) : La méthode basée sur la consommation historique est l'une des méthodes principales.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 21,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les médicaments essentiels sont sélectionnés en fonction de la préférence des patients.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Faux"),
                explanation = "FAUX — Justification (p. 28) : La sélection dépend de la prévalence des maladies, du coût, de l'efficacité et de la sécurité, non des préférences des patients.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 22,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "La facilité d'emploi est un critère de sélection des médicaments essentiels.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Justification (p. 28) : Elle favorise la bonne observance du traitement.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 23,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les réactifs de laboratoire sont des dispositifs médicaux.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Justification (p. 16) : Ce sont des Dispositifs Médicaux de Diagnostic In Vitro (DMDIV).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 24,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "Les produits de santé comprennent les kits d'accouchement, les dispositifs médicaux et les médicaments.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Justification (p. 1) : Classification retenue dans la définition globale des produits de santé.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = 25,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "En système d'allocation, c'est le niveau supérieur qui détermine les quantités de produits reçus par le niveau inférieur.",
                type = QuestionType.TRUE_FALSE,
                options = listOf("Vrai", "Faux"),
                correctAnswers = listOf("Vrai"),
                explanation = "VRAI — Justification (p. 32) : C'est la définition exacte du système PUSH.",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            )
        )
    }

    fun getPart2Qcm(quizId: Long, offset: Int = 0): List<QuestionEntity> {
        return listOf(
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 1,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "26- Sont partie prenante de la chaîne d'approvisionnement :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Les institutions multilatérales",
                    "b) Les patients",
                    "c) Les chefs de communauté"
                ),
                correctAnswers = listOf("b"),
                explanation = "Réponse : b) Les patients (Bénéficiaire final / client du réseau ; les institutions multilatérales le sont aussi p. 29, mais b est la priorité en tant que destinataire ultime).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 2,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "27- L'acquisition des produits entre le fournisseur et la centrale d'achat peut se faire par :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Appel d'offre",
                    "b) Achat différé",
                    "c) Compensation"
                ),
                correctAnswers = listOf("a"),
                explanation = "Réponse : a) Appel d'offre",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 3,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "28- Une des principales fonctions de la chaîne d'approvisionnement est :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) La gestion des flux physiques",
                    "b) La gestion des flux physiques et des flux d'informations",
                    "c) Le rangement des produits"
                ),
                correctAnswers = listOf("b"),
                explanation = "Réponse : b) La gestion des flux physiques et des flux d'informations",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 4,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "29- Un des éléments suivants fait partie des 3 classes de dispositifs médicaux :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Les tubes",
                    "b) Les microscopes",
                    "c) Les durables"
                ),
                correctAnswers = listOf("c"),
                explanation = "Réponse : c) Les durables (Consommables, durables, réactifs/labo).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 5,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "30- Les médicaments essentiels :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Sont les plus prescrits",
                    "b) Satisfont aux besoins de la majorité de la population",
                    "c) Sont indispensables à tout traitement"
                ),
                correctAnswers = listOf("b"),
                explanation = "Réponse : b) Satisfont aux besoins de la majorité de la population",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 6,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "31- En Côte d'Ivoire, la LNME est révisée tous les :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) 3 ans",
                    "b) 2 ans",
                    "c) 5 ans"
                ),
                correctAnswers = listOf("b"),
                explanation = "Réponse : b) 2 ans",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 7,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "32- La quantification peut être basée sur :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Les résultats d'enquêtes",
                    "b) Les pathologies saisonnières",
                    "c) Les statistiques de service"
                ),
                correctAnswers = listOf("c"),
                explanation = "Réponse : c) Les statistiques de service",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 8,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "33- Les produits de santé comprennent :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Kits, DM et médicaments",
                    "b) Médicaments, DM et équipements médicaux",
                    "c) Kits, DM et consommables"
                ),
                correctAnswers = listOf("a"),
                explanation = "Réponse : a) Kits, DM et médicaments",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 9,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "34- Le circuit de distribution des produits de santé dans le secteur privé est assuré par :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Des supermarchés",
                    "b) Des grossistes répartiteurs",
                    "c) La NPSP-CI"
                ),
                correctAnswers = listOf("b"),
                explanation = "Réponse : b) Des grossistes répartiteurs",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 10,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "35- Le système d'allocation est aussi appelé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) PULL",
                    "b) PUSH",
                    "c) PUTT"
                ),
                correctAnswers = listOf("b"),
                explanation = "Réponse : b) PUSH",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 11,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "36- Le système de réquisition est aussi appelé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) PULL",
                    "b) PUTT",
                    "c) PUSH"
                ),
                correctAnswers = listOf("a"),
                explanation = "Réponse : a) PULL",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 12,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "37- La centrale d'achat du système public national est :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) La NPSP-CI",
                    "b) La DPCI",
                    "c) UBIPHARM"
                ),
                correctAnswers = listOf("a"),
                explanation = "Réponse : a) La NPSP-CI",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 13,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "38- Les PPI peuvent être des produits :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Périmés",
                    "b) Commandés non reçus",
                    "c) Volés"
                ),
                correctAnswers = listOf("a"),
                explanation = "Réponse : a) Périmés (Produits Périmés et Inutilisables).",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 14,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "39- Les produits de santé comprennent :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) Les dispositifs médicaux",
                    "b) Les PPI",
                    "c) Les outils de gestion"
                ),
                correctAnswers = listOf("a"),
                explanation = "Réponse : a) Les dispositifs médicaux",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            ),
            QuestionEntity(
                quizId = quizId,
                questionIndex = offset + 15,
                contextText = "Épreuve Logistique • Barème : Bonne réponse +1 Pt, Fausse ou Non répondu 0 Pt",
                questionText = "40- Trouvez l'élément faisant partie des critères de sélection des produits de santé :",
                type = QuestionType.SINGLE_CHOICE,
                options = listOf(
                    "a) La disponibilité",
                    "b) La couleur"
                ),
                correctAnswers = listOf("a"),
                explanation = "Réponse : a) La disponibilité",
                positivePoints = 1.0f,
                negativePoints = 0.0f,
                maxChoices = 1
            )
        )
    }
}
