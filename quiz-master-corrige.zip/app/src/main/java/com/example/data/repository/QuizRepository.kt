package com.example.data.repository

import com.example.data.local.AttemptDao
import com.example.data.local.QuestionDao
import com.example.data.local.QuizDao
import com.example.data.model.QuestionEntity
import com.example.data.model.QuizAttemptEntity
import com.example.data.model.QuizEntity
import com.example.data.seed.EpreuveLogistiqueData
import com.example.data.seed.EvaluationTox2022Data
import com.example.data.seed.GaleniqueMatierePremiereData
import com.example.data.seed.LogisticsQuizData
import com.example.data.seed.PharmacologyQuizData
import com.example.data.seed.Td2024FormsLogisticsData
import com.example.data.seed.ToxicologyQuizData
import kotlinx.coroutines.flow.Flow

class QuizRepository(
    private val quizDao: QuizDao,
    private val questionDao: QuestionDao,
    private val attemptDao: AttemptDao
) {

    val allQuizzes: Flow<List<QuizEntity>> = quizDao.getAllQuizzes()
    val allAttempts: Flow<List<QuizAttemptEntity>> = attemptDao.getAllAttempts()

    // --- QUIZ ---

    suspend fun getQuizById(quizId: Long): QuizEntity? = quizDao.getQuizById(quizId)

    suspend fun insertQuiz(quiz: QuizEntity): Long = quizDao.insertQuiz(quiz)

    suspend fun updateQuiz(quiz: QuizEntity) = quizDao.updateQuiz(quiz)

    suspend fun deleteQuiz(quiz: QuizEntity) {
        quizDao.deleteQuestionsForQuiz(quiz.id)
        quizDao.deleteQuiz(quiz)
    }

    // --- QUESTIONS ---

    fun getQuestionsForQuiz(quizId: Long): Flow<List<QuestionEntity>> =
        questionDao.getQuestionsForQuiz(quizId)

    suspend fun getQuestionsForQuizSync(quizId: Long): List<QuestionEntity> =
        questionDao.getQuestionsForQuizSync(quizId)

    suspend fun insertQuestions(questions: List<QuestionEntity>) =
        questionDao.insertQuestions(questions)

    suspend fun insertQuestion(question: QuestionEntity): Long =
        questionDao.insertQuestion(question)

    suspend fun updateQuestion(question: QuestionEntity) =
        questionDao.updateQuestion(question)

    suspend fun deleteQuestion(question: QuestionEntity) =
        questionDao.deleteQuestion(question)

    // --- ATTEMPTS ---

    suspend fun recordAttempt(attempt: QuizAttemptEntity): Long =
        attemptDao.insertAttempt(attempt)

    fun getAttemptsForQuiz(quizId: Long): Flow<List<QuizAttemptEntity>> =
        attemptDao.getAttemptsForQuiz(quizId)

    suspend fun deleteAttempt(attemptId: Long) = attemptDao.deleteAttempt(attemptId)

    suspend fun clearAllAttempts() = attemptDao.clearAllAttempts()

    // --- SEEDING BUILT-IN QUIZZES ---

    suspend fun ensureDefaultQuizSeeded() {
        seedQuizIfNeeded(PharmacologyQuizData.createFullQuiz()) { quizId ->
            PharmacologyQuizData.getQuestionsForQuiz(quizId)
        }
        seedQuizIfNeeded(PharmacologyQuizData.createQcdPartQuiz()) { quizId ->
            PharmacologyQuizData.getQuestionsForQuiz(quizId)
        }
        seedQuizIfNeeded(PharmacologyQuizData.createQcmPartQuiz()) { quizId ->
            PharmacologyQuizData.getQuestionsForQuiz(quizId)
        }

        seedQuizIfNeeded(ToxicologyQuizData.createFullQuiz()) { quizId ->
            ToxicologyQuizData.getQuestionsForQuiz(quizId)
        }
        seedQuizIfNeeded(ToxicologyQuizData.createVraiFauxQuiz()) { quizId ->
            ToxicologyQuizData.getQuestionsForQuiz(quizId)
        }
        seedQuizIfNeeded(ToxicologyQuizData.createQcmQuiz()) { quizId ->
            ToxicologyQuizData.getQuestionsForQuiz(quizId)
        }

        seedQuizIfNeeded(LogisticsQuizData.createFullQuiz()) { quizId ->
            LogisticsQuizData.getQuestionsForQuiz(quizId)
        }
        seedQuizIfNeeded(LogisticsQuizData.createVraiFauxQuiz()) { quizId ->
            LogisticsQuizData.getQuestionsForQuiz(quizId)
        }
        seedQuizIfNeeded(LogisticsQuizData.createQcmQuiz()) { quizId ->
            LogisticsQuizData.getQuestionsForQuiz(quizId)
        }

        seedQuizIfNeeded(EpreuveLogistiqueData.createFullQuiz()) { quizId ->
            EpreuveLogistiqueData.getQuestionsForQuiz(quizId)
        }
        seedQuizIfNeeded(EpreuveLogistiqueData.createVraiFauxQuiz()) { quizId ->
            EpreuveLogistiqueData.getQuestionsForQuiz(quizId)
        }
        seedQuizIfNeeded(EpreuveLogistiqueData.createQcmQuiz()) { quizId ->
            EpreuveLogistiqueData.getQuestionsForQuiz(quizId)
        }

        seedQuizIfNeeded(Td2024FormsLogisticsData.createQuiz()) { quizId ->
            Td2024FormsLogisticsData.getQuestions(quizId)
        }

        seedQuizIfNeeded(EvaluationTox2022Data.createQuiz()) { quizId ->
            EvaluationTox2022Data.getQuestions(quizId)
        }

        seedQuizIfNeeded(GaleniqueMatierePremiereData.createQuiz()) { quizId ->
            GaleniqueMatierePremiereData.getQuestions(quizId)
        }
    }

    private suspend fun seedQuizIfNeeded(
        quiz: QuizEntity,
        questionsProvider: (Long) -> List<QuestionEntity>
    ) {
        val existing = quizDao.getQuizById(quiz.id)
        if (existing == null) {
            quizDao.insertQuiz(quiz)
            questionDao.insertQuestions(questionsProvider(quiz.id))
        } else if (questionDao.getQuestionCountForQuiz(quiz.id) == 0) {
            // Quiz row exists but questions are missing (e.g. partial seed) - backfill them.
            questionDao.insertQuestions(questionsProvider(quiz.id))
        }
    }
}
